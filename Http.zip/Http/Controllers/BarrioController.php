<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Barrios;

class BarrioController extends Controller
{
    public function barrioByProCanDis($provincia_id, $canton_id, $distrito_id)
    {
        $barrios = Barrios::where('provincia_id', '=', $provincia_id)
                            ->where('canton_id', '=', $canton_id)
                            ->where('distrito_id', '=', $distrito_id)
                            ->where('barrio_id', '>', 0)
                            ->get();
        return $barrios;
    }
}
