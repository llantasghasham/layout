<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BusquedaController extends Controller
{
    // Método para mostrar la vista del buscador
    public function index()
    {
        return view('busqueda.buscador');
    }

    /**
     * Obtener marcas.
     */
    public function getMarcas()
    {
        $marcas = DB::connection('buscador')->table('tableName')->select('MARCA')->distinct()->orderBy('MARCA', 'ASC')->get();
        return response()->json($marcas);
    }

    /**
     * Obtener modelos según la marca seleccionada.
     */
    public function getModelos(Request $request)
    {
        $marca = $request->input('marca');
        $modelos = DB::connection('buscador')->table('tableName')
            ->where('MARCA', $marca)
            ->select('BF_GLOBAL_MODEL')
            ->distinct()
            ->orderBy('BF_GLOBAL_MODEL', 'ASC')
            ->get();

        return response()->json($modelos);
    }

    /**
     * Obtener submodelos según el modelo seleccionado.
     */
    public function getSubmodelos(Request $request)
    {
        $modelo = $request->input('modelo');
        $submodelos = DB::connection('buscador')->table('tableName')
            ->where('BF_GLOBAL_MODEL', $modelo)
            ->select('MODELO')
            ->distinct()
            ->orderBy('MODELO', 'ASC')
            ->get();

        return response()->json($submodelos);
    }

    /**
     * Obtener versiones según el submodelo seleccionado.
     */
    public function getVersiones(Request $request)
    {
        $submodelo = $request->input('submodelo');
        $versiones = DB::connection('buscador')->table('tableName')
            ->where('MODELO', $submodelo)
            ->select('VERSION')
            ->distinct()
            ->orderBy('VERSION', 'ASC')
            ->get();

        return response()->json($versiones);
    }

    /**
     * Obtener años según la versión seleccionada.
     */
    public function getAnios(Request $request)
    {
        $version = $request->input('version');
        $anios = DB::connection('buscador')->table('tableName')
            ->where('VERSION', $version)
            ->select('ANIO')
            ->distinct()
            ->orderBy('ANIO', 'ASC')
            ->get();

        return response()->json($anios);
    }

    /**
     * Obtener resultados según los datos seleccionados.
     */
    public function getResultados(Request $request)
    {
        $marca = $request->input('marca');
        $modelo = $request->input('modelo');
        $submodelo = $request->input('submodelo');
        $version = $request->input('version');
        $anio = $request->input('anio');

        $resultados = DB::connection('buscador')->table('tableName')
            ->where([
                ['MARCA', '=', $marca],
                ['BF_GLOBAL_MODEL', '=', $modelo],
                ['MODELO', '=', $submodelo],
                ['VERSION', '=', $version],
                ['ANIO', '=', $anio],
            ])
            ->select('IDENTIFICACION')
            ->first();

        return response()->json($resultados);
    }

    /**
     * Manejar la búsqueda por dimensiones de llanta.
     */
    public function buscarPorDimensiones(Request $request)
    {
        $request->validate([
            'ancho' => 'required|string',
            'alto' => 'required|string',
            'aro' => 'required|string',
        ]);

        $ancho = $request->input('ancho');
        $alto = $request->input('alto');
        $aro = $request->input('aro');
        $identificacion = "{$ancho}/{$alto}{$aro}";

        $resultados = DB::connection('buscador')->table('tableName')
            ->where('IDENTIFICACION', 'like', "%{$identificacion}%")
            ->select('MARCA', 'MODELO', 'ANIO')
            ->get();

        return response()->json($resultados);
    }
}
