<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Artisan;

class CacheController extends Controller
{
    public function borrarCache()
    {
        // Borrar caché de la aplicación
        Artisan::call('cache:clear');

        // Borrar caché de configuración
        Artisan::call('config:clear');

        // Borrar caché de vistas
        Artisan::call('view:clear');

        // Borrar caché de rutas
        Artisan::call('route:clear');

        // Borrar caché de eventos
        Artisan::call('event:clear');

        // Borrar caché de optimizaciones
        Artisan::call('optimize:clear');

        return redirect()->back()->with('success', 'Todas las cachés se han borrado correctamente.');
    }
}
