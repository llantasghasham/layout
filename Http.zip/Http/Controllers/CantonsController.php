<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cantons;

class CantonsController extends Controller
{
    public function cantonsByProvincia($provincia_id)
    {
        return Cantons::where('provincia_id', '=', $provincia_id)->get();
    }
}
