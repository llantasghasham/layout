<?php

namespace App\Http\Controllers;

use App\Chat;
use App\User;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function show($id)
    {
        $chat = Chat::findOrFail($id);

        return view('chat.show', ['chat' => $chat]);
    }

    public function addUser(Request $request, $id)
    {
        $chat = Chat::findOrFail($id);

        if ($chat->type != 'group') {
            return response('Forbidden', 403);
        }

        $user = User::findOrFail($request->user_id);

        $chat->users()->attach($user);

        return back();
    }
}
