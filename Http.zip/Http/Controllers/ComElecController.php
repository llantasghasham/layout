<?php

namespace App\Http\Controllers;

use DB;
use DOMDocument;
use App\Voucher_Electronic;
use App\BusinessLocation;
use App\Contact;
use App\Transaction;
//use App\Utils\ModuleUtil;
use App\Utils\BusinessUtil;
use App\Utils\Util;
use Illuminate\Http\Request;
use App\Http\Requests;
//use Spatie\Permission\Models\Permission;
//use Yajra\DataTables\Facades\DataTables;
use App\Utils\TransactionUtil;

require "../vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class ComElecController extends Controller
{
    protected $commonUtil;
    protected $transactionUtil;
    protected $business_id;
    protected $businessUtil;

    public $data;
    public $ConfigMail;
    public $Asunto;
    public $certs;
    public $serial;
    public $name_space;

    public function __construct(
        BusinessUtil $businessUtil,
        Util $commonUtil,
        TransactionUtil $transactionUtil
    ) {
        //SellPosController $sellposcontroller){

        $this->commonUtil     = $commonUtil;
        $this->transactionUtil = $transactionUtil;
        $this->businessUtil  = $businessUtil;

        $this->data      = '';
        $this->ConfigMail = '';
        $this->Asunto    = 'Asunto';

        $this->certs     = [];
        $this->serial    = "";
        $this->name_space = "";
    }
    public function index()
    {
        $this->business_id = request()->session()->get('user.business_id');
        //      $permitted_locations = auth()->user()->permitted_locations();
        $limite = 10;
        $pagina = 1;
        $desde = 1;
        $Obj_Act = 'contenido';
        $location_id = 0;
        $customer_id = 0;
        $statuses_id = 0;
        $year_start = strtotime('first day of January', time());
        $year_end   = strtotime('last day of December', time());
        $start_date = date('Y-m-d', $year_start);
        $end_date  = date("Y-m-d", $year_end);
        //            'desde'      =>$desde,
        $datos = [
            'limite'     => $limite,
            'pagina'     => $pagina,
            'Obj_Act'    => $Obj_Act,
            'location_id' => $location_id,
            'customer_id' => $customer_id,
            'statuses_id' => $statuses_id,
            'start_date' => $start_date,
            'end_date'   => $end_date
        ];
        $text_pagina = $this->Spaginar($datos);
        $business_locations = BusinessLocation::forDropdown($this->business_id, false);
        $customers = Contact::customersDropdown($this->business_id, false);
        global $tipoCompro,$estadoCompro;
        include 'tablas.php';
        return view('voucher_electronic.index')
        ->with(compact(   //     'sources',
            'business_locations',
            'customers',
            'tipoCompro',
            'estadoCompro',
            'limite',
            'desde',
            'text_pagina'
        ));
    }
    public function paginar(Request $request)
    {
        $datos = $request->all();
        $salida = $this->Spaginar($datos);
        echo $salida;
    }
    public function Spaginar($datos)
    {
        $limite     = $datos['limite'];
        $pagina     = $datos['pagina'];
        $Obj_Act    = $datos['Obj_Act'];
        //$desde      =$datos['desde'];
        $location_id = $datos['location_id'];
        $customer_id = $datos['customer_id'];
        $statuses_id = $datos['statuses_id'];
        $start_date = $datos['start_date'];
        $end_date   = $datos['end_date'];
        $year_start = strtotime($start_date);
        $year_end   = strtotime($end_date);
        $start_date = date('Y-m-d', $year_start);
        $end_date  = date("Y-m-d", $year_end);

        $filtro = "a.business_id>0 ";
        if (!empty($location_id)) {
            $filtro = $filtro."and a.location_id=".$location_id." ";
        }
        if (!empty($customer_id)) {
            $filtro = $filtro."and b.contact_id=".$customer_id." ";
        }
        if (!empty($statuses_id)) {
            $filtro = $filtro."and a.status=".$statuses_id." ";
        }
        if (!empty($start_date)) {
            $filtro = $filtro."and a.fechaEmision>='".$start_date."' ";
        }
        if (!empty($end_date)) {
            $filtro = $filtro."and a.fechaEmision<='".$end_date."' ";
        }
        $respuesta = $this->consultaSqL($limite, $pagina, $filtro);

        $VoucherElectronic = $respuesta['resultado'];
        $num_voucher = $respuesta['todos'];
        $desde = $respuesta['inicio'];
        $hasta = $respuesta['hasta'];
        if ($num_voucher < $hasta) {
            $hasta = $num_voucher;
        }

        global $tipoCompro,$estadoCompro;
        include 'tablas.php';
        $color = [
        '00' => '#EB984E',
        '01' => '#FEFEFE',
        '02' => '#FCE4C4',
        '03' => '#C0B99D',
        '04' => '#C3A492',
        '05' => '#D2B4DE',
        '06' => '#F8E469',
        '07' => '#ABEBC6',
        '08' => '#F1948A',
        '09' => '#58C3BB',
        '10' => '#58D68D'
        ];
        //

        $pagina_html = '';
        $pagina_html = $pagina_html.'<div class="table-responsive">';
        $pagina_html = $pagina_html.'<table class="table table-bordered table-striped ajax_view" id="voucher_electronico_table">';
        $pagina_html = $pagina_html.'<thead>';
        $pagina_html = $pagina_html.'<tr> ';
        $pagina_html = $pagina_html.'<th>Acción</th>';
        $pagina_html = $pagina_html.'<th>&nbsp&nbsp&nbspFecha&nbsp&nbsp&nbsp</th>';
        $pagina_html = $pagina_html.'<th>Nº Transacción</th>';
        $pagina_html = $pagina_html.'<th>Nº del Comprobante</th>';
        $pagina_html = $pagina_html.'<th>Tipo del Comprobante</th>';
        $pagina_html = $pagina_html.'<th>Estado del Comprobante</th>';
        $pagina_html = $pagina_html.'<th>Monto Total</th>';
        $pagina_html = $pagina_html.'<th>Nº de Artículos</th>';
        $pagina_html = $pagina_html.'</tr>';
        $pagina_html = $pagina_html.'</thead>';
        $pagina_html = $pagina_html.'<tbody>';
        $lineaPagina = "";
        foreach ($VoucherElectronic as $Voucher) {
            $cod_comprobante = str_pad($Voucher->vauchertype, 2, "0", STR_PAD_LEFT);
            $cod_estadoCompro = str_pad($Voucher->vaucherElect_status, 2, "0", STR_PAD_LEFT);
            $lineaPagina = $lineaPagina.'<tr>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">';
            $lineaPagina = $lineaPagina.'<div class="btn-group">';
            $lineaPagina = $lineaPagina.'<button type="button" class="btn btn-info dropdown-toggle btn-xs" data-toggle="dropdown" aria-expanded="false">';
            $lineaPagina = $lineaPagina.__("messages.actions");
            $lineaPagina = $lineaPagina.'<span class="caret"></span><span class="sr-only">Toggle Dropdown';
            $lineaPagina = $lineaPagina.'</span>';
            $lineaPagina = $lineaPagina.'</button>';
            $lineaPagina = $lineaPagina.'<ul class="dropdown-menu dropdown-menu-left" role="menu">';
            $lineaPagina = $lineaPagina.'<li><a href="#" data-href="'.action("ComElecController@ver_archivoxml", [$Voucher->id]).'" class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> Ver Comprobante Electrónico</a></li>';
            //$lineaPagina=$lineaPagina.'<li><a href="#" data-href="'.action("ComElecController@ver_archivoxml2",[$Voucher->id]).'" class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> Ver Mensaje de envio </a></li>';
            $lineaPagina = $lineaPagina.'<li><a href="#" data-href="'.action("ComElecController@ver_archivopdf", [$Voucher->id]).'" class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> Ver Comprobante pdf </a></li>';
            $lineaPagina = $lineaPagina.'<li><a href="#" data-href="'.action("ComElecController@consulta_elec", [$Voucher->transaction_id]).'" class="btn-modal" data-container=".view_modal"><i class="fas fa-eye" aria-hidden="true"></i> Consultar Electrónico </a></li>';

            $lineaPagina = $lineaPagina.'</ul>';
            $lineaPagina = $lineaPagina.'</div>';
            $lineaPagina = $lineaPagina.'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">'.$Voucher->fechaEmision.'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">'.$Voucher->invoice_no.'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">';
            $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #FADBD8; color:#17202A; font-size: 12px" title="No enviado a hacienda" ';

            if ($Voucher->status == 1) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F9FB22; color:#17202A; font-size: 12px" title="Enviado a hacienda" ';
            }
            if ($Voucher->status == 2) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F8C471; color:#17202A; font-size: 12px" title="Recibido por hacienda" ';
            }
            if ($Voucher->status == 3) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #88FA64; color:#17202A; font-size: 12px" title="Aceptado por hacienda" ';
            }
            if ($Voucher->status == 4) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F1948A; color:#17202A; font-size: 12px" title="Rechazado por hacienda" ';
            }
            if ($Voucher->status == 5) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #D6EAF8; color:#17202A; font-size: 12px" title="Procesando por hacienda" ';
            }
            if ($Voucher->status == 6) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F1948A; color:#17202A; font-size: 12px" title="Error en el xml o ya se envio" ';
            }


            $lineaPagina = $lineaPagina.'<div style="'.$atributo.'" class="btn-group">&nbsp'.$Voucher->NumeroConsecutivo.'&nbsp</div>';
            '</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">'.$tipoCompro[$cod_comprobante].'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;"><i> '.$estadoCompro[$cod_estadoCompro].' </i></td>'; //style="background-color:#EB984E"  '.$color[$cod_estadoCompro].'
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">'.number_format($Voucher->final_total, 2).'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:85%;">'.$Voucher->num_product.'</td>';
            $lineaPagina = $lineaPagina.'</tr>';
        }
        $pagina_html = $pagina_html.$lineaPagina;
        $pagina_html = $pagina_html.'</tbody>';
        $pagina_html = $pagina_html.'</table>';
        $pagina_html = $pagina_html.'</div>';
        $pagina_html = $pagina_html.'<div id="viendo">';
        $Cuantaslineas = 'Mostrando '.$desde.' a '.$hasta.' de '.$num_voucher.' entradas';
        $pagina_html = $pagina_html.$Cuantaslineas;
        $pagina_html = $pagina_html.'</div>';

        $pagina_html = $pagina_html.'<div class="card-body float-left" >';

        $pagina_html = $pagina_html.'<nav aria-label="Page navigation example" id="Para_ver">';
        $pagina_html = $pagina_html.'<ul class="pagination" id="Paginar">';
        $paginar = '';
        $total_pages = ceil($num_voucher / $limite);
        if ($total_pages > 1) {
            $control = '/ComElecController';
            if ($pagina > 1) {
                $primero = 1;
                $antes = $pagina - 1;
                $toEjecutar = "'".$control."',".$limite.",".$primero.",'','".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginar('.$toEjecutar.')"><span aria-hidden="true">Primero</span></a></li>';
                $toEjecutar = "'".$control."',".$limite.",".$antes.",'','".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginar('.$toEjecutar.')"><span aria-hidden="true">Anterior</span></a></li>';
            }

            $muestra = 1;
            $verPagina = 1;
            if ($pagina > 3) {
                $verPagina = $pagina - 2;
            }
            for ($i = $verPagina;$i <= $total_pages;$i++) {
                $toEjecutar = "'".$control."',".$limite.",".$i.",'','".$Obj_Act."'";
                if ($pagina == $i) {
                    $paginar = $paginar.'<li class="page-item active"><a class="page-link" >'.$i.'</a></li>';
                } else {
                    $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginar('.$toEjecutar.')">'.$i.'</a></li>';
                }
                $muestra = $muestra + 1;
                if ($muestra > 5) {
                    break;
                }
            }

            if ($pagina != $total_pages) {
                $despues = $pagina + 1;
                $toEjecutar = "'".$control."',".$limite.",".$despues.",'','".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginar('.$toEjecutar.')"><span aria-hidden="true">Siguiente</span></a></li>';
                $toEjecutar = "'".$control."',".$limite.",".$total_pages.",'','".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginar('.$toEjecutar.')"><span aria-hidden="true">Ultima</span></a></li>';
            }
        }
        $pagina_html = $pagina_html.$paginar;
        $pagina_html = $pagina_html.'</ul>';
        $pagina_html = $pagina_html.'</nav>';
        $pagina_html = $pagina_html.'</div>';
        return $pagina_html;
    }
    public function consultaSqL($limite, $pagina, $filtro = "")
    {
        $this->business_id = request()->session()->get('user.business_id');
        if ($pagina == 0) {
            $pagina = 1;
        }
        $inicio = ($pagina - 1) * $limite;
        // ************************
        // cuantos voucher electronicos hay
        $tabla = "voucher_electronic AS a ";
        $tabla = $tabla."INNER JOIN transactions AS b ON a.transaction_id=b.id ";
        $datos       = "COUNT(*) as num_voucher ";
        $condicion = "";
        $condicion = $condicion."a.business_id=".$this->business_id." ";
        if (!empty($filtro)) {
            $condicion = $condicion."and ".$filtro." ";
        }
        //$agrupa="a.transaction_id,a.vauchertype,a.vaucherElect_status ";
        $agrupa = "a.transaction_id ";
        $sql = 'SELECT '.$datos;
        $sql = $sql.'FROM '.$tabla;
        $sql = $sql.'WHERE '.$condicion;
        $VoucherElectronic = DB::select($sql);
        $num_voucher = $VoucherElectronic[0]->num_voucher;

        //**********************
        $tabla = "voucher_electronic AS a ";
        $tabla = $tabla."INNER JOIN transactions AS b ON a.transaction_id=b.id ";
        $tabla = $tabla."LEFT JOIN transaction_sell_lines AS c ON a.transaction_id=c.transaction_id ";
        $datos       = "a.*, ";
        $datos = $datos."b.final_total,b.invoice_no,COUNT(a.transaction_id) as num_product ";
        $ordenar = "a.fechaEmision desc,a.transaction_id asc ";
        $sql = 'SELECT '.$datos;
        $sql = $sql.'FROM '.$tabla;
        $sql = $sql.'WHERE '.$condicion;
        $sql = $sql.'GROUP BY '.$agrupa;
        $sql = $sql.'ORDER BY '.$ordenar;
        $sql = $sql.'LIMIT '.$inicio.','.$limite;
        //$respuesta= $sql;
        $VoucherElectronic = DB::select($sql);

        $hasta = $inicio + $limite;
        $inicio = $inicio + 1;
        $respuesta = [
            'inicio' => $inicio,
            'hasta' => $hasta,
            'todos' => $num_voucher,
            'resultado' => $VoucherElectronic,
            'Consulta' => $sql
        ];
        return $respuesta;
        // ************************
    }
    public function ComproElec($idp, $ver_msg = "dime", $send_cliente = false, $ver_xml = false)
    {
        $mensaje = $this->VoucherElectronico($idp, 1, 1);
        if ($mensaje['success'] == true) {
            $msg1 = $mensaje['msg'];
            $this->gen_pdf($idp);
            $mensaje = $this->verifica_estado($idp);
            //$mensaje=$this->EnviaClienteHac($idp);
            if ($mensaje['success'] == true) {
                $mensaje = $this->CorreoCliente($idp);
                if ($mensaje['success'] == true) {
                    $mensaje['msg'] = $msg1;
                }
            }
        }
        if ($ver_msg == "dime") {
            $msg = $mensaje['msg'];
            return view('voucher_electronic.mensaje')
            ->with(compact(
                'msg'
            ));
        }
    }
    public function RComproElec($idp)
    {
        $mensaje = $this->VoucherElectronico($idp, 2, 1);
        if ($mensaje['success'] == true) {
            $msg1 = $mensaje['msg'];
            $this->gen_pdf($idp);
            $mensaje = $this->verifica_estado($idp);
            //$mensaje=$this->EnviaClienteHac($idp);
            if ($mensaje['success'] == true) {
                $mensaje = $this->CorreoCliente($idp);
                if ($mensaje['success'] == true) {
                    $mensaje['msg'] = $msg1;
                }
            }
        }
        $msg = $mensaje['msg'];
        //return $msg;
        return view('voucher_electronic.mensaje')
        ->with(compact(
            'msg'
        ));
    }
    public function FIComproElec($idp)
    {
        $mensaje = $this->VoucherElectronico($idp, 3, 1);
        if ($mensaje['success'] == true) {
            $msg1 = $mensaje['msg'];
            $this->gen_pdf($idp);
            $mensaje = $this->verifica_estado($idp);
            //$mensaje=$this->EnviaClienteHac($idp);
            if ($mensaje['success'] == true) {
                $mensajef = $this->CorreoCliente($idp);
                if ($mensajef['success'] == true) {
                    $mensajef['msg'] = $msg1;
                }
            }
        }
        $msg = $mensaje['msg'];
        //return $msg;
        return view('voucher_electronic.mensaje')
        ->with(compact(
            'msg'
        ));
    }
    public function NotaCreditoEdit($id)
    {
        $transaction = Transaction::where('id', '=', $id)
                                  ->get();
        $razon = $transaction[0]->razon;
        return view('voucher_electronic.razon')
        ->with(compact(
            'id',
            'razon'
        ));
    }
    public function NotaCredito_pro($idp)
    {
        try {
            $sql = 'SELECT * FROM transactions WHERE id='.$idp;
            $transactions_datos = DB::select($sql);
            $padre_fact = null;
            if (count($transactions_datos) == 1) {
                $padre_fact = $transactions_datos[0]->return_parent_id;
            }
            if (!empty($padre_fact)) {
                $sql = 'SELECT * FROM voucher_electronic WHERE transaction_id='.$padre_fact;
                $transactions_datos = DB::select($sql);
                if (count($transactions_datos) < 1) {
                    $output = [
                        'success' => 0,
                        'msg' => "No tiene factura en hacienda"
                    ];
                    return $output;
                }
            } else {
                $output = [
                    'success' => 0,
                    'msg' => "No tiene factura en hacienda"
                ];
                return $output;
            }
            $mensaje = $this->VoucherElectronico($idp, 1, 3, $padre_fact);
            if ($mensaje['success'] == true) {
                $msg1 = $mensaje['msg'];
                $this->gen_pdf($idp);
                $mensaje = $this->verifica_estado($idp);
                //$mensaje=$this->EnviaClienteHac($idp);
                if ($mensaje['success'] == true) {
                    $mensajef = $this->CorreoCliente($idp);
                    if ($mensajef['success'] == true) {
                        $mensajef['msg'] = $msg1;
                    }
                }
            }

            return $mensaje;
            //code...
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = "File:" . $e->getFile(). "<br>Line:" . $e->getLine(). "<br>Message:" . $e->getMessage(); // "Error: " . $e->getMessage()
            $output = [
                'success' => 0,
                'msg' => $msg
            ];
            return $output;
        }
    }
    ////////////////////////////
    public function NotaCredito(Request $request)
    {
        try {
            $idp = request()->get('id');
            $sql = 'SELECT * FROM transactions WHERE id='.$idp.'';
            $transactions_datos = DB::select($sql);
            $padre_fact = null;
            if (count($transactions_datos) == 1) {
                $padre_fact = $transactions_datos[0]->return_parent_id;
            }
            if (!empty($padre_fact)) {
                $sql = 'SELECT * FROM voucher_electronic WHERE transaction_id='.$padre_fact;
                $transactions_datos = DB::select($sql);
                if (count($transactions_datos) < 1) {
                    $output = [
                        'success' => 0,
                        'msg' => "No tiene factura en hacienda"
                    ];
                    return $output['msg'];
                }
            } else {
                $output = [
                    'success' => 0,
                    'msg' => "No tiene factura en hacienda"
                ];
                return $output['msg'];
            }

            $mensaje = $this->VoucherElectronico($idp, 1, 3, $padre_fact);
            if ($mensaje['success'] == true) {
                $razon = request()->get('razon');
                $tabla = "transactions ";
                $campos = "razon='".$razon."' ";
                $condicion = "id=".$idp;
                $sql = 'UPDATE '.$tabla.'SET '.$campos.'WHERE '.$condicion;
                $transactions = DB::select($sql);
                $msg1 = $mensaje['msg'];
                $this->gen_pdf($idp);
                $mensaje = $this->verifica_estado($idp);
                //$mensaje=$this->EnviaClienteHac($idp);
                if ($mensaje['success'] == true) {
                    $mensaje = $this->CorreoCliente($idp);
                    if ($mensaje['success'] == true) {
                        $mensaje['msg'] = $msg1;
                    }
                }
            }

            return $mensaje['msg'];
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $msg = "File:" . $e->getFile(). "<br>Line:" . $e->getLine(). "<br>Message:" . $e->getMessage(); // "Error: " . $e->getMessage()
            return $msg;
        }
    }
    public function TiqueteElec($idp, $ver_msg = "dime", $send_cliente = false, $ver_xml = false)
    {
        $mensaje = $this->VoucherElectronico($idp, 1, 4);
        if ($mensaje['success'] == true) {
            $msg1 = $mensaje['msg'];
            $this->gen_pdf($idp);
            $mensaje = $this->verifica_estado($idp);
            /*if ($mensaje['success']==true){
                $mensaje=$this->CorreoCliente($idp);
                if ($mensaje['success']==true){
                    $mensaje['msg']=$msg1;
                }
            } */
        }

        if ($ver_msg == "dime") {
            $msg = $mensaje['msg'];
            return view('voucher_electronic.mensaje')
            ->with(compact(
                'msg'
            ));
        }
    }
    //**************** */
    public function EnviarCliente($idp)
    {
        //$mensaje=$this->EnviaClienteHac($id);
        //$msg1=$mensaje['msg'];
        //if ($mensaje['success']==true){
        $mensaje = $this->verifica_estado($idp);
        $this->gen_pdf($idp);
        if ($mensaje['success'] == true) {
            $mensaje = $this->CorreoCliente($idp);
        }
        //}
        return $mensaje;
    }
    //
    public function EnviandoCliente($id)
    {
        try {
            // si ya esta en cola
            $tablas = "voucher_electronic AS a ";
            $tablas = $tablas."INNER JOIN business_locations AS b ON a.business_id = b.business_id AND a.location_id = b.id ";
            $tablas = $tablas."INNER JOIN transactions AS c ON a.transaction_id = c.id ";
            $tablas = $tablas."LEFT JOIN contacts AS d ON c.contact_id = d.id ";
            $tablas = $tablas."INNER JOIN business AS e ON a.business_id = e.id ";
            $datos = "";
            $datos = $datos."a.*,e.logo, ";
            $datos = $datos."b.name AS name_emi,b.email AS email_emi,b.codpais1 as cod_pais_emi,b.mobile as telefono_emi,b.cedula_juridica,b.website, ";
            $datos = $datos."b.certificado,b.llavecripto,b.username,b.password,b.cliente_id,b.ruta_xml,b.clave_mail, ";
            $datos = $datos."c.invoice_no,c.tax_amount,c.final_total,c.total_before_tax, ";
            $datos = $datos."d.name as name_rec,d.email AS email_rec,d.cedula_juridica as cedula_rec ";
            $sql = "SELECT ".$datos."FROM ".$tablas."WHERE a.transaction_id='".$id."'";
            $voucher_electronic = DB::select($sql);
            if (count($voucher_electronic) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'No está en cola de envia a hacienda.'
                ];
                return $output;
            }
            /*if ($voucher_electronic[0]->status==0){
                $output = [
                    'success' => false,
                    'msg' => 'No se ha enviado a Hacienda'
                ];
                return $output;
            }*/
            $fecha      = $voucher_electronic[0]->fechaEmision;

            $vaucherElect_status = $voucher_electronic[0]->vaucherElect_status;
            if (empty($voucher_electronic[0]->xml)) {
                $output = [
                    'success' => false,
                    'msg' => 'El Comprobante esta vacio.'
                ];
                return $output;
            }
            if (!file_exists($voucher_electronic[0]->xml)) {
                $output = [
                    'success' => false,
                    'msg' => 'El Comprobante Electrónico '.trim($voucher_electronic[0]->xml).' no está en disco.'
                ];
                return $output;
            }

            $sql = 'SELECT * FROM transactions WHERE id='.$id;
            $transactions_datos = DB::select($sql);
            $contact_id = $transactions_datos[0]->contact_id;
            if (empty($contact_id)) {
                $output = ['success' => false,
                        'msg' => 'Transacción sin cliente.'
                ];
                return $output;
            }
            $business_id = $transactions_datos[0]->business_id;
            $location_id = $transactions_datos[0]->location_id;

            $sql = 'SELECT * FROM contacts WHERE id='.$contact_id;
            $contact_datos = DB::select($sql);
            if (count($contact_datos) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'Transacción sin cliente.'
                ];
                return $output;
            }

            $sql = 'SELECT * FROM business WHERE id='.$business_id;
            $business_datos = DB::select($sql);
            if (count($business_datos) < 1) {
                $output = ['success' => false,
                        'msg' => 'Transacción sin empresa.'
                ];
                return $output;
            }

            $vauchertype = 5;
            $vaucherElect_status = 7;

            $clave = "";
            $location_id        = $transactions_datos[0]->location_id;
            $terminal           = $transactions_datos[0]->id_terminal;
            $transaction_id     = $transactions_datos[0]->id;
            $transaction_fecha = strtotime($voucher_electronic[0]->fechaEmision);

            $ano = strval(date("Y", $transaction_fecha));
            $ano = substr($ano, -2, 2);

            if ($vauchertype != 8) {
                $tipoIdEmisor =
                $emisor      = $voucher_electronic[0]->cedula_juridica;
                $cedReceptor = $voucher_electronic[0]->cedula_rec;
            } else {
                $emisor      = $voucher_electronic[0]->cedula_rec;
                $cedReceptor = $voucher_electronic[0]->cedula_juridica;
            }

            $ano = strval(date("Y", $transaction_fecha));
            $ano = substr($ano, -2, 2);
            $documento = str_pad($transaction_id, 10, "0", STR_PAD_LEFT);
            $clave = $clave."506";
            $clave = $clave.str_pad(date("d", $transaction_fecha), 2, "0", STR_PAD_LEFT);
            $clave = $clave.str_pad(date("m", $transaction_fecha), 2, "0", STR_PAD_LEFT);
            $clave = $clave.$ano;
            $clave = $clave.str_pad($emisor, 12, "0", STR_PAD_LEFT);
            $clave = $clave.str_pad($location_id, 3, "0", STR_PAD_LEFT); // tamaño 3 digitos correspondientes a la sucursal de donde proviene el documento
            $clave = $clave.str_pad($terminal, 5, "0", STR_PAD_LEFT);    //tamaño 5 digitos correspondientes al terminal o punto de venta
            $clave = $clave.str_pad($vauchertype, 2, "0", STR_PAD_LEFT);
            $clave = $clave.$documento;
            $clave = $clave.str_pad($vaucherElect_status, 1, "0", STR_PAD_LEFT); // tamaño 1 digito corresponde a la situacion del documento 1 Normal 2 Contingencia y 3 Sin internet

            $clave = $clave.substr($documento, 2, 10);


            $vaucherElect_id = $voucher_electronic[0]->vaucherElect_id;
            $NumeroConsecutivo  = $voucher_electronic[0]->NumeroConsecutivo;
            $statusOld = trim($voucher_electronic[0]->statusOld).",".$voucher_electronic[0]->vaucherElect_status;
            $xml = simplexml_load_file($voucher_electronic[0]->xml);

            $sigTipoDoc = "MR";
            $desTipoDoc = "Mensaje Receptor";
            /*
                switch ($vauchertype) {
                    case 5:
                        $sigTipoDoc="MR";
                        $desTipoDoc="Mensaje Receptor";
                        break;
                    case 6:
                        $sigTipoDoc="MR";
                        $desTipoDoc="Mensaje Receptor";
                        break;
                    case 7:
                        $sigTipoDoc="RR";
                        $desTipoDoc="Rechazo Receptor";
                        break;
                }
            */

            $currency_id = $business_datos[0]->currency_id;
            $sql = 'SELECT a.*, b.codigo as actividad_economica FROM business_locations AS a ';
            $sql = $sql.'LEFT JOIN actividades_economica AS b ON a.actividad_economica_id = b.id ';
            $sql = $sql.'WHERE a.business_id='.$business_id.' and a.id='.$location_id;
            $ubicacion_datos = DB::select($sql);
            $certificado = DIR_PRO.'/public'.FILEENCRIPTADOS.'/'.trim($ubicacion_datos[0]->certificado);
            if (!file_exists($certificado)) {
                $output = [
                    'success' => false,
                    'msg' => 'El archivo '.$certificado.' no existe. debe copiarlo en '.'/public'.FILEENCRIPTADOS
                ];
                return $output;
            }

            $actividad_economica = $ubicacion_datos[0]->actividad_economica;
            $cedEmisor     = $ubicacion_datos[0]->cedula_juridica;
            //  $datos_config  =$ubicacion_datos[0]->datos_config;
            $tipoIdEmisor  = $ubicacion_datos[0]->tipo_ident;
            $emailEmisor   = $ubicacion_datos[0]->email;

            $tipoIdReceptor = $contact_datos[0]->tipo_ident;
            $cedReceptor   = $contact_datos[0]->cedula_juridica;
            $emailReceptor = $contact_datos[0]->email;

            $datos_config = '{"USERNAME":"'   .trim($ubicacion_datos[0]->username)
                         .'","CLIENT_ID":"'  .trim($ubicacion_datos[0]->cliente_id)
                         .'","PASSWORD":"'   .trim($ubicacion_datos[0]->password)
                         .'","LLAVECRIPTO":"'.trim($ubicacion_datos[0]->llavecripto)
                         .'","RUTA_XML":"'   .trim($ubicacion_datos[0]->ruta_xml)
                         .'","CLAVE_MAIL":"'.trim($ubicacion_datos[0]->clave_mail)
                         .'"}';

            $archivomensaje = DIR_PRO.'/public/resources/MensajeReceptor.txt';
            $mensaje = "";
            if (file_exists($archivomensaje)) {
                $mensaje = file_get_contents($archivomensaje);
            }

            $mensaje = $mensaje.PHP_EOL;

            $fondo = 'Se adjuntan comprobantes electrónicos nº: '.$voucher_electronic[0]->NumeroConsecutivo.PHP_EOL;
            if (!empty($voucher_electronic[0]->xml)) {
                $nombre1   = pathinfo($voucher_electronic[0]->xml, PATHINFO_FILENAME);
                $extension1 = pathinfo($voucher_electronic[0]->xml, PATHINFO_EXTENSION);
                $fondo = $fondo.'Sus archivos: ';
                $fondo = $fondo.''.$nombre1.'.'.$extension1.PHP_EOL;
                if (!empty($voucher_electronic[0]->xml2)) {
                    $nombre2   = pathinfo($voucher_electronic[0]->xml2, PATHINFO_FILENAME);
                    $extension2 = pathinfo($voucher_electronic[0]->xml2, PATHINFO_EXTENSION);
                    $fondo = $fondo.','.$nombre2.'.'.$extension2.PHP_EOL;
                }
                if (!empty($voucher_electronic[0]->pdf)) {
                    $nombre3   = pathinfo($voucher_electronic[0]->pdf, PATHINFO_FILENAME);
                    $extension3 = pathinfo($voucher_electronic[0]->pdf, PATHINFO_EXTENSION);
                    $fondo = $fondo.','.$nombre3.'.'.$extension3.PHP_EOL;
                }
            }

            $cabeza = "";
            $cabeza = $cabeza.'Mensaje Emitido por: '.trim($voucher_electronic[0]->name_emi).PHP_EOL;
            $cabeza = $cabeza.'Con correo: '.trim($voucher_electronic[0]->email_emi).PHP_EOL;
            $cabeza = $cabeza.'Teléfono: '.str_pad($voucher_electronic[0]->cod_pais_emi, 3, '0', STR_PAD_LEFT).'-'.trim($voucher_electronic[0]->telefono_emi).PHP_EOL;
            $cabeza = $cabeza.'Nº de registro: '.$voucher_electronic[0]->cedula_juridica.PHP_EOL.PHP_EOL;

            $name_rec = letraEspeciales(trim($voucher_electronic[0]->name_rec));
            $cabeza = $cabeza.'Receptor del Comprobante: '.$name_rec.PHP_EOL;
            $cabeza = $cabeza.'Nº de registro: '.$voucher_electronic[0]->cedula_rec.PHP_EOL;
            $cabeza = $cabeza.'Correo: '.$voucher_electronic[0]->email_rec.PHP_EOL.PHP_EOL;

            $mensaje = $cabeza.$mensaje.$fondo;

            $config = json_decode($datos_config, true);
            $datos = ['Clave'             => $clave,
                    'cedEmisor'         => $emisor,
                    'FechaEmisionDoc'   => $fecha,
                    'cedReceptor'       => $cedReceptor,
                    'Mensaje'           => 1,   //$voucher_electronic[0]->Mensaje; // valores: 1 (aceptado), 2 (aceptado parcialmente) y 3 (rechazado)
                    'DetalleMensaje'    => $mensaje,
                    'MontoTotalImpuesto' => $voucher_electronic[0]->MontoTotalImpuesto,
                    'TotalFactura'      => $voucher_electronic[0]->TotalFactura,
                    'NumeroConsecutivo' => $NumeroConsecutivo,
                    'vauchertype' => $vauchertype
            ];
            // Preparar Firma
            if (!$data = file_get_contents($certificado)) {
                $output = ['success' => false,
                    'msg' => 'Error: No se puede leer el archivo de certificado o no existe en la ruta especificada.'
                ];
                return $output;
            }

            $archivo_certificado = array_merge([
                'file' => '',
                'pass' => ''.$config['LLAVECRIPTO'],
                'data' => ''.$data,
                'archivo' => $certificado
            ], $config);

            $xml_ws = $this->armar_xml_cliente($datos, $archivo_certificado); //$clave_doc, $consecutivo);

            $nombre_xml = DIR_PRO.'/public'.$config['RUTA_XML'].'/'.$NumeroConsecutivo.$vaucherElect_status.$sigTipoDoc.'.xml';
            if (file_exists($nombre_xml)) {
                unlink($nombre_xml);
            }

            $xml = base64_decode($xml_ws);
            file_put_contents($nombre_xml, $xml);

            $token = token($datos_config);
            if (isset($token->access_token)) {
                $xml_ws64 = $xml_ws;
                $xml_ws = "";
                $array = new \stdClass();
                $array->clave  = "".$clave;
                $array->fecha  = "".$fecha;
                $array->emisor = array(
                    "tipoIdentificacion" => ''.$tipoIdEmisor,
                    "numeroIdentificacion" => ''.$cedEmisor
                );
                $array->receptor = array(
                    "tipoIdentificacion" => ''.$tipoIdReceptor,
                    "numeroIdentificacion" => ''.$cedReceptor
                );
                $array->consecutivoReceptor = $NumeroConsecutivo;
                $array->comprobanteXml = $xml_ws64;
                $mensaje = json_encode($array, true);

                $access_token = $token->access_token;
                $tabla = 'voucher_electronic ';
                $campos = '';
                $campos = $campos.'xml2="'.$nombre_xml.'", ';
                $campos = $campos.'statusOld="'.trim($statusOld).'", ';
                $campos = $campos.'vaucherElect_status="'.$vaucherElect_status.'" ';
                $condicion = 'transaction_id='.$id;

                $sql = 'UPDATE '.$tabla.'SET '.$campos.'WHERE '.$condicion;
                $voucher_electronic = DB::select($sql);
                set_time_limit(20);
                $config = json_decode($datos_config, true);
                $curl_envio = "";
                // activar
                //$curl_envio = $this->Envia_Doc_Cliente($mensaje,$token->access_token,$clave,$datos_config);
                if (!empty($curl_envio)) {
                    $i = 1;
                    do {
                        $fnombre_e = DIR_PRO.'/public'.$config['RUTA_XML'].'/'.$NumeroConsecutivo.$vaucherElect_status.$sigTipoDoc.'-MR'.$i.'.txt';
                        if (!file_exists($fnombre_e)) {
                            file_put_contents($fnombre_e, $curl_envio);
                            break;
                        }
                        $i = $i + 1;
                    } while ($i > 0);
                }

                $output = [
                    'success' => true,
                    'msg' => 'Mensaje Enviado.'
                ];
                logout($access_token, $datos_config);
            } else {
                $output = [
                    'success' => false,
                    'msg' => 'No hay conexión con Hacienda .'
                ];
            }
            return $output;
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $output = [
                'success' => false,
                'msg' => "File:" . $e->getFile(). "<br>Line:" . $e->getLine(). "<br>Message:" . $e->getMessage() // "Error: " . $e->getMessage()
            ];
            return $output;
        }
    }
    public function Envia_Doc_Cliente($json, $token, $clave, $dato_cof)
    {
        $config = json_decode($dato_cof, true);
        $apiTo = $config['CLIENT_ID'];
        if ($apiTo == 'api-stag') {
            $url = URLAPISTAG;
        } elseif ($apiTo == 'api-prod') {
            $url = URLAPIPROD;
        }
        $url = $url."recepcion";

        $header = array(
            "Authorization: Bearer ".$token,
            'Content-Type: application/json'
        );

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $respuesta = curl_exec($curl);
        $status1 = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $arrayResp = array(
            "Status" => $status1,
            "text" => explode("\n", $respuesta)
        );
        curl_close($curl);
        if ($status1 == 400) {
            return  $status1;
        } else {
            return $respuesta;
        }
    }
    public function EnviaClienteHac($id)
    {
        /*$datos=cuerpoEnvioCliente($id);
        if ($datos['success']==true){
            $Arrydatos=$datos['data']; */
        $datos = $this->EnviandoCliente($id);
        return $datos;
    }
    public function CorreoCliente($id)
    {
        $datos = cuerpoEnvioCliente($id);
        $data = $datos['data'];
        $susesos = [
            'success' => $datos['success'],
            'msg'     => $datos['msg']
        ];
        if ($datos['success'] == true) {
            $susesos = Enviar_Correo($data);
            if ($susesos['success'] == true) {
                if (!empty($data['statusOld'])) {
                    $statusOld = $data['statusOld'].','.$data['vaucherElect_status'];
                } else {
                    $statusOld = $data['vaucherElect_status'];
                }
                $tabla = "voucher_electronic ";
                $condicion = "transaction_id=".$id;
                $campos = "vaucherElect_status=7, ";
                $campos = $campos."statusOld='".$statusOld."' ";
                $sql = 'UPDATE '.$tabla.'SET '.$campos.'WHERE '.$condicion;
                $transactions = DB::select($sql);
            }
        }
        return $susesos;
        /*return view('voucher_electronic.mensaje')
        ->with(compact(
            'msg'
        ));*/
    }
    public function armar_xml_cliente($datos, $archivo_certificado) //$clave, $consecutivo){
    {// XML dinamico para el mensaje receptor
        // $xml = $datos['rutaxml'];  //simplexml_load_file($this->xmlCompleto['rutaxml']);
        $cedEmisor = $datos['cedEmisor'];  //$xml->Emisor->Identificacion->Numero;
        $cedReceptor = $datos['cedReceptor'];  //$xml->Receptor->Identificacion->Numero;
        $xmlDoc = new DOMDocument('1.0', 'UTF-8');
        $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("MensajeReceptor"));
        $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
            $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor')
        );
        //ENCABEZADO DEL XML
        $facturacion->appendChild($xmlDoc->createAttribute("xmlns:xsd"))->appendChild(
            $xmlDoc->createTextNode('http://www.w3.org/2001/XMLSchema')
        );
        $facturacion->appendChild($xmlDoc->createAttribute("xmlns:xsi"))->appendChild(
            $xmlDoc->createTextNode('http://www.w3.org/2001/XMLSchema-instance')
        );
        //FIN ENCABEZADO DEL XML
        //DATOS DEL MENSAJE
        $facturacion->appendChild($xmlDoc->createElement("Clave", $datos['Clave']));
        $facturacion->appendChild($xmlDoc->createElement("NumeroCedulaEmisor", $datos['cedEmisor']));
        $facturacion->appendChild($xmlDoc->createElement("FechaEmisionDoc", $datos['FechaEmisionDoc']));
        $facturacion->appendChild($xmlDoc->createElement("Mensaje", $datos['Mensaje']));
        $facturacion->appendChild($xmlDoc->createElement("DetalleMensaje", $datos['DetalleMensaje']));
        $facturacion->appendChild($xmlDoc->createElement("MontoTotalImpuesto", $datos['MontoTotalImpuesto']));
        $facturacion->appendChild($xmlDoc->createElement("TotalFactura", $datos['TotalFactura']));
        $facturacion->appendChild($xmlDoc->createElement("NumeroCedulaReceptor", $datos['cedReceptor']));
        $facturacion->appendChild($xmlDoc->createElement("NumeroConsecutivo", $datos['NumeroConsecutivo']));
        //FIN DATOS MENSAJE
        $xmlDoc->formatOutput = true;
        $xml_sin_firma = $xmlDoc->saveXML();

        $fac = new Firmadocr();
        //$inXmlUrl debe de ser en Base64
        //$p12Url es un downloadcode previamente suministrado al subir el certificado en el modulo fileUploader -> subir_certif
        //Tipo es el tipo de documento
        // 01 FE
        //02 ND
        //03 NC
        //04 TE
        //05 06 07 Mensaje Receptor

        $vauchertype = $datos['vauchertype'];

        $p12Url = $archivo_certificado['archivo'];
        $pinP12 = $archivo_certificado['pass'];
        $inXml = base64_encode($xml_sin_firma);
        $tipoDocumento = str_pad($datos['vauchertype'], 2, "0", STR_PAD_LEFT);
        $Firmado = $fac->firmar($p12Url, $pinP12, $inXml, $tipoDocumento);
        if (!$Firmado['success']) {
            return $Firmado;
        }
        $xml_f64 = $Firmado['xml64'];
        // ************** hasta aqui
        return $xml_f64;
    }

    /* genera pdf */
    // https://mpdf.github.io/installation-setup/installation-v7-x.html
    // https://github.com/mpdf/mpdf
    public function gen_pdf($id)
    {

        $printer_type = null;
        $is_package_slip = false;
        $from_pos_screen = true;
        $invoice_layout_id = null;
        try {
            $sql = 'SELECT * FROM voucher_electronic WHERE transaction_id='.$id;
            $voucher_electronic = DB::select($sql);
            $hacernuevo = true;
            if (count($voucher_electronic) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'No existe ese Comprobante en cola.'
                ];
                return $output;
            }
            /*if ($voucher_electronic[0]->status==0){
                $output = [
                    'success' => false,
                    'msg' => 'No se ha enviado a hacienda.'
                ];
                return $output;
            }*/
            $business_id   = $voucher_electronic[0]->business_id;
            $location_id   = $voucher_electronic[0]->location_id;
            $transaction_id = $voucher_electronic[0]->transaction_id;
            $vauchertype   = $voucher_electronic[0]->vauchertype;
            $output = [
                'is_enabled' => false,
                'print_type' => 'browser',
                'html_content' => null,
                'printer_config' => [],
                'data' => []
            ];
            $transaction = Transaction::find($transaction_id);
            $business_details = $this->businessUtil->getDetails($business_id);
            $location_details = BusinessLocation::find($location_id);

            //Check if printing of invoice is enabled or not.
            //If enabled, get print type.
            $output['is_enabled'] = true;
            $invoice_layout_id = !empty($invoice_layout_id) ? $invoice_layout_id : $location_details->invoice_layout_id;
            $invoice_layout = $this->businessUtil->invoiceLayout($business_id, $location_id, $invoice_layout_id);

            //Check if printer setting is provided.
            $receipt_printer_type = is_null($printer_type) ? $location_details->receipt_printer_type : $printer_type;
            $receipt_details = $this->transactionUtil->getReceiptDetails($transaction_id, $location_id, $invoice_layout, $business_details, $location_details, $receipt_printer_type);
            $currency_details = [
                'symbol' => $business_details->currency_symbol,
                'thousand_separator' => $business_details->thousand_separator,
                'decimal_separator' => $business_details->decimal_separator,
            ];

            $receipt_details->currency = $currency_details;
            //$output['html_content'] = view('sale_pos.receipts.packing_slip', compact('receipt_details'))->render();

            $output['data'] = $receipt_details;
            $output['print_title'] = $receipt_details->invoice_no;
            $sigTipoDoc = "";
            switch ($vauchertype) {
                case 1:
                    $sigTipoDoc = "FE";
                    $layout = 'sale_pos.receipts.slim';
                    break;
                case 2:
                    $sigTipoDoc = "ND";
                    break;
                case 3:
                    $sigTipoDoc = "NC";
                    $layout = 'sell_return.receipt';
                    break;
                case 4:
                    $sigTipoDoc = "TE";
                    $layout = 'sale_pos.receipts.slim';
                    break;
                case 5:
                    $sigTipoDoc = "MR";
                    break;
                case 6:
                    $sigTipoDoc = "CPR";
                    break;
                case 7:
                    $sigTipoDoc = "RR";
                    break;
                case 8:
                    $sigTipoDoc = "FC";
                    break;
                case 9:
                    $sigTipoDoc = "FX";
                    break;
            }

            $receipt_details->css = true;

            $documento = str_pad($transaction_id, 10, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = "";
            $NumeroConsecutivo = $NumeroConsecutivo.str_pad($location_id, 3, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = $NumeroConsecutivo.str_pad($transaction->id_terminal, 5, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = $NumeroConsecutivo.str_pad($voucher_electronic[0]->vauchertype, 2, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = $NumeroConsecutivo.$documento;
            $nombre_pdf = DIR_PRO.'/public'.trim($location_details->ruta_xml).'/'.$NumeroConsecutivo.$sigTipoDoc.".pdf";
            if (file_exists($nombre_pdf)) {
                unlink($nombre_pdf);
            }
            //$bytes = file_put_contents('htmltxt2.html',$layout);
            $output['html_content'] = view($layout, compact('receipt_details'))->render();

            $max_eje = ini_get("max_execution_time");
            ini_set('max_execution_time', '350');
            $mpdf = new \Mpdf\Mpdf(['default_font_size' => 7]);  //['default_font_size' =>7,'default_font' => 'times']
            $mpdf->WriteHTML($output['html_content']);
            $mpdf->Output($nombre_pdf, 'F');
            ini_set('max_execution_time', $max_eje);

            $tabla = 'voucher_electronic ';
            $campos = '';
            $campos = $campos.'pdf="'.$nombre_pdf.'" ';
            $condicion = 'transaction_id='.$transaction_id;
            $sql = 'UPDATE '.$tabla.'SET '.$campos.'WHERE '.$condicion;
            $voucher_electronic = DB::select($sql);
            set_time_limit(20);

            $output = [
                'success' => true,
                'msg' => 'Pdf Transaction creada.'
            ];
            return $output;
        } catch (\Exception $e) {
            $msg = "File:" . $e->getFile(). "<br>Line:" . $e->getLine(). "<br>Message:" . $e->getMessage();
            $output = [
                'success' => 0,
                'msg' => $msg
            ];
            return $output;
            //
        }
    }
    //https://github.com/CRLibre/API_Hacienda/blob/dev/api/contrib/genXML/genXML.php
    public function VoucherElectronico($id, $vaucherElect_status, $vauchertype, $retorno_id = 0)
    {
        try {
            // Busca transaction
            $sql = 'SELECT * FROM transactions WHERE id='.$id;
            $transactions_datos = DB::select($sql);
            if (count($transactions_datos) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'No existe transacción con esos datos.'
                ];
                return $output;
            }
            $business_id      = $transactions_datos[0]->business_id;
            $location_id      = $transactions_datos[0]->location_id;
            $created_by       = $transactions_datos[0]->created_by;
            $contact_id       = $transactions_datos[0]->contact_id;
            $terminal         = $transactions_datos[0]->id_terminal;
            $return_parent_id = $transactions_datos[0]->return_parent_id;
            $type             = strtoupper($transactions_datos[0]->type);
            $num_documento    = $transactions_datos[0]->invoice_no;
            $transaction_fecha = strtotime($transactions_datos[0]->transaction_date);
            // Busca La Ubicación
            $sql = 'SELECT a.*, b.codigo as actividad_economica FROM business_locations AS a ';
            $sql = $sql.'LEFT JOIN actividades_economica AS b ON a.actividad_economica_id = b.id ';
            $sql = $sql.'WHERE a.id='.$location_id;
            $ubicacion_datos = DB::select($sql);
            if (count($ubicacion_datos) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'Transacción sin ubicación.'
                ];
                return $output;
            }
            $actividad_economica = $ubicacion_datos[0]->actividad_economica;
            if (empty($actividad_economica)) {
                $output = ['success' => false,
                    'msg' => 'La Ubicacón sin actividad ecónomica.'
                ];
                return $output;
            }
            $datos_config = '{"USERNAME":"'.trim($ubicacion_datos[0]->username)
                .'","CLIENT_ID":"'  .trim($ubicacion_datos[0]->cliente_id)
                .'","PASSWORD":"'   .trim($ubicacion_datos[0]->password)
                .'","LLAVECRIPTO":"'.trim($ubicacion_datos[0]->llavecripto)
                .'","RUTA_XML":"'   .trim($ubicacion_datos[0]->ruta_xml)
                .'","CLAVE_MAIL":"'.trim($ubicacion_datos[0]->clave_mail)
                .'"}';
            $config = json_decode($datos_config, true);
            $cedulaJuridi_emi = $ubicacion_datos[0]->cedula_juridica;
            $tipo_ident_emi = $ubicacion_datos[0]->tipo_ident;
            if (empty($cedulaJuridi_emi)) {
                $output = ['success' => false,
                    'msg' => 'La ubicación no tiene asignado un número de cedula jurídica.'
                ];
                return $output;
            }
            if (empty($tipo_ident_emi)) {
                $output = ['success' => false,
                    'msg' => 'La ubicación no tiene el tipo de cedula jurídica.'
                ];
                return $output;
            }
            if (empty($ubicacion_datos[0]->email)) {
                $output = ['success' => false,
                    'msg' => 'La ubicación no tiene correo.'
                ];
                return $output;
            }
            $country_nom = trim($ubicacion_datos[0]->country);
            if (empty($ubicacion_datos[0]->certificado)) {
                $output = [
                    'success' => false,
                    'msg' => 'El archivo '.$certificado.' no existe. debe copiarlo en '.'/public'.FILEENCRIPTADOS
                ];
                return $output;
            }
            $country_nom = trim($ubicacion_datos[0]->country);
            if (empty($ubicacion_datos[0]->barrio_id)) {
                $output = ['success' => false,
                    'msg' => 'Ubicación Local no tiene seleccionado el barrio.'
                ];
                return $output;
            }

            $tipo_ident_rec = 0;
            if ($vauchertype != 4) {
                $sql = 'SELECT * FROM contacts WHERE id='.$contact_id;
                $contact_datos = DB::select($sql);
                if (count($contact_datos) < 1) {
                    $output = [
                        'success' => false,
                        'msg' => 'Transacción sin cliente.'
                    ];
                    return $output;
                }
                $tipo_ident_rec = $contact_datos[0]->tipo_ident;
                $cedula_juridica_rec = $contact_datos[0]->cedula_juridica;
                if (empty($tipo_ident_rec)) {
                    $output = [
                        'success' => false,
                        'msg' => 'El cliente no tiene el tipo de identificación jurídica.'
                    ];
                    return $output;
                }
                if (empty($cedula_juridica_rec)) {
                    $output = ['success' => false,
                        'msg' => 'El cliente no tiene cedula Jurídica.'
                    ];
                    return $output;
                }
                if (empty($contact_datos[0]->email)) {
                    $output = ['success' => false,
                        'msg' => 'El cliente no tiene correo.'
                    ];
                    return $output;
                }
            }
            // Numero Consecutivo
            $documento = str_pad($id, 10, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = "";
            $NumeroConsecutivo = $NumeroConsecutivo.str_pad($location_id, 3, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = $NumeroConsecutivo.str_pad($terminal, 5, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = $NumeroConsecutivo.str_pad($vauchertype, 2, "0", STR_PAD_LEFT);
            $NumeroConsecutivo = $NumeroConsecutivo.$documento;
            // Verifica el tipo de Voucher
            $sigTipoDoc = "FE";
            $entrada = 1;
            switch ($vauchertype) {
                case 1:
                    $sigTipoDoc = "FE";
                    $desTipoDoc = "Factura Electronica";
                    break;
                case 2:
                    $sigTipoDoc = "ND";
                    $desTipoDoc = "Nota Debito Electrónica";
                    $entrada = 2;
                    break;
                case 3:
                    $sigTipoDoc = "NC";
                    $desTipoDoc = "Nota Credito Electrónica";
                    $entrada = 3;
                    break;
                case 4:
                    $sigTipoDoc = "TE";
                    $desTipoDoc = "Tiquete Electronico";
                    break;
                case 5:
                    $sigTipoDoc = "MR";
                    $desTipoDoc = "Mensaje Receptor";
                    break;
                case 6:
                    //  '06'=>'Confirmación parcial del Receptor',
                    $sigTipoDoc = "CPR";
                    $desTipoDoc = "Confirmación parcial del Receptor";
                    break;
                case 7:
                    // '07'=>'Rechazo del Receptor'
                    $sigTipoDoc = "RR";
                    $desTipoDoc = "Rechazo Receptor";
                    break;
                case 8:
                    $sigTipoDoc = "FC";
                    $desTipoDoc = "Factura Electrónica de Compra";
                    $entrada = 4;
                    break;
                case 9:
                    $sigTipoDoc = "FX";
                    $desTipoDoc = "Factura Electrónica de Exportacion";
                    break;
            }
            // si ya esta en cola
            $sql = 'SELECT * FROM voucher_electronic WHERE transaction_id='.$id; //.' and vauchertype='.$vauchertype.' and vaucherElect_status='.$vaucherElect_status
            $voucher_electronic = DB::select($sql);
            $hacernuevo = true;
            $clave = "";
            if (count($voucher_electronic) > 0) {
                if ($voucher_electronic[0]->status > 0) {
                    $output = [
                        'success' => false,
                        'msg' => 'ya fue enviado a hacienda. '
                    ];
                    return $output;
                }
                $vaucherElect_id = $voucher_electronic[0]->vaucherElect_id;
                $clave          = trim($voucher_electronic[0]->clave);
                $fecha_emi      = $voucher_electronic[0]->fechaEmision;
                $fnombre_xml    = $voucher_electronic[0]->xml;
                if (file_exists($fnombre_xml)) {
                    unlink($fnombre_xml);
                    //$xml_f=file_get_contents($fnombre_xml);
                }
                $hacernuevo = false;
            } else {
                $vaucherElect_id = crearVoucherid();
            }
            // Buscar Informacion Referencia si es tipo 2 o 3
            $Tipo_Doc = "";
            $cla_ve = "";
            $Fech_Emision = "";
            $Cod_igo = "";
            $Razon = "";
            //Razon
            $Razon = $transactions_datos[0]->razon;
            if ($vauchertype == 2 or $vauchertype == 3) {
                $campos = "a.id,a.transaction_date,a.razon,b.vauchertype,b.clave ";
                $tablas = "transactions as a LEFT JOIN voucher_electronic AS b ON a.id=b.transaction_id ";
                $sql = 'SELECT '.$campos.'FROM '.$tablas.'WHERE a.id='.$return_parent_id;
                $Referencia = DB::select($sql);
                if (count($Referencia) > 0) {
                    //TipoDoc
                    $Tipo_Doc = $Referencia[0]->vauchertype;
                    //Numero
                    $cla_ve  = $Referencia[0]->clave;
                    //FechaEmision
                    $fecha_referencia = strtotime($Referencia[0]->transaction_date);
                    $Fech_Emision    = date('Y-m-d', $fecha_referencia)."T".date('H:i:s', $fecha_referencia);
                    //Codigo
                    $Cod_igo = "01";
                }
            }
            //
            if ($vauchertype != 4) {
                if (empty($contact_id)) {
                    $output = ['success' => false,
                            'msg' => 'Transacción sin cliente.'
                    ];
                    return $output;
                }
            } else {
                $contact_id = 0;
            }
            $tablas = 'transaction_sell_lines AS a ';
            $tablas = $tablas.'INNER JOIN products AS b ON a.product_id=b.id ';
            $tablas = $tablas.'LEFT JOIN product_variations AS c ON a.product_id=c.product_id ';
            $tablas = $tablas.'LEFT JOIN variations AS d ON a.variation_id=d.id AND a.product_id=d.product_id ';
            $tablas = $tablas.'INNER JOIN units AS e ON b.unit_id=e.id ';
            $tablas = $tablas.'LEFT JOIN discounts AS f ON a.discount_id=f.id ';
            $tablas = $tablas.'LEFT JOIN tax_rates AS g ON a.tax_id = g.id ';
            switch ($entrada) {
                case 1:
                    $condicion = "a.transaction_id=".$id;
                    break;
                case 3:
                    $tablas = $tablas.'INNER JOIN transactions AS h ON h.return_parent_id=a.transaction_id ';
                    $condicion = "h.return_parent_id=".$retorno_id;
                    break;
            }
            $campos = "a.*, ";
            $campos = $campos."b.id as produc_id,b.typebymin,b.sku,b.name AS proname,b.typebymin,b.codigo_cabys,b.tax_name as cod_tax, ";
            $campos = $campos."c.name AS provarname, ";
            $campos = $campos."d.name AS varname,d.sub_sku, ";
            $campos = $campos."e.short_name,e.actual_name, ";
            $campos = $campos."f.name AS descuName, ";
            $campos = $campos."g.amount ";

            $sql = 'SELECT '.$campos.'FROM '.$tablas.'WHERE '.$condicion;
            $transaction_lines = DB::select($sql);

            if (count($transaction_lines) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'Transacción sin Productos.'
                ];
                return $output;
            }

            if (empty($transaction_lines[0]->descuName) && $transaction_lines[0]->line_discount_type == "percentage") {
                $output = [
                    'success' => false,
                    'msg' => 'Falta la descripción del descuento.'
                ];
                return $output;
            }
            //
            $sql = 'SELECT * FROM business WHERE id='.$business_id;
            $business_datos = DB::select($sql);
            if (count($business_datos) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'Transacción sin empresa.'
                ];
                return $output;
            }
            $currency_id = $business_datos[0]->currency_id;

            $certificado = DIR_PRO.'/public'.FILEENCRIPTADOS.'/'.trim($ubicacion_datos[0]->certificado);
            if (!file_exists($certificado)) {
                $output = [
                    'success' => false,
                    'msg' => 'El archivo '.$certificado.' no existe. debe copiarlo en '.'/public'.FILEENCRIPTADOS
                ];
                return $output;
            }
            // Busa Pais
            $sql = 'SELECT * FROM currencies WHERE country="'.$country_nom.'"';
            $country_dato = DB::select($sql);
            if (count($country_dato) < 1) {
                $output = [
                    'success' => false,
                    'msg' => 'La ubicación sin país.'
                ];
                return $output;
            }
            $pais = $country_dato[0]->id;
            $sql = 'SELECT * FROM currencies WHERE id='.$currency_id;
            $currency_datos = DB::select($sql);
            if (count($currency_datos) < 1) {
                $output = ['success' => false,
                    'msg' => 'La ubicación sin moneda.'
                ];
                return $output;
            }
            //    if ($vauchertype!=2 && $vauchertype!=3){
            $method = "";
            $sql = 'SELECT * FROM transaction_payments WHERE transaction_id='.$id;
            $payments_datos = DB::select($sql);
            //    }
            // creando XML
            $xmlDoc = new DOMDocument('1.0', 'UTF-8');
            libxml_use_internal_errors(true);
            $desTipoDoc = "";
            $sigTipoDoc = "";

            switch ($vauchertype) {
                case 1:
                    $sigTipoDoc = "FE";
                    $desTipoDoc = "Factura Electronica";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("FacturaElectronica"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronica')
                    );
                    break;
                case 2:
                    $sigTipoDoc = "ND";
                    $desTipoDoc = "Nota Debito Electrónica";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("NotaDebitoElectronica"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/notaDebitoElectronica')
                    );
                    break;
                case 3:
                    $sigTipoDoc = "NC";
                    $desTipoDoc = "Nota Credito Electrónica";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("NotaCreditoElectronica"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/notaCreditoElectronica')
                    );
                    break;
                case 4:
                    $sigTipoDoc = "TE";
                    $desTipoDoc = "Tiquete Electronico";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("TiqueteElectronico"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/tiqueteElectronico')
                    );
                    break;
                case 5:
                    $sigTipoDoc = "MR";
                    $desTipoDoc = "Mensaje Receptor";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("MensajeReceptor"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor')
                    );
                    break;
                case 6:
                    //  '06'=>'Confirmación parcial del Receptor',
                    $cabeza = '<MensajeReceptor ';
                    $this->name_space = '"https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor" ';
                    $cabeza = $cabeza.'xmlns='.$this->name_space;
                    $pies = '</MensajeReceptor>';
                    break;
                case 7:
                    // '07'=>'Rechazo del Receptor'
                    $sigTipoDoc = "RR";
                    $desTipoDoc = "Rechazo Receptor";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("RechazoReceptor"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/mensajeReceptor')
                    );
                    break;
                case 8:
                    $sigTipoDoc = "FC";
                    $desTipoDoc = "Factura Electrónica de Compra";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("facturaElectronicaCompra"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronicaCompra')
                    );
                    $entrada = 4;
                    break;
                case 9:
                    $sigTipoDoc = "FX";
                    $desTipoDoc = "Factura Electrónica de Exportacion";
                    $facturacion = $xmlDoc->appendChild($xmlDoc->createElement("facturaElectronicaExportacion"));
                    $facturacion->appendChild($xmlDoc->createAttribute("xmlns"))->appendChild(
                        $xmlDoc->createTextNode('https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/facturaElectronicaExportacion')
                    );
                    break;
            }

            $facturacion->appendChild($xmlDoc->createAttribute("xmlns:xsd"))->appendChild(
                $xmlDoc->createTextNode('http://www.w3.org/2001/XMLSchema')
            );
            $facturacion->appendChild($xmlDoc->createAttribute("xmlns:xsi"))->appendChild(
                $xmlDoc->createTextNode('http://www.w3.org/2001/XMLSchema-instance')
            );

            // clave

            $ano = strval(date("Y", $transaction_fecha));
            $ano = substr($ano, -2, 2);
            if ($vauchertype != 8) {
                $emisor = $ubicacion_datos[0]->cedula_juridica;
            } else {
                $emisor = $contact_datos[0]->cedula_juridica;
            }
            if (empty($clave)) {
                $clave = $clave."506";
                $clave = $clave.str_pad(date("d", $transaction_fecha), 2, "0", STR_PAD_LEFT);
                $clave = $clave.str_pad(date("m", $transaction_fecha), 2, "0", STR_PAD_LEFT);
                $clave = $clave.$ano;
                $clave = $clave.str_pad($emisor, 12, "0", STR_PAD_LEFT);
                $clave = $clave.str_pad($location_id, 3, "0", STR_PAD_LEFT); // tamaño 3 digitos correspondientes a la sucursal de donde proviene el documento
                $clave = $clave.str_pad($terminal, 5, "0", STR_PAD_LEFT);    //tamaño 5 digitos correspondientes al terminal o punto de venta
                $clave = $clave.str_pad($vauchertype, 2, "0", STR_PAD_LEFT);
                $clave = $clave.$documento;
                $clave = $clave.str_pad($vaucherElect_status, 1, "0", STR_PAD_LEFT); // tamaño 1 digito corresponde a la situacion del documento 1 Normal 2 Contingencia y 3 Sin internet
                $clave = $clave.substr($documento, 2, 10);
            }
            $facturacion->appendChild($xmlDoc->createElement("Clave", $clave));
            // Codigo de actividad
            $facturacion->appendChild($xmlDoc->createElement("CodigoActividad", str_pad($actividad_economica, 6, "0", STR_PAD_LEFT)));
            $facturacion->appendChild($xmlDoc->createElement("NumeroConsecutivo", $NumeroConsecutivo));
            //Fecha de Emision
            $fecha_emi = date('Y-m-d', $transaction_fecha)."T".date('H:i:s', $transaction_fecha);
            $facturacion->appendChild($xmlDoc->createElement("FechaEmision", $fecha_emi));
            //Emisor
            if ($vauchertype != 8) {
                $emisor_name  = $ubicacion_datos[0]->name;
                $emisor_tipo  = str_pad($ubicacion_datos[0]->tipo_ident, 2, "0", STR_PAD_LEFT);
                $emisor_Numero = $ubicacion_datos[0]->cedula_juridica;
            } else {
                $emisor_name  = $contact_datos[0]->name;
                $emisor_tipo  = str_pad($contact_datos[0]->tipo_ident, 2, "0", STR_PAD_LEFT);
                $emisor_Numero = $contact_datos[0]->cedula_juridica;
            }

            $emisor = $facturacion->appendChild($xmlDoc->createElement("Emisor"));
            $emisor->appendChild($xmlDoc->createElement("Nombre", $emisor_name));
            $ident_emisor = $emisor->appendChild($xmlDoc->createElement("Identificacion"));
            $ident_emisor->appendChild($xmlDoc->createElement("Tipo", $emisor_tipo));
            $ident_emisor->appendChild($xmlDoc->createElement("Numero", $emisor_Numero));
            if ($vauchertype != 8) {
                $ubicacion_emisor = $emisor->appendChild($xmlDoc->createElement("Ubicacion"));
                $ubicacion_emisor->appendChild($xmlDoc->createElement("Provincia", str_pad($ubicacion_datos[0]->provincia_id, 1, "0", STR_PAD_LEFT)));
                $ubicacion_emisor->appendChild($xmlDoc->createElement("Canton", str_pad($ubicacion_datos[0]->canton_id, 2, "0", STR_PAD_LEFT)));
                $ubicacion_emisor->appendChild($xmlDoc->createElement("Distrito", str_pad($ubicacion_datos[0]->distrito_id, 2, "0", STR_PAD_LEFT)));
                $ubicacion_emisor->appendChild($xmlDoc->createElement("Barrio", str_pad($ubicacion_datos[0]->barrio_id, 2, "0", STR_PAD_LEFT)));
                $ubicacion_emisor->appendChild($xmlDoc->createElement("OtrasSenas", $ubicacion_datos[0]->landmark));
                $telf_emisor = $emisor->appendChild($xmlDoc->createElement("Telefono"));
                $telf_emisor->appendChild($xmlDoc->createElement("CodigoPais", str_pad($ubicacion_datos[0]->codpais1, 3, "0", STR_PAD_LEFT)));
                $telf_emisor->appendChild($xmlDoc->createElement("NumTelefono", $ubicacion_datos[0]->mobile));
                if (!empty($ubicacion_datos[0]->alternate_number)) {
                    $fax_emisor = $emisor->appendChild($xmlDoc->createElement("Fax"));
                    $fax_emisor->appendChild($xmlDoc->createElement("CodigoPais", str_pad($ubicacion_datos[0]->codpais2, 3, "0", STR_PAD_LEFT)));
                    $fax_emisor->appendChild($xmlDoc->createElement("NumTelefono", $ubicacion_datos[0]->alternate_number));
                }
                $CorreoElectronico = $emisor->appendChild($xmlDoc->createElement("CorreoElectronico", $ubicacion_datos[0]->email));
            }
            //Receptor
            if ($vauchertype != 8) {
                if ($vauchertype != 4) {
                    $receptor_name  = $contact_datos[0]->name;
                    $receptor_tipo  = str_pad($contact_datos[0]->tipo_ident, 2, "0", STR_PAD_LEFT);
                    $receptor_Numero = $contact_datos[0]->cedula_juridica;
                    $receptor_email = $contact_datos[0]->email;
                }
            } else {
                $receptor_name  = $ubicacion_datos[0]->name;
                $receptor_tipo  = str_pad($ubicacion_datos[0]->tipo_ident, 2, "0", STR_PAD_LEFT);
                $receptor_Numero = $ubicacion_datos[0]->cedula_juridica;
                $receptor_email = $ubicacion_datos[0]->email;
            }

            if ($vauchertype != 4) {
                $Receptor = $facturacion->appendChild($xmlDoc->createElement("Receptor"));
                $Receptor->appendChild($xmlDoc->createElement("Nombre", $receptor_name));
                $ident_Receptor = $Receptor->appendChild($xmlDoc->createElement("Identificacion"));
                $ident_Receptor->appendChild($xmlDoc->createElement("Tipo", str_pad($receptor_tipo, 2, "0", STR_PAD_LEFT)));
                $ident_Receptor->appendChild($xmlDoc->createElement("Numero", $receptor_Numero));
                $CorreoElectronico = $Receptor->appendChild($xmlDoc->createElement("CorreoElectronico", $receptor_email));
            }
            //Encabezado
            $facturacion->appendChild($xmlDoc->createElement("CondicionVenta", str_pad($transactions_datos[0]->condicion_venta, 2, "0", STR_PAD_LEFT)));
            $facturacion->appendChild($xmlDoc->createElement("PlazoCredito", str_pad($transactions_datos[0]->plazoscredito, 1, "0", STR_PAD_LEFT)));

            //hasta un maximo de 4 medios de pago segun version 4.3 para los medios de pagos
            //if ($vauchertype!=2 && $vauchertype!=3){
            $nmethod = "99";
            if (count($payments_datos) < 1) {
                $facturacion->appendChild($xmlDoc->createElement("MedioPago", "01"));
            } else {
                $cuenta = 0;
                foreach ($payments_datos as $metodo_dato) {
                    $method = strtoupper($metodo_dato->method);
                    switch ($method) {   //purchase=compras
                        case 'CASH':   $nmethod = "01";
                            break;  //Efectivo
                        case 'CARD':   $nmethod = "02";
                            break;  //Tarjeta
                        case 'CHEQUE': $nmethod = "03";
                            break;  //Cheque
                        case 'BANK_TRANSFER': $nmethod = "04";
                            break;  //Transferencia Bancarias
                            //    case 'COLLECTED BY THIRD PARTIES': $nmethod="05"; break;  //Recaudado por terceros
                            //    case 'SIMPLE MOVIL': $nmethod="06"; break;  //Simple MOVIL
                        default: $nmethod = "99";
                            break; //Otros (se debe indicar el medio de pago en la representación gráfica)
                    }
                    $facturacion->appendChild($xmlDoc->createElement("MedioPago", $nmethod));
                    $cuenta = $cuenta + 1;
                    if ($cuenta == 4) {
                        break;
                    }
                }
            }
            //}
            // b.- Detalle de la mercancía o servicio prestado
            $linea = 0;
            $totalgravado = 0;
            $totalexento = 0;
            $totalventa  = 0;
            $totaldescuentos = 0;
            $totalimpuestos = 0;
            $totalMerGra = 0;
            $totalMerExen = 0;
            $totalSerGra = 0;
            $totalSerExen = 0;
            $totalVentaSinDes = 0;
            $totalVentaConDes = 0;
            $totalventaneta = 0;
            $detalle_servicio = $facturacion->appendChild($xmlDoc->createElement("DetalleServicio"));
            // repetir por cada producto
            foreach ($transaction_lines as $transaction_line) {
                if (empty($transaction_line->typebymin)) {
                    $output = ['success' => false,
                        'msg' => 'Hay productos sin clasificar el tipo por Hacienda.'
                    ];
                    return $output;
                }
                if (empty($transaction_line->codigo_cabys)) {
                    $output = ['success' => false,
                        'msg' => 'Hay productos sin codigo de bienes y servicio de Hacienda.'
                    ];
                    return $output;
                }
                $linea = $linea + 1;
                $linea_detalle = $detalle_servicio->appendChild($xmlDoc->createElement("LineaDetalle"));
                $linea_detalle->appendChild($xmlDoc->createElement("NumeroLinea", str_pad($linea, 2, "0", STR_PAD_LEFT)));

                $codigoB = trim($transaction_line->codigo_cabys);
                $codigoB = str_replace('', '.', $codigoB);
                /*$codig oB=str_replace("-",'',$cod igoB);
                $codi goB=str_pad($codi goB,13, " ", STR_PAD_LEFT);     */

                $linea_detalle->appendChild($xmlDoc->createElement("Codigo", $codigoB));
                $codigo = $linea_detalle->appendChild($xmlDoc->createElement("CodigoComercial"));
                $codigo->appendChild($xmlDoc->createElement("Tipo", str_pad(4, 2, "0", STR_PAD_LEFT)));
                $codigo->appendChild($xmlDoc->createElement("Codigo", $transaction_line->product_id));

                $quantity = $transaction_line->quantity;
                if ($vauchertype == 3) {
                    $quantity = $transaction_line->quantity_returned;
                }

                $cantidad = $transaction_line->quantity;
                $linea_detalle->appendChild($xmlDoc->createElement("Cantidad", number_format($cantidad, 3)));
                $linea_detalle->appendChild($xmlDoc->createElement("UnidadMedida", $transaction_line->short_name));
                $des_detalle = "";
                if ($transaction_line->proname != 'DUMMY') {
                    $des_detalle = $des_detalle.$transaction_line->proname   .' ';
                }
                if ($transaction_line->provarname != 'DUMMY') {
                    $des_detalle = $des_detalle.$transaction_line->provarname.' ';
                }
                if ($transaction_line->varname != 'DUMMY') {
                    $des_detalle = $des_detalle.$transaction_line->varname   .' ';
                }
                if ($transaction_line->sub_sku != 'DUMMY') {
                    $des_detalle = $des_detalle.$transaction_line->sub_sku   .' ';
                }

                $montoAnteDescuento = $transaction_line->unit_price_before_discount;
                $monto_total = $montoAnteDescuento * $cantidad;

                $linea_detalle->appendChild($xmlDoc->createElement("Detalle", $des_detalle));
                $linea_detalle->appendChild($xmlDoc->createElement("PrecioUnitario", number_format($montoAnteDescuento, 5, '.', '')));
                $linea_detalle->appendChild($xmlDoc->createElement("MontoTotal", number_format($monto_total, 5, '.', '')));
                $totaldespro = 0;

                $NaturaezaDescuento = "";
                $CodigoDescuento = 0;
                $MontoDescuento = 0;
                $porcentajeDescuento = 0;

                // calculando los descuentos
                if ($transaction_line->line_discount_type == 'percentage') {
                    if (!empty($transaction_line->descuName)) {
                        $NaturaezaDescuento = $transaction_line->descuName;
                    }
                    if (!empty($transaction_line->discount_id)) {
                        $CodigoDescuento = $transaction_line->discount_id;
                    }
                    if (!empty($transaction_line->line_discount_amount)) {
                        $porcentajeDescuento = $transaction_line->line_discount_amount;
                    }
                    $montoDescuento = ($montoAnteDescuento * $porcentajeDescuento) / 100;
                    $montoDesDescuento = ($montoAnteDescuento - $montoDescuento);
                    $subtotal = $montoDesDescuento * $cantidad;
                    $totaldescuentos = $totaldescuentos + ($montoDescuento * $cantidad);
                    $totalVentaConDes = $totalVentaConDes + $subtotal;

                    $Descuento = $linea_detalle->appendChild($xmlDoc->createElement("Descuento"));
                    $Descuento->appendChild($xmlDoc->createElement("MontoDescuento", number_format($montoDescuento * $cantidad, 5, '.', '')));
                    //$Descuento->appendChild($xmlDoc->createElement("CodigoDescuento",str_pad($CodigoDescuento,3,"0", STR_PAD_LEFT)));
                    $Descuento->appendChild($xmlDoc->createElement("NaturalezaDescuento", $NaturaezaDescuento));
                } else {
                    $montoDesDescuento = $montoAnteDescuento;
                    $subtotal = $montoAnteDescuento * $cantidad;
                    $totalVentaSinDes = $totalVentaSinDes + $subtotal;
                }

                $linea_detalle->appendChild($xmlDoc->createElement("SubTotal", number_format($subtotal, 5, '.', '')));

                //$impuesto=(($subtotal*$transaction_line->item_tax)/100);

                $tarifa = $transaction_line->amount;
                $impuesto_n = ($montoDesDescuento * $tarifa / 100) * $cantidad;

                $tipebym = $transaction_line->typebymin;
                if ($impuesto_n > 0) {
                    $totalimpuestos = $totalimpuestos + $impuesto_n;
                    switch ($tipebym) {
                        case 1:
                            $totalMerGra = $totalMerGra + ($montoAnteDescuento * $cantidad);
                            break;
                        case 2:
                            $totalSerGra = $totalSerGra + ($montoAnteDescuento * $cantidad);
                            break;
                    }
                } else {
                    switch ($tipebym) {
                        case 1:
                            $totalMerExen = $totalMerExen + ($montoAnteDescuento * $cantidad);
                            break;
                        case 2:
                            $totalSerExen = $totalSerExen + ($montoAnteDescuento * $cantidad);
                            break;
                            /*default:
                                echo "i no es igual a 0, 1 ni 2";*/
                    }
                }
                $totallinea    = $subtotal + $impuesto_n;
                $totalventaneta = $totalventaneta + $subtotal;
                $totalventa    = $totalventa + ($montoAnteDescuento * $cantidad);
                /*if ($transaction_line->tax_id==7)
                    $linea_detalle->appendChild($xmlDoc->createElement("BaseImponible",number_format($subtotal,5,'.',''))); */
                $tax_id = $transaction_line->tax_id;
                if (!empty($tax_id)) {
                    $cod_tax = str_pad($transaction_line->cod_tax, 2, "0", STR_PAD_LEFT);
                    $tax_id = str_pad($tax_id, 2, "0", STR_PAD_LEFT);
                    $tarifa = number_format($tarifa, 2, '.', '');
                    $impuesto_n = number_format($impuesto_n, 5, '.', '');
                    $impuesto = $linea_detalle->appendChild($xmlDoc->createElement("Impuesto"));
                    $impuesto->appendChild($xmlDoc->createElement("Codigo", $cod_tax));
                    $impuesto->appendChild($xmlDoc->createElement("CodigoTarifa", $tax_id));
                    $impuesto->appendChild($xmlDoc->createElement("Tarifa", $tarifa));
                    $impuesto->appendChild($xmlDoc->createElement("Monto", $impuesto_n));
                } else {
                    $impuesto_n = 0;
                }
                $linea_detalle->appendChild($xmlDoc->createElement("MontoTotalLinea", number_format($totallinea, 5, '.', '')));
            }
            // fin repetir
            // Resumen Factura
            $resumen_factura = $facturacion->appendChild($xmlDoc->createElement("ResumenFactura"));
            $codtm = $resumen_factura->appendChild($xmlDoc->createElement("CodigoTipoMoneda"));
            $codtm->appendChild($xmlDoc->createElement("CodigoMoneda", $currency_datos[0]->code));
            $codtm->appendChild($xmlDoc->createElement("TipoCambio", $transactions_datos[0]->exchange_rate));


            $resumen_factura->appendChild($xmlDoc->createElement("TotalServGravados", number_format($totalSerGra, 5, '.', '')));
            $resumen_factura->appendChild($xmlDoc->createElement("TotalServExentos", number_format($totalSerExen, 5, '.', '')));
            $resumen_factura->appendChild($xmlDoc->createElement("TotalMercanciasGravadas", number_format($totalMerGra, 5, '.', '')));
            $resumen_factura->appendChild($xmlDoc->createElement("TotalMercanciasExentas", number_format($totalMerExen, 5, '.', '')));
            $totalgravado = $totalSerGra + $totalMerGra;
            $resumen_factura->appendChild($xmlDoc->createElement("TotalGravado", number_format($totalgravado, 5, '.', '')));
            $totalexento = $totalSerExen + $totalMerExen;
            //$$totalventa =$totalgravado+$totalexento;
            $resumen_factura->appendChild($xmlDoc->createElement("TotalExento", number_format($totalexento, 5, '.', '')));
            $resumen_factura->appendChild($xmlDoc->createElement("TotalVenta", number_format($totalventa, 5, '.', '')));
            $resumen_factura->appendChild($xmlDoc->createElement("TotalDescuentos", number_format($totaldescuentos, 5, '.', '')));
            //$totalventaneta=$totalventa;
            $totalventaneta = $totalventa - $totaldescuentos;
            $resumen_factura->appendChild($xmlDoc->createElement("TotalVentaNeta", number_format($totalventaneta, 5, '.', '')));
            $resumen_factura->appendChild($xmlDoc->createElement("TotalImpuesto", number_format($totalimpuestos, 5, '.', '')));
            $totalventacop = $totalventaneta + $totalimpuestos;
            $resumen_factura->appendChild($xmlDoc->createElement("TotalComprobante", number_format($totalventacop, 5, '.', '')));

            /*
            <TotalServExonerado>0</TotalServExonerado>
            <TotalMercExonerada>0</TotalMercExonerada>
            <TotalExonerado>0</TotalExonerado>
            <TotalIVADevuelto>0</TotalIVADevuelto>
            <TotalOtrosCargos>0</TotalOtrosCargos>
            */
            // Llenar informacion de Referencia
            if ($vauchertype == 2 or $vauchertype == 3) {
                $InformacionReferencia = $facturacion->appendChild($xmlDoc->createElement("InformacionReferencia"));
                $InformacionReferencia->appendChild($xmlDoc->createElement('TipoDoc', str_pad($Tipo_Doc, 2, "0", STR_PAD_LEFT)));
                $InformacionReferencia->appendChild($xmlDoc->createElement('Numero', $cla_ve));
                $InformacionReferencia->appendChild($xmlDoc->createElement('FechaEmision', $Fech_Emision));
                $InformacionReferencia->appendChild($xmlDoc->createElement('Codigo', $Cod_igo));
                $InformacionReferencia->appendChild($xmlDoc->createElement('Razon', $Razon));
            }
            // Mas infomación
            $Otros = $facturacion->appendChild($xmlDoc->createElement("Otros"));
            $Otros->appendChild($xmlDoc->createElement(
                'OtroTexto',
                "Tipo de Documento: ".$desTipoDoc.", ".
                    "Numero de operacion: ".$transactions_datos[0]->id.", ".
                    "Fecha de Emision: ".date('Y-m-d', $transaction_fecha).", ".
                    "Codigo: ".$transactions_datos[0]->invoice_no.". "
            ));

            /*
            $InformacionRe = $facturacion->appendChild($xmlDoc->createElement("InformacionReferencia"));
            $InformacionRe->appendChild($xmlDoc->createElement("TipoDoc",str_pad($vauchertype,2,"0", STR_PAD_LEFT)));
            $InformacionRe->appendChild($xmlDoc->createElement("NumeroOperacion" ,); //$this->xmlCompleto['InformacionReferencia']['Numero']
            $InformacionRe->appendChild($xmlDoc->createElement("FechaEmision",)); //$this->xmlCompleto['InformacionReferencia']['FechaEmision']
            $InformacionRe->appendChild($xmlDoc->createElement("Codigo",$transactions_datos[0]->invoice_no)); // $this->xmlCompleto['InformacionReferencia']['Codigo']
            */
            if (!empty($transactions_datos->razon)) {
                $InformacionRe->appendChild($xmlDoc->createElement("Razon", $transactions_datos[0]->razon));
            } // $this->xmlCompleto['InformacionReferencia']['Razon']

            $xml_sin_firma = $xmlDoc->saveXML();
            // firmar xml
            $fac = new Firmadocr();
            //$inXmlUrl debe de ser en Base64
            //$p12Url es un downloadcode previamente suministrado al subir el certificado en el modulo fileUploader -> subir_certif
            //Tipo es el tipo de documento
            // 01 FE
            //02 ND
            //03 NC
            //04 TE
            //05 06 07 Mensaje Receptor
            $p12Url = $certificado;
            $pinP12 = $config['LLAVECRIPTO'];
            $inXml = base64_encode($xml_sin_firma);
            $tipoDocumento = str_pad($vauchertype, 2, "0", STR_PAD_LEFT);
            $Firmado = $fac->firmar($p12Url, $pinP12, $inXml, $tipoDocumento);
            if (!$Firmado['success']) {
                return $Firmado;
            }
            $xml_f64 = $Firmado['xml64'];

            $fnombre_xml = DIR_PRO.'/public'.$config['RUTA_XML'].'/'.$NumeroConsecutivo.$vaucherElect_status.$sigTipoDoc.'.xml';
            if (file_exists($fnombre_xml)) {
                unlink($fnombre_xml);
            }
            $xml_f = base64_decode($xml_f64);
            file_put_contents($fnombre_xml, $xml_f);

            // Verificar acceso a Hacienda
            $token = token($datos_config);
            $status = 0;
            if (isset($token->access_token)) {
                // Enviar datos a hacienda
                $access_token = $token->access_token;
                $datos = new \stdClass();
                $datos->clave = "".$clave;
                $datos->fecha = "".$fecha_emi;
                $datos->emisor = array(
                    "tipoIdentificacion" => ''.$tipo_ident_emi,
                    "numeroIdentificacion" => ''.$cedulaJuridi_emi
                );
                if ($vauchertype != 4) {
                    $datos->receptor = array(
                        'tipoIdentificacion' => $tipo_ident_rec,
                        'numeroIdentificacion' => $cedula_juridica_rec
                    );
                }
                $datos->comprobanteXml = $xml_f64;
                $datosj = json_encode($datos, true);

                // activar
                $respuesta['Status'] = false;
                $respuesta = enviar($datosj, $access_token, $config);
                $text = [];
                if (isset($respuesta['text'])) {
                    $text = $respuesta['text'];
                }
                $stado = $respuesta['Status'];
                logout($access_token, $datos_config);

                // poner comentario
                $len_text = count($text);
                $salida_text = "";
                for ($i = 0; $i < $len_text; ++$i) {
                    $salida_text = $salida_text.$text[$i];
                }
                $salida_text = $salida_text.$respuesta['Status'];
                $i = 1;
                do {
                    $fnombre_e = DIR_PRO.'/public'.$config['RUTA_XML'].'/'.$NumeroConsecutivo.$vaucherElect_status.$sigTipoDoc.'-M'.$i.'.txt';
                    if (!file_exists($fnombre_e)) {
                        file_put_contents($fnombre_e, $text);
                        break;
                    }
                    $i = $i + 1;
                } while ($i > 0);
                // hasta aqui quitar
                // verificar estado de envio
                //$stado=200;
                if ($stado == 200 || $stado == 202) {
                    $output = [
                        'success' => true,
                        'msg' => 'El archivo '.$fnombre_xml.'<br>fue creado y enviado con exito para Hacienda. '
                    ];
                    $status = 1;
                } else {
                    $output = [
                        'success' => true,
                        'msg' => 'El archivo '.$fnombre_xml.'<br>No se pudo enviar para Hacienda trata más tarde. '
                    ];
                    $status = 6;
                    $vaucherElect_status = 0;
                }
            } else {
                $output = [
                    'success' => false,
                    'msg' => 'No hay Conexión con Hacienda o hay problema de red o con la clave.'
                ];
            }
            $tabla = 'voucher_electronic ';
            // Guardar en colamkiki
            if ($hacernuevo) {
                $campos = '(   business_id  ,transaction_id,     vaucherElect_id,     vaucherElect_status,     vauchertype,               xml,       NumeroConsecutivo,    fechaEmision,     location_id,       clave,      TotalFactura, MontoTotalImpuesto,     status) ';
                $valor = "(".$business_id.",".$id.       ",".$vaucherElect_id.",".$vaucherElect_status.",".$vauchertype.",'".$fnombre_xml."','".$NumeroConsecutivo."','".$fecha_emi."',".$location_id.",'".$clave."',".$totalventacop.",".$totalimpuestos.",".$status.")";
                $sql   = 'INSERT INTO '.$tabla.$campos.' VALUES '.$valor;
            } else {
                $campos = "";
                $campos = $campos.'vaucherElect_status='.$vaucherElect_status.',';
                $campos = $campos.'xml="'.$fnombre_xml.'",';
                $campos = $campos.'xml2="",';
                $campos = $campos.'pdf="",';
                $campos = $campos.'status='.$status;
                $sql   = 'UPDATE '.$tabla.' SET '.$campos.' WHERE transaction_id='.$id;
            }
            $voucher_electronic = DB::select($sql);
            return $output;
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
            $output = [
                'success' => false,
                'msg' => "File:" . $e->getFile(). "<br>Line:" . $e->getLine(). "<br>Message:" . $e->getMessage() // "Error: " . $e->getMessage()
            ];
            return $output;
        }
    }
    public function ver_archivoxml($id)
    {
        $campos = "a.*,b.username,b.cliente_id,b.password,b.llavecripto,b.ruta_xml,b.clave_mail ";
        $sql = 'SELECT '.$campos.'FROM voucher_electronic AS a INNER JOIN business_locations AS b ON a.location_id=b.id WHERE a.id='.$id;
        $voucher_electronic = DB::select($sql);
        if (count($voucher_electronic) == 1) {
            $archivo = basename($voucher_electronic[0]->xml);
            if (!empty($archivo)) {
                $fnombre_xml = env('APP_URL').trim($voucher_electronic[0]->ruta_xml).'/'.$archivo;
                echo '<script> window.open("'.$fnombre_xml.'") </script>';
                //echo '<script> window.open("'.$fnombre_xml.'","_blank") </script>';                 //        location.href= "consulta.php";
            } else {
                $susesos = [
                    'success' => false,
                    'msg'     => "No ha sido enviado a hacienda."
                ];
                return $susesos;
            }
        }

    }
    public function ver_archivoxml2($id)
    {
        $campos = "a.*,b.username,b.cliente_id,b.password,b.llavecripto,b.ruta_xml,b.clave_mail ";
        $sql = 'SELECT '.$campos.'FROM voucher_electronic AS a INNER JOIN business_locations AS b ON a.location_id=b.id WHERE a.id='.$id;
        $voucher_electronic = DB::select($sql);
        if (count($voucher_electronic) == 1) {
            $archivo = basename($voucher_electronic[0]->xml2);
            if (!empty($archivo)) {
                $fnombre_xml = env('APP_URL').trim($voucher_electronic[0]->ruta_xml).'/'.$archivo;
                echo '<script> window.open("'.$fnombre_xml.'") </script>';
                //echo '<script> window.open("'.$fnombre_xml.'","_blank") </script>';                 //        location.href= "consulta.php";
            } else {
                $susesos = [
                    'success' => false,
                    'msg'     => "No ha sido enviado a hacienda."
                ];
                return $susesos;
            }
        }

    }
    public function ver_archivopdf($id)
    {
        $campos = "a.*,b.username,b.cliente_id,b.password,b.llavecripto,b.ruta_xml,b.clave_mail ";
        $sql = 'SELECT '.$campos.'FROM voucher_electronic AS a INNER JOIN business_locations AS b ON a.location_id=b.id WHERE a.id='.$id;
        $voucher_electronic = DB::select($sql);
        if (count($voucher_electronic) == 1) {
            $archivo = basename($voucher_electronic[0]->pdf);
            if (!empty($archivo)) {
                $fnombre_xml = env('APP_URL').trim($voucher_electronic[0]->ruta_xml).'/'.$archivo;
                echo '<script> window.open("'.$fnombre_xml.'") </script>';
                //echo '<script> window.open("'.$fnombre_xml.'","_blank") </script>';                 //        location.href= "consulta.php";
            } else {
                $susesos = [
                    'success' => false,
                    'msg'     => "No ha sido enviado a hacienda."
                ];
                return $susesos;
            }
        }

    }
    public function verifica_estado($transaction_id)
    {
        $campos = "a.*,b.username,b.cliente_id,b.password,b.llavecripto,b.ruta_xml,b.clave_mail ";
        $sql = 'SELECT '.$campos.'FROM voucher_electronic AS a INNER JOIN business_locations AS b ON a.location_id=b.id WHERE a.transaction_id='.$transaction_id;
        $electronic = DB::select($sql);
        if (count($electronic) == 1) {
            $datos_config = '{"USERNAME":"'.trim($electronic[0]->username)
                .'","CLIENT_ID":"'  .trim($electronic[0]->cliente_id)
                .'","PASSWORD":"'   .trim($electronic[0]->password)
                .'","LLAVECRIPTO":"'.trim($electronic[0]->llavecripto)
                .'","RUTA_XML":"'   .trim($electronic[0]->ruta_xml)
                .'","CLAVE_MAIL":"'.trim($electronic[0]->clave_mail)
                .'"}';

            $respuesta = Generar_Token($datos_config, 'I');
            /*
            echo "<br><br><br>".$respuesta['Status']."<br><br><br>";
            print_r($respuesta);
            echo "<br><br><br>".$respuesta['Status'];
            */
            $stado = $respuesta['Status'];
            $token = $respuesta['text'];
            if ($stado == 200 || $stado == 202) {
            } else {
                $mens = "Error del servidor no esperado";
                if (isset($token->{'error_description'})) {
                    $mens = $token->{'error_description'};
                }
                $output = [
                    'success' => false,
                    'archivo' => '',
                    'msg' => $mens
                ];
                return $output;
            }

            $token = $respuesta['text'];
            $access_token = "";
            if (isset($token->{'access_token'})) {
                $access_token = $token->{'access_token'};
            }
            if (!empty($access_token)) {
                $respuesta = consulta_oper(trim($electronic[0]->clave), trim($electronic[0]->cliente_id), $access_token);
                $response = $respuesta['response'];
                $largo = strlen($response);
                $pos   = strpos($response, '{');
                $hasta = $largo - $pos;
                $xml_json = substr($response, -$hasta);
                $consult = json_decode($xml_json);
                //print_r($consult);
                //echo "<br><br><br>".$consult->{'respuesta-xml'};
                //echo base64_decode($consult->{'respuesta-xml'});
                //$mensaje=$consult->{'respuesta-xml'};
                //echo "<br><br><br>".$consult->{'ind-estado'};

                if (isset($consult->{'ind-estado'})) {
                    $sigTipoDoc = 'RH';
                    $respuesta_xml = DIR_PRO.'/public'.trim($electronic[0]->ruta_xml).'/'.trim($electronic[0]->NumeroConsecutivo).$sigTipoDoc.'.xml';
                    if (file_exists($respuesta_xml)) {
                        unlink($respuesta_xml);
                    }
                    $status = $electronic[0]->status;
                    $estado = $consult->{'ind-estado'};

                    $output = [
                        'success' => true,
                        'archivo' => $respuesta_xml,
                        'msg'     => 'consulta hecha.'
                    ];
                    switch ($estado) {
                        case 'recibido':
                            $status = 2;
                            break;
                        case 'aceptado':
                            $status = 3;
                            break;
                        case 'rechazado':
                            /*$output = [
                                'success' => false,
                                'archivo' =>'',
                                'msg' => 'Factura rechazada.'
                            ];*/
                            $status = 4;
                            break;
                        case 'procesando':
                            $status = 5;
                            break;
                        case 'error':
                            $output = [
                                'success' => false,
                                'archivo' => '',
                                'msg' => 'Error en el xml.'
                            ];
                            $status = 6;
                            break;
                    }

                    $respuesta_datos = "";
                    if (isset($consult->{'respuesta-xml'})) {
                        $respuesta_datos = $consult->{'respuesta-xml'};
                    }

                    $tabla = "voucher_electronic";
                    $campos = "";
                    $campos = $campos.'xml_respuesta="'.$respuesta_xml.'",';
                    $campos = $campos.'status='.$status;
                    $sql   = 'UPDATE '.$tabla.' SET '.$campos.' WHERE transaction_id='.$transaction_id;
                    DB::select($sql);
                    file_put_contents($respuesta_xml, base64_decode($respuesta_datos));

                } else {
                    $output = [
                        'success' => false,
                        'archivo' => '',
                        'msg' => 'No hay Conexión con Hacienda o hay problema de red o con la clave.'
                    ];
                }
                logout($access_token, $datos_config);
                return $output;
            } else {
                $output = [
                    'success' => false,
                    'archivo' => '',
                    'msg' => 'No hay Conexión con Hacienda o hay problema de red o con la clave.'
                ];
                return $output;
            }

        }
    }
    public function consulta_elec($transaction_id)
    {
        $campos = "a.*,b.username,b.cliente_id,b.password,b.llavecripto,b.ruta_xml,b.clave_mail ";
        $sql = 'SELECT '.$campos.'FROM voucher_electronic AS a INNER JOIN business_locations AS b ON a.location_id=b.id WHERE a.transaction_id='.$transaction_id; //xml_respuesta is not null and
        $electronic = DB::select($sql);
        if (count($electronic) == 1) {
            $respuesta_xml = $electronic[0]->xml_respuesta;
            $verificado = $this->verifica_estado($transaction_id);
            $respuesta_xml = $verificado['archivo'];
            if (!empty($respuesta_xml)) {
                $archivo = basename($respuesta_xml);
                $respuesta_xml = env('APP_URL').trim($electronic[0]->ruta_xml).'/'.trim($archivo);
                echo '<script> window.open("'.$respuesta_xml.'") </script>';
                $output = [
                    'success' => true,
                    'msg' => 'Verificación enviada al explorador.'
                ];
            }
            if ($verificado['success'] === false) {
                $output = $verificado;
            }
        } else {
            $output = [
                'success' => false,
                'msg' => 'No hay Voucher Electrónico para consultar.'
            ];
        }
        $msg = $output['msg'];
        return view('voucher_electronic.mensaje')
        ->with(compact(
            'msg'
        ));
    }
}
//
function encrypt_decrypt($action, $string)
{
    $output = false;

    $encrypt_method = "AES-256-CBC";
    $secret_key = 'secret key';
    $secret_iv = 'secret iv';

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if ($action == 'encrypt') {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    } elseif ($action == 'decrypt') {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}
// https://github.com/CRLibre/API_Hacienda/blob/dev/api/contrib/token/mhToken.php
function Generar_Token($datos_config, $accion)
{
    $config    = json_decode($datos_config, true);
    $client_id = trim($config['CLIENT_ID']);
    $username  = trim($config['USERNAME']);
    $password  = trim($config['PASSWORD']);
    $client_secret = "";
    if ($accion == 'I') {
        $grant_type = 'password';
        $data = array(
            'client_id'         => $client_id,
            'client_secret'     => $client_secret,
            'grant_type'        => $grant_type,
            'username'          => $username,
            'password'          => $password
        );
    }
    /*if ($accion=='R'){
        $archivotok=DIR_PRO.'/app/Http/Controllers/refresh_token.tok';
        if (file_exists($archivotok)){
            $refresh_token=file_get_contents($archivotok);
        }else{
            return "Archivo de refresh token no existe";
        }
        $grant_type='refresh_token';
        $data = array(
            'client_id'     => $client_id,
            'client_secret' => $client_secret,
            'grant_type'    => $grant_type,
            'refresh_token' => $refresh_token
        );
    }*/

    $url = '';
    if ($client_id == 'api-stag') {
        $url = URLTOKENSTAG;
    } elseif ($client_id == 'api-prod') {
        $url = URLTOKENPROD;
    }
    $url = $url."token";

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_HEADER, 'Content-Type: application/x-www-form-urlencoded');
    $data = http_build_query($data);
    //$data = rtrim($data, '&');
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    //grace_debug("JSON: ".$data);
    $respuesta  = curl_exec($curl);
    $status1    = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        $arrayResp = array(
            "Status"    => $status1,
            "text"      => $err
        );
        return $arrayResp;
    } else {
        $arrayResp = array(
            "Status"    => $status1,
            "text"      => json_decode($response)
        );
        return $arrayResp;
    }
}
//
function consulta_oper($clave, $client_id, $token)
{
    if ($clave == "" || strlen($clave) == 0) {
        return "La clave no puede ser en blanco";
    }
    $url = null;
    if ($client_id == 'api-stag') {
        $url = URLCOMSTAG;
    } elseif ($client_id == 'api-prod') {
        $url = URLCOMPROD;
    }
    $url = $url . "recepcion/";
    $curl   = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL             => $url . $clave,
        CURLOPT_RETURNTRANSFER  => true,
        CURLOPT_HEADER          => 1,
        CURLOPT_ENCODING        => "",
        CURLOPT_MAXREDIRS       => 10,
        CURLOPT_SSLVERSION      => CURL_SSLVERSION_TLSv1_2,
        CURLOPT_TIMEOUT         => 45,
        CURLOPT_CUSTOMREQUEST   => "GET",
        CURLOPT_HTTPHEADER      => array(
            "Authorization: ".$token,
            "Cache-Control: no-cache",
            "Content-Type: application/x-www-form-urlencoded"
        )
    ));
    $response   = curl_exec($curl);
    $status1     = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err        = curl_error($curl);
    $info = curl_getinfo($curl, CURLOPT_HTTPHEADER);
    curl_close($curl);

    if ($err) {
        $responde = [
            'status' => $status1,
            'response' => "cURL Error #:" . $err . " Info: " . $info
        ];
        return $responde;
    } else {
        $responde = [
            'status' => $status1,
            'response' => $response
        ];
        return $responde;
    }

}
//
function EnviarComElecClient($id)
{
    $datos = cuerpoEnvioCliente($id);
    if ($datos['success'] == true) {
        $mensaje = Enviar_Correo($datos['data']);
        $msg = $mensaje['msg'];
    } else {
        $msg = $datos['msg'];
    }
    return view('voucher_electronic.mensaje')
    ->with(compact(
        'msg'
    ));
}
//
function cuerpoEnvioCliente($id)
{
    try {
        /// datos de envio
        $tablas = "voucher_electronic AS a ";
        $tablas = $tablas."INNER JOIN business_locations AS b ON a.business_id = b.business_id AND a.location_id = b.id ";
        $tablas = $tablas."INNER JOIN transactions AS c ON a.transaction_id = c.id ";
        $tablas = $tablas."LEFT JOIN contacts AS d ON c.contact_id = d.id ";
        $tablas = $tablas."INNER JOIN business AS e ON a.business_id = e.id ";
        $datos = "";
        $datos = $datos."a.*,e.logo, ";
        $datos = $datos."b.name AS name_emi,b.email AS email_emi,b.codpais1 as cod_pais_emi,b.mobile as telefono_emi,b.cedula_juridica,b.website, ";
        $datos = $datos."b.certificado,b.llavecripto,b.username,b.password,b.cliente_id,b.ruta_xml,b.clave_mail, ";
        $datos = $datos."c.invoice_no,c.tax_amount,c.final_total,c.total_before_tax, ";
        $datos = $datos."d.name as name_rec,d.email AS email_rec,d.cedula_juridica as cedula_rec ";
        $sql = "SELECT ".$datos."FROM ".$tablas."WHERE a.transaction_id='".$id."'";
        $voucher_electronic = DB::select($sql);
        if (count($voucher_electronic) < 1) {
            $output = [
                'success' => false,
                'data' => '',
                'msg' => 'No existe ese voucher electronico.'
            ];
            return $output;
        }
        if ($voucher_electronic[0]->vauchertype != 4) {
            if (empty($voucher_electronic[0]->email_rec)) {
                $output = [
                    'success' => false,
                    'data' => '',
                    'msg' => 'No tiene un email receptor.'
                ];
            }
        }
        /*if ($voucher_electronic[0]->vaucherElect_status==7){
            $output = ['success' => false,
                'msg' => 'Correo ya fue enviado.'
            ];
            return $output;
        }*/
        if (!empty($voucher_electronic[0]->statusOld)) {
            $statusOld = trim($voucher_electronic[0]->statusOld).','.str_pad($voucher_electronic[0]->status, 2, "0", STR_PAD_LEFT);
        } else {
            $statusOld = str_pad($voucher_electronic[0]->status, 2, "0", STR_PAD_LEFT);
        }

        $datos_config = '{"USERNAME":"'   .trim($voucher_electronic[0]->username)
            .'","CLIENT_ID":"'  .trim($voucher_electronic[0]->cliente_id)
            .'","PASSWORD":"'   .trim($voucher_electronic[0]->password)
            .'","LLAVECRIPTO":"'.trim($voucher_electronic[0]->llavecripto)
            .'","RUTA_XML":"'   .trim($voucher_electronic[0]->ruta_xml)
            .'","CLAVE_MAIL":"' .trim($voucher_electronic[0]->clave_mail)
            .'"}';

        /*if ($voucher_electronic[0]->vaucherElect_status<6){
            $output = ['success' => false,
                'msg' => 'No ha sido aprobado por Hacienda.'
            ];
            return $output;
        }*/

        /*
        $datos1_config=$voucher_electronic[0]->datos_config;
        if (empty($datos1_config)){
            $output = ['success' => false,
                'msg' => 'La Ubicacón no tiene la configuración para enviar factura.'
            ];
            return $output;
        }
        */
        $domain = explode('@', $voucher_electronic[0]->email_emi);
        if (!checkdnsrr($domain[1])) {
            $output = [
                'success' => false,
                'data' => '',
                'msg' => "Correo de la Ubicación no valido o no hay red."
            ];
            return $output;
        }
        $vauchertype = $voucher_electronic[0]->vauchertype;
        if ($vauchertype == 4) {
            $output = [
                'success' => false,
                'data' => '',
                'msg' => ""
            ];
            return $output;
        }
        if (!$vauchertype == 4) {
            if (empty($voucher_electronic[0]->email_rec)) {
                $output = [
                    'success' => false,
                    'data' => '',
                    'msg' => "Correo del cliente esta vacio."
                ];
                return $output;
            }
        }
        $tomain = explode('@', $voucher_electronic[0]->email_rec);
        if (!checkdnsrr($tomain[1])) {
            $output = [
                'success' => false,
                'data' => '',
                'msg' => "Correo del cliente no valido o no hay red."
            ];
            return $output;
        }

        /*$datos1_config=trim($datos1_config); */
        $config   = json_decode($datos_config, true);
        $servidoresMail = [];
        $tipoCompro = [];
        // https://ascii.cl/es/codigos-html.htm
        include 'tablas.php';
        $cod_comprobante = str_pad($voucher_electronic[0]->vauchertype, 2, "0", STR_PAD_LEFT);
        $Asunto = $tipoCompro[$cod_comprobante];

        $rutatexto = DIR_PRO.'/public/resources/TextoCorreo.html';
        $Texto = "";
        if (file_exists($rutatexto)) {
            $Texto = file_get_contents($rutatexto);
        } else {
            $Texto = "Aviso de Envió de Voucher electrónico.";
        }
        $cuerpo = '';
        $cuerpo = $cuerpo.'<!DOCTYPE html>';
        $cuerpo = $cuerpo.'<html lang="es">';
        $cuerpo = $cuerpo.'<head>';
        $cuerpo = $cuerpo.'    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
        $cuerpo = $cuerpo.'    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">';
        $cuerpo = $cuerpo.'    <meta name="x-apple-disable-message-reformatting">';
        $cuerpo = $cuerpo.'    <title>'.$Asunto.'</title>';
        $cuerpo = $cuerpo.'    <style>';
        $cuerpo = $cuerpo.'       table {border-collapse:collapse;border-spacing:0;border:none;margin:0;}';
        $cuerpo = $cuerpo.'       div, td {padding:0;}';
        $cuerpo = $cuerpo.'       div {margin:0 !important;}';
        $cuerpo = $cuerpo.'    </style>';
        $cuerpo = $cuerpo.'    <style>';
        $cuerpo = $cuerpo.'       table, td, div, h1, p {';
        $cuerpo = $cuerpo.'           font-family: Arial, sans-serif;';
        $cuerpo = $cuerpo.'       }';
        $cuerpo = $cuerpo.'    </style>';
        $cuerpo = $cuerpo.'</head>';
        $cuerpo = $cuerpo.'<body style="margin:10px;padding:5px;word-spacing:normal">';
        $cuerpo = $cuerpo.'<table role="presentation" style="width:100%;border:none;border-spacing:0;">
                <tr>
                    <td>
                    <div style="display: flex;width: 100%">
                            <div style="padding:5px 5px 5px 5px;font-size:24px;font-weight:bold;width: 13%;">
                            <a href="'.trim($voucher_electronic[0]->website).'" style="text-decoration:none;">
                            <img src="'.ENV('APP_URL').'/uploads/business_logos/'.trim($voucher_electronic[0]->logo).'" width="165" alt="Logo" style="width:165px;max-width:80%;height:auto;border:none;text-decoration:none;color:#ffffff;">
                            </a>
                            </div>
                            <div style="text-align:left;padding:10px;background-color:#ffffff;width: 50%; ">
                                <h1 style="margin-top:0;margin-bottom:5px;font-size:22px;line-height:32px;font-weight:bold;letter-spacing:-0.02em;">'.letraEspeciales(trim($voucher_electronic[0]->name_emi)).'</h1>';
        $cuerpo = $cuerpo.'<p style="margin:0;"><b>'.trim($voucher_electronic[0]->email_emi).'</b><br>';
        $cuerpo = $cuerpo.'<b>'.str_pad($voucher_electronic[0]->cod_pais_emi, 3, "0", STR_PAD_LEFT)."-".trim($voucher_electronic[0]->telefono_emi).'</b><br>';
        $cuerpo = $cuerpo.'<b>N&#186; de registro: '.$voucher_electronic[0]->cedula_juridica.'</b><br>';
        $cuerpo = $cuerpo.'</p>
                            </div>
                    </div>
                    </td>
                </tr>                    
                <tr>
                    <td colspan = "2" style="padding:30;">';                // mejorar cantenido email.
        //$cuerpo=$cuerpo.'<h2>'.trim($voucher_electronic[0]->name_emi).'</h2>';
        $cuerpo = $cuerpo.'<div class="col-lge" style="display:inline-block;width:100%;max-width:500px;vertical-align:top;padding-bottom:5px;font-family:Arial,sans-serif;font-size:16px;line-height:18px;color:#363636;">';
        $name_rec = letraEspeciales(trim($voucher_electronic[0]->name_rec));
        $cuerpo = $cuerpo.'Para: <b>'.$name_rec.'</b><br>';
        $cuerpo = $cuerpo.'N&#186; de registro: <b>'.$voucher_electronic[0]->cedula_rec.'</b><br>';
        $cuerpo = $cuerpo.'Correo: <b>'.$voucher_electronic[0]->email_rec.'</b><br><br>';
        //$cuerpo=$cuerpo.'<b>'.$voucher_electronic[0]->name_rec.'</b><br><br>';
        $cuerpo = $cuerpo.'<h3>'.$Asunto.'</h3>';
        $cuerpo = $cuerpo.'Comprobante N&#186;: <b>'.trim($voucher_electronic[0]->invoice_no).'</b><br>';
        $cuerpo = $cuerpo.'Por: <b>'.$voucher_electronic[0]->total_before_tax.'</b><br>';
        $cuerpo = $cuerpo.'M&#225;s Impuestos: <b>'.$voucher_electronic[0]->tax_amount.'</b><br>';
        $cuerpo = $cuerpo.'Total General: <b>'.$voucher_electronic[0]->final_total.'</b><br><br>';

        $cuerpo = $cuerpo.'<p>'.$Texto.'</p><br><br>';

        $cuerpo = $cuerpo.'Se adjuntan comprobantes electr&#243;nico n&#186;: <b>'.$voucher_electronic[0]->NumeroConsecutivo.'</b><br><br>';
        if (!empty($voucher_electronic[0]->xml)) {
            $nombre1   = pathinfo($voucher_electronic[0]->xml, PATHINFO_FILENAME);
            $extension1 = pathinfo($voucher_electronic[0]->xml, PATHINFO_EXTENSION);
            $cuerpo = $cuerpo.'Sus archivos ';
            $cuerpo = $cuerpo.'<b>'.$nombre1.'.'.$extension1.' </b><br> ';
            if (!empty($voucher_electronic[0]->xml_respuesta)) {
                $nombre2   = pathinfo($voucher_electronic[0]->xml_respuesta, PATHINFO_FILENAME);
                $extension2 = pathinfo($voucher_electronic[0]->xml_respuesta, PATHINFO_EXTENSION);
                $cuerpo = $cuerpo.'<b>,'.$nombre2.'.'.$extension2.', </b><br> ';
            }
            if (!empty($voucher_electronic[0]->pdf)) {
                $nombre3   = pathinfo($voucher_electronic[0]->pdf, PATHINFO_FILENAME);
                $extension3 = pathinfo($voucher_electronic[0]->pdf, PATHINFO_EXTENSION);
                $cuerpo = $cuerpo.'<b>,'.$nombre3.'.'.$extension3.'</b><br> ';
            }
        }
        $cuerpo = $cuerpo.'</div>';
        $cuerpo = $cuerpo.'</td> 
                </tr>
            </table>';
        $cuerpo = $cuerpo.'</body>';
        $cuerpo = $cuerpo.'</html>';

        $ConfigMail = $servidoresMail[$domain[1]];
        $data = [
            'Host'       => $ConfigMail['Host'],
            'SMTPSecure' => $ConfigMail['SMTPSecure'],
            'Port'       => $ConfigMail['Port'],
            'Correo_from' => $voucher_electronic[0]->email_emi,
            'Nombre_from' => trim($voucher_electronic[0]->name_emi),
            'Password'   => trim($config['CLAVE_MAIL']),
            'Correo_to'  => trim($voucher_electronic[0]->email_rec),
            'Nombre_to'  => trim($voucher_electronic[0]->name_rec),
            'Asunto'     => $Asunto,
            'Cuerpo'     => $cuerpo,
            'Adjunto1'   => trim($voucher_electronic[0]->xml),
            'Adjunto2'   => trim($voucher_electronic[0]->xml_respuesta),
            'Adjunto3'   => trim($voucher_electronic[0]->pdf),
            'status'     => $voucher_electronic[0]->status,
            'vaucherElect_status' => $voucher_electronic[0]->vaucherElect_status,
            'statusOld'  => $statusOld
        ];
        $output = [
            'success' => true,
            'data'   => $data,
            'msg'    => ''
        ];
        return $output;
    } catch (\Exception $e) {
        \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        $output = [
            'success' => false,
            'data' => '',
            'msg' => "Msg: " . "<br>File:" . $e->getFile(). "<br>Line:" . $e->getLine(). "<br>Message:" . $e->getMessage()
        ];
        return $output;
    }
}
// https://www.baulphp.com/php-foreach-enviar-email-phpmailer-completo/
// https://www.ionos.es/digitalguide/correo-electronico/cuestiones-tecnicas/phpmailer/
function Enviar_Correo($datos)
{
    try {
        if (empty($datos['Adjunto1'])) {
            $output = [
                'success' => false,
                'msg' => 'No hay Voucher Electrónico para enviar.'
            ];
            return $output;
        }
        $mail = new PHPMailer(true);                   // Passing `true` enables exceptions
        $mail->isHTML(true); // Set email format to HTML
        $mail->CharSet = 'UTF-8';
        //Server settings
        $mail->SetLanguage('es');
        $mail->SMTPDebug  = 0;                      // Enable verbose debug output
        $mail->isSMTP();                           // Set mailer to use SMTP
        $mail->Host       = $datos['Host'];       //'smtp.mailtrap.io';    //Specify main and backup SMTP servers
        $mail->Username   = $datos['Correo_from']; //'a4928ebb10a974';      //SMTP username
        $mail->Password   = $datos['Password'];    //'7a8665332a2d9e';      //SMTP password
        $mail->SMTPAuth   = true;                  // Enable SMTP authentication por username y Password
        $mail->SMTPSecure = $datos['SMTPSecure'];  // Enable TLS encryption, `ssl` also accepted
        $mail->Port       = $datos['Port'];        // 2525;    // TCP port to connect to

        //Recipients
        $mail->setFrom($datos['Correo_from'], $datos['Nombre_from']);
        //$mail->addAddress($datos['Correo_to'], $datos['Nombre_to']); // Add a destino
        // Separar los correos y agregarlos individualmente
        $emails = explode(',', $datos['Correo_to']); // Dividir por comas
        foreach ($emails as $email) {
            $email = trim($email); // Eliminar espacios en blanco
            if (!empty($email)) { 
                $mail->addAddress($email, $datos['Nombre_to']); // Agregar destinatario
            }
        }
        //$mail->addAddress('ellen@example.com');               // Name is optional
        //$mail->addReplyTo('ellen@example.com','información']);
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');

        //Attachments
        if (!empty($datos['Adjunto1'])) {
            $mail->addAttachment($datos['Adjunto1']);
        }         // Add attachments
        if (!empty($datos['Adjunto2'])) {
            $mail->addAttachment($datos['Adjunto2']);
        }
        if (!empty($datos['Adjunto3'])) {
            $mail->addAttachment($datos['Adjunto3']);
        }
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

        //Content
        $Asunto = $datos['Asunto'];
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = $Asunto;
        $mail->Body    = $datos['Cuerpo'];
        //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        if (!$mail->send()) {
            $output = [
                'success' => false,
                'msg' => 'Mensaje no fue enviado. Error: ' . $mail->ErrorInfo
            ];
            return $output;
        }
        $output = [
            'success' => true,
            'msg' => 'Correo enviado.'
        ];
        return $output;
    } catch (Exception $e) {
        \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        $output = [
            'success' => false,
            'msg' => $mail->ErrorInfo
        ];
        return $output;
    }

}
function letraEspeciales($palabras)
{
    $cadena = "";
    // Recorremos cada carácter de la cadena
    //http://www.webusable.com/CharsExtendedTable.htm
    for ($i = 0;$i < strlen($palabras);$i++) {
        $especiales = [
            'á' => '&#225;',
            'é' => '&#233;',
            'í' => '&#237;',
            'ó' => '&#243;',
            'ú' => '&#250;',
            'Á' => '&#193;',
            'É' => '&#201;',
            'Í' => '&#205;',
            'Ó' => '&#211;',
            'Ú' => '&#218,',
            'ñ' => '&#241;',
            'Ñ' => '&#241;',
            'º' => '&#176;',
            '@' => '&#64'
        ];
        if (isset($especiales[$palabras[$i]])) {
            $cadena = $cadena.$especiales[$palabras[$i]];
        } else {
            $cadena = $cadena.$palabras[$i];
        }
    }
    return $cadena;
}
// no terminado
// https://jwt.io/introduction
/*function ver_AprobadoMin($id){
    $tablas="voucher_electronic AS a ";
    $tablas=$tablas."INNER JOIN business_locations AS b ON b.id=a.location_id and b.business_id=b.business_id ";
    $datos="a.*,b.datos_config ";
    $sql = "SELECT ".$datos."FROM ".$tablas."WHERE a.transaction_id=".$id." ";
    $voucher_electronic = DB::select($sql);
    if (count($voucher_electronic)<1){
        $output = ['success' => false,
            'msg' => 'No existe ese voucher electrónico. '
        ];
        return $output;
    }
    $datos_config='{"USERNAME":"'   .trim($ubicacion_datos[0]->username)
        .'","CLIENT_ID":"'  .trim($ubicacion_datos[0]->cliente_id)
        .'","PASSWORD":"'   .trim($ubicacion_datos[0]->password)
        .'","LLAVECRIPTO":"'.trim($ubicacion_datos[0]->llavecripto)
        .'","RUTA_XML":"'   .trim($ubicacion_datos[0]->ruta_xml)
        .'","CLAVE_MAIL":"' .trim($ubicacion_datos[0]->clave_mail)
    .'"}';
    /*
        $datos1_config=$voucher_electronic[0]->datos_config;
        if (empty($datos1_config)){
            $output = ['success' => false,
                'msg' => 'La ubicación no tiene los datos de configuración.'
            ];
            return $output;
        }

    $status=$voucher_electronic[0]->vaucherElect_status;
    if ($status>5){
        $output = ['success' => false,
            'msg' => 'Ya fue aprobado por Hacienda.'
        ];
        return $output;
    }

    if (!empty($voucher_electronic[0]->statusOld)){
        $statusOld=trim($voucher_electronic[0]->statusOld).','.str_pad($voucher_electronic[0]->vaucherElect_status,2, "0", STR_PAD_LEFT);
    }else{
        $statusOld=str_pad($voucher_electronic[0]->vaucherElect_status,2, "0", STR_PAD_LEFT);
    }
    $clave       =$voucher_electronic[0]->clave;
    //$datos1_config=trim($datos1_config);
    $token=token($datos_config);
    //    echo '<br><br><br>';
    if (isset($token->access_token)){
        $config = json_decode($datos_config, true);
        $respuesta = consultar($config['CLIENT_ID'],$clave,$token->access_token);

        $Rnombre_rep=DIR_PRO.'/public'.$config['RUTA_XML'].'/'.trim($voucher_electronic[0]->NumeroConsecutivo).trim($voucher_electronic[0]->vaucherElect_status)."A.txt";
        $text=$respuesta;
        $i = 1;
        $numero=$voucher_electronic[0]->NumeroConsecutivo;
        $status=$voucher_electronic[0]->vaucherElect_status;
        do {
            $Rnombre_rep=DIR_PRO.'/public'.$config['RUTA_XML'].'/'.trim($numero).trim($status).'A'.$i.'.txt';
            if (!file_exists($Rnombre_rep)){
                file_put_contents($Rnombre_rep,$text);
                break;
            }
            $i=$i+1;
        } while ($i>0);

        $tabla="voucher_electronic ";
        $condicion="transaction_id=".$id;

        // quitar por aprobación de hacienda
        $vistaso='Esperando Hacienda';
        //$vistaso='Aprobado';
        // quitar por aprobación de hacienda

        $campos="vaucherElect_status='04', ";
        if ($vistaso=='Rechazada'){
            $campos="vaucherElect_status='05', ";
        }
        if ($vistaso=='Aprobado'){
            $campos="vaucherElect_status='06', ";
        }
        $campos=$campos."statusOld='".$statusOld."' ";
        $sql = 'UPDATE '.$tabla.'SET '.$campos.'WHERE '.$condicion;
        $transactions= DB::select($sql);
        set_time_limit(20);
        $respuesta="--> No esta Listo> <-- <br>";
        $output = ['success' => true,'msg' =>   ' Respuesta en '.$Rnombre_rep// .$dato."."
        ];
        //logout($token,$datos_config);
    }else{
        $output = ['success' => false,
            'msg' =>'No hay Conexión con Hacienda intente más tarde.'
        ];
    }
    return $output;
}
*/
//https://github.com/CRLibre/API_Hacienda/blob/master/api/contrib/consultar/consultar.php
//Envio del documento para Hacienda mediante CURL nuevamente
function enviar($json, $token, $config)
{
    $apiTo = $config['CLIENT_ID'];
    if ($apiTo == 'api-stag') {
        $url = URLAPISTAG;
    } elseif ($apiTo == 'api-prod') {
        $url = URLAPIPROD;
    }
    $url = $url."recepcion";
    //$url = "https://www.comprobanteselectronicoscr.com/api/makeXML.stag.42";
    //consumo del WS con envio de parametros con metodo POST
    //$url = "https://www.comprobanteselectronicoscr.com/api/makeXML.stag.42";
    //consumo del WS con envio de parametros con metodo POST
    $header = array(
        "Authorization: bearer ".$token,
        "Content-Type: application/json",
    );
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($curl, CURLOPT_POSTFIELDS, $json);

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT  => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $json,
        CURLOPT_HTTPHEADER => array(
            "authorization: bearer ".$token,
            "cache-control: no-cache",
            "Content-Type: application/json",
            "postman-token: 689c8b8b-789b-94a3-ba89-607cb3338a5d"
        ),
    ));
    $respuesta = curl_exec($curl);
    $status1 = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        $arrayResp = array(
            "Status" => $status1,
            "to" => $apiTo,
            "text" => explode("\n", $err)
        );
        return $arrayResp;
    } else {
        $arrayResp = array(
            "Status" => $status1,
            "text" => explode("\n", $respuesta)
        );
        return $arrayResp;
    }
}

function enviar99($json, $token, $config)
{
    $apiTo = $config['CLIENT_ID'];
    if ($apiTo == 'api-stag') {
        $url = URLAPISTAG;
    } elseif ($apiTo == 'api-prod') {
        $url = URLAPIPROD;
    }
    $url = $url."recepcion";
    //$url = "https://www.comprobanteselectronicoscr.com/api/makeXML.stag.42";
    //consumo del WS con envio de parametros con metodo POST
    $header = array(
        "Authorization: bearer ".$token,
        //"cache-control: no-cache",
        "Content-Type: application/json",
        //"postman-token: 689c8b8b-789b-94a3-ba89-607cb3338a5d"
    );
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
    curl_setopt($curl, CURLOPT_TIMEOUT, 30);
    $respuesta = curl_exec($curl);
    $status1 = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        $arrayResp = array(
            "Status" => $status1,
            "to" => $apiTo,
            "text" => explode("\n", $err)
        );
        return $arrayResp;
    } else {
        $arrayResp = array(
            "Status" => $status1,
            "text" => explode("\n", $respuesta)
        );
        return $arrayResp;
    }
}
//https://flecharoja.com/guia-de-uso-para-idp-comprobantes-electronicos/
//https://github.com/CRLibre/API_Hacienda/tree/dev/api/contrib
function token($datos_config)
{
    $config = json_decode($datos_config, true);
    $client_id = trim($config['CLIENT_ID']);
    $grant_type = GRANT_TYPE;
    $username = trim($config['USERNAME']);
    $password = trim($config['PASSWORD']);
    $refresh_token = REFRESH_TOKEN;
    if ($client_id == 'api-stag') {
        $url = URLTOKENSTAG;
    } elseif ($client_id == 'api-prod') {
        $url = URLTOKENPROD;
    }
    $url = $url."token";
    //Validation
    if ($client_id == '') {
        return "El parametro Client ID es requerido";
    } elseif ($grant_type == '') {
        return "El parametro Grant Type es requerido";
    } elseif ($username == '') {
        return "El parametro Username es requerido";
    } elseif ($password == '') {
        return "El parametro Password es requerido";
    }
    if ($grant_type == "password") {
        $data = array(
            'client_id' => $client_id,
            //            'client_secret' => $client_secret,
            'grant_type' => $grant_type,
            'username' => $username,
            'password' => $password
        );
    } elseif ($grant_type == "refresh_token") {
        if ($refresh_token == '') {
            return "El parametro Refresh Token es requerido";
        }
        $data = array(
            'client_id' => $client_id,
            'client_secret' => $client_secret,
            'grant_type' => $grant_type,
            'refresh_token' => $refresh_token
        );
    }

    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_HEADER, 'Content-Type: application/x-www-form-urlencoded; charset=utf-8');
    $data = http_build_query($data);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    //    grace_debug("JSON: ".$data);
    $respuesta = curl_exec($curl);
    $status1 = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $err = json_decode(curl_error($curl));
    curl_close($curl);
    if ($err) {
        $arrayResp = array(
            "error" => true,
            "Status" => $status1,
            "text" => $err
        );
        return $arrayResp;
    } else {
        return json_decode($respuesta);
    }
}

// Comienzo de proceso de logout
function logout($token, $datos_config)
{
    $config = json_decode($datos_config, true);
    $client_id = $config['CLIENT_ID'];
    $curl = curl_init();

    if ($client_id == 'api-stag') {
        $url = URLTOKENSTAG;
    } elseif ($client_id == 'api-prod') {
        $url = URLTOKENPROD;
    }

    $url = $url.'logout';
    $post = "client_id=".$client_id."&refresh_token=".$token."";
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $post,
        CURLOPT_HTTPHEADER => array(
            "Content-Type: application/x-www-form-urlencoded",
            "Postman-Token: d9d25658-c3b0-47c9-a30e-11681b86f0b7",
            "cache-control: no-cache"
        ),
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if ($err) {
        return "cURL Error #:" . $err;
    } else {
        return $response;
    }
}
////
function to_xml($array)
{
    $texto = "";
    foreach ($array as $key => $value) {
        if (is_array($value)) {
            $value = to_xml($value);
        }
        $texto = $texto."<".$key.">".$value."</".$key.">";
    }
    return $texto;
}
// crea un numero de voucher
function crearVoucherid()
{
    $repetir = true;
    do {
        $vaucherElect_id = rand();
        $sql = 'SELECT * FROM voucher_electronic WHERE vaucherElect_id='.$vaucherElect_id;
        $voucher_electronic = DB::select($sql);
        if (count($voucher_electronic) < 1) {
            $repetir = false;
        }
    } while ($repetir);
    return $vaucherElect_id;
}

//https://github.com/CRLibre/API_Hacienda/blob/dev/api/contrib/signXML/sign.php   este
class Firmadocr
{
    public $NODOS_NS;
    public $POLITICA_FIRMA;
    public $signTime;
    public $signPolicy;
    public $publicKey;
    public $privateKey;
    public $cerROOT;
    public $cerINTERMEDIO;
    public $tipoDoc;

    public function __construct()
    {
        $this->NODOS_NS = array(
            "URL" => "https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/",
            '01' => "facturaElectronica",
            '02' => "notaDebitoElectronica",
            '03' => "notaCreditoElectronica",
            '04' => "tiqueteElectronico",
            '05' => "mensajeReceptor",
            '06' => "mensajeReceptor",
            '07' => "mensajeReceptor"
        );

        $this->signTime         = null;
        $this->signPolicy       = null;
        $this->publicKey        = null;
        $this->privateKey       = null;
        $this->cerROOT          = null;
        $this->cerINTERMEDIO    = null;

        $this->POLITICA_FIRMA = array(
            "name"      => "",
            "url"       => "https://atv.hacienda.go.cr/ATV/ComprobanteElectronico/docs/esquemas/2016/v4.3/Resoluci%C3%B3n_General_sobre_disposiciones_t%C3%A9cnicas_comprobantes_electr%C3%B3nicos_para_efectos_tributarios.pdf",
            "digest"    => "0h7Q3dFHhu0bHbcZEgVc07cEcDlquUeG08HG6Iototo=" // digest en sha256 y base64
        );

        $this->tipoDoc          = '01';
    }

    public function retC14DigestSha1($strcadena)
    {
        $strcadena    = str_replace("\r", "", str_replace("\n", "", $strcadena));
        $d1p          = new DOMDocument('1.0', 'UTF-8');
        $d1p->loadXML($strcadena);
        $strcadena    = $d1p->C14N();

        return base64_encode(hash('sha256', $strcadena, true));
    }

    public function firmar($certificadop12, $clavecertificado, $xmlsinfirma, $tipodoc_i)
    {
        if (!$pfx = file_get_contents($certificadop12)) {
            $output = [
                'success' => false,
                'msg' => "Error: No se puede leer el fichero del certificado o no existe en la ruta especificada\n"
            ];
            return $output;
        }

        if (openssl_pkcs12_read($pfx, $key, $clavecertificado)) {
            $this->publicKey    = $key["cert"];
            $this->privateKey   = $key["pkey"];

            $complem          = openssl_pkey_get_details(openssl_pkey_get_private($this->privateKey));
            $this->Modulus    = base64_encode($complem['rsa']['n']);
            $this->Exponent   = base64_encode($complem['rsa']['e']);
        } else {
            $output = [
                'success' => false,
                'msg' => 'Error: No se puede leer el almacén de certificados o la clave no es la correcta.\n'
            ];
            return $output;
        }

        $this->signPolicy         = $this->POLITICA_FIRMA;
        $this->signatureID        = "Signature-ddb543c7-ea0c-4b00-95b9-d4bfa2b4e411";
        $this->signatureValue     = "SignatureValue-ddb543c7-ea0c-4b00-95b9-d4bfa2b4e411";
        $this->XadesObjectId      = "XadesObjectId-43208d10-650c-4f42-af80-fc889962c9ac";
        $this->KeyInfoId          = "KeyInfoId-".$this->signatureID;

        $this->Reference0Id       = "Reference-0e79b719-635c-476f-a59e-8ac3ba14365d";
        $this->Reference1Id       = "ReferenceKeyInfo";

        $this->SignedProperties   = "SignedProperties-".$this->signatureID;

        $this->tipoDoc            = $tipodoc_i;
        $xml1                     = base64_decode($xmlsinfirma);
        $xml1                     = $this->insertaFirma($xml1);

        $output = [
            'success' => true,
            'msg' => 'No error',
            'xml64' => base64_encode($xml1)
        ];
        return $output;
    }

    /**
     * Función que Inserta la firma e
     * @parametros  archivo xml sin firma según UBL de DIAN
     * @retorna el documento firmando
     */

    public function insertaFirma($xml)
    {
        if (is_null($this->publicKey) || is_null($this->privateKey)) {
            return $xml;
        }

        // Canoniza todo el documento  para el digest
        $d = new DOMDocument('1.0', 'UTF-8');
        $d->loadXML($xml);
        $canonizadoreal = $d->C14N();

        // Definir los namespace para los diferentes nodos
        $xmlns_keyinfo = 'xmlns="'.$this->NODOS_NS["URL"].$this->NODOS_NS[$this->tipoDoc].'" ';
        $xmnls_signedprops = $xmlns_keyinfo;
        $xmnls_signeg = $xmlns_keyinfo;

        $xmlns = 'xmlns:ds="http://www.w3.org/2000/09/xmldsig#" ' .
            'xmlns:fe="http://www.dian.gov.co/contratos/facturaelectronica/v1" ' .
            'xmlns:xades="http://uri.etsi.org/01903/v1.3.2#"';

        $xmlns_keyinfo .= 'xmlns:ds="http://www.w3.org/2000/09/xmldsig#" ' .
                        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ' .
                        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"';

        $xmnls_signedprops .= 'xmlns:ds="http://www.w3.org/2000/09/xmldsig#" ' .
                            'xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" ' .
                            'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ' .
                            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"';

        $xmnls_signeg .= 'xmlns:ds="http://www.w3.org/2000/09/xmldsig#" ' .
                        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ' .
                        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"';

        $signTime1 = date('Y-m-d\TH:i:s-06:00');

        $certData   = openssl_x509_parse($this->publicKey);
        $certDigest = base64_encode(openssl_x509_fingerprint($this->publicKey, "sha256", true));

        $certIssuer = array();
        foreach ($certData['issuer'] as $item => $value) {
            $certIssuer[] = $item . '=' . $value;
        }

        $certIssuer = implode(', ', array_reverse($certIssuer));

        $prop = '<xades:SignedProperties Id="' . $this->SignedProperties .  '">' .
      '<xades:SignedSignatureProperties>'.
          '<xades:SigningTime>' .  $signTime1 . '</xades:SigningTime>' .
          '<xades:SigningCertificate>'.
              '<xades:Cert>'.
                  '<xades:CertDigest>' .
                      '<ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256" />'.
                      '<ds:DigestValue>' . $certDigest . '</ds:DigestValue>'.
                  '</xades:CertDigest>'.
                  '<xades:IssuerSerial>' .
                      '<ds:X509IssuerName>'   . $certIssuer       . '</ds:X509IssuerName>'.
                      '<ds:X509SerialNumber>' . $certData['serialNumber'] . '</ds:X509SerialNumber>' .
                  '</xades:IssuerSerial>'.
              '</xades:Cert>'.
          '</xades:SigningCertificate>' .
          '<xades:SignaturePolicyIdentifier>'.
              '<xades:SignaturePolicyId>' .
                  '<xades:SigPolicyId>'.
                      '<xades:Identifier>' . $this->signPolicy['url'] .  '</xades:Identifier>'.
                      '<xades:Description />'.
                  '</xades:SigPolicyId>'.
                  '<xades:SigPolicyHash>' .
                      '<ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256" />'.
                      '<ds:DigestValue>' . $this->signPolicy['digest'] . '</ds:DigestValue>'.
                  '</xades:SigPolicyHash>'.
              '</xades:SignaturePolicyId>' .
          '</xades:SignaturePolicyIdentifier>'.
      '</xades:SignedSignatureProperties>'.
      '<xades:SignedDataObjectProperties>'.
          '<xades:DataObjectFormat ObjectReference="#'. $this->Reference0Id . '">'.
              '<xades:MimeType>text/xml</xades:MimeType>'.
              '<xades:Encoding>UTF-8</xades:Encoding>'.
          '</xades:DataObjectFormat>'.
      '</xades:SignedDataObjectProperties>'.
      '</xades:SignedProperties>';

        // Prepare key info
        $publicPEM = "";
        openssl_x509_export($this->publicKey, $publicPEM);
        $publicPEM = str_replace("-----BEGIN CERTIFICATE-----", "", $publicPEM);
        $publicPEM = str_replace("-----END CERTIFICATE-----", "", $publicPEM);
        $publicPEM = str_replace("\r", "", str_replace("\n", "", $publicPEM));

        $kInfo = '<ds:KeyInfo Id="'.$this->KeyInfoId.'">' .
                '<ds:X509Data>'  .
                    '<ds:X509Certificate>'  . $publicPEM .'</ds:X509Certificate>' .
                '</ds:X509Data>' .
                '<ds:KeyValue>'.
                '<ds:RSAKeyValue>'.
                    '<ds:Modulus>'.$this->Modulus .'</ds:Modulus>'.
                    '<ds:Exponent>'.$this->Exponent .'</ds:Exponent>'.
                '</ds:RSAKeyValue>'.
                '</ds:KeyValue>'.
             '</ds:KeyInfo>';

        $aconop     = str_replace('<xades:SignedProperties', '<xades:SignedProperties ' . $xmnls_signedprops, $prop);
        $propDigest = $this->retC14DigestSha1($aconop);

        $keyinfo_para_hash1 = str_replace('<ds:KeyInfo', '<ds:KeyInfo ' . $xmlns_keyinfo, $kInfo);
        $kInfoDigest = $this->retC14DigestSha1($keyinfo_para_hash1);

        $documentDigest = base64_encode(hash('sha256', $canonizadoreal, true));

        // Prepare signed info
        $sInfo = '<ds:SignedInfo>' .
        '<ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315" />' .
        '<ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256" />' .
        '<ds:Reference Id="' . $this->Reference0Id . '" URI="">' .
        '<ds:Transforms>' .
        '<ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature" />' .
        '</ds:Transforms>' .
        '<ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256" />' .
        '<ds:DigestValue>' . $documentDigest . '</ds:DigestValue>' .
        '</ds:Reference>' .
        '<ds:Reference Id="'.  $this->Reference1Id . '" URI="#'.$this->KeyInfoId .'">' .
        '<ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256" />' .
        '<ds:DigestValue>' . $kInfoDigest . '</ds:DigestValue>' .
        '</ds:Reference>' .
        '<ds:Reference Type="http://uri.etsi.org/01903#SignedProperties" URI="#' . $this->SignedProperties . '">' .
        '<ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256" />' .
        '<ds:DigestValue>' . $propDigest . '</ds:DigestValue>' .
        '</ds:Reference>' .
        '</ds:SignedInfo>';


        $signaturePayload = str_replace('<ds:SignedInfo', '<ds:SignedInfo ' . $xmnls_signeg, $sInfo);

        $d1p = new DOMDocument('1.0', 'UTF-8');
        $d1p->loadXML($signaturePayload);
        $signaturePayload = $d1p->C14N();

        $signatureResult = "";
        $algo = "SHA256";

        openssl_sign($signaturePayload, $signatureResult, $this->privateKey, $algo);

        $signatureResult = base64_encode($signatureResult);

        $sig = '<ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Id="' . $this->signatureID . '">'.
        $sInfo .
        '<ds:SignatureValue Id="' . $this->signatureValue . '">' .
        $signatureResult .  '</ds:SignatureValue>'  . $kInfo .
        '<ds:Object Id="'.$this->XadesObjectId .'">'.
        '<xades:QualifyingProperties xmlns:xades="http://uri.etsi.org/01903/v1.3.2#" Id="QualifyingProperties-012b8df6-b93e-4867-9901-83447ffce4bf" Target="#' . $this->signatureID . '">' . $prop .
        '</xades:QualifyingProperties></ds:Object></ds:Signature>';

        $buscar;
        $remplazar;
        if ($this->tipoDoc == '01') {
            $buscar = '</FacturaElectronica>';
            $remplazar = $sig."</FacturaElectronica>";
        } elseif ($this->tipoDoc == '02') {
            $buscar = '</NotaDebitoElectronica>';
            $remplazar = $sig."</NotaDebitoElectronica>";
        } elseif ($this->tipoDoc == '03') {
            $buscar = '</NotaCreditoElectronica>';
            $remplazar = $sig."</NotaCreditoElectronica>";
        } elseif ($this->tipoDoc == '04') {
            $buscar = '</TiqueteElectronico>';
            $remplazar = $sig."</TiqueteElectronico>";
        } elseif ($this->tipoDoc == '05' || $this->tipoDoc == '06' || $this->tipoDoc == '07') {
            $buscar = '</MensajeReceptor>';
            $remplazar = $sig."</MensajeReceptor>";
        }

        $pos = strrpos($xml, $buscar);
        if ($pos !== false) {
            $xml = substr_replace($xml, $remplazar, $pos, strlen($buscar));
        }

        return $xml;
    }


    public function listado()
    {

    }

}


//    Factura electrónica
// https://solucionfactible.com/sfic/capitulos/general/xmldsig.jsp
// https://www.baulphp.com/sistema-factura-con-php-y-mysql/
// https://www.alegra.com/costarica/facturacion-electronica/?utm_source=escuela-emprendedores.alegra.com&amp;utm_medium=referral&amp;utm_term=costa-rica-pasos-para-ser-facturador-electronico&amp;utm_content=costa-rica-pasos-para-ser-facturador-electronico
// https://helenbogantes.com/factura-electronica-en-costa-rica/
// https://github.com/CRLibre/API_Hacienda/blob/master/api/contrib/signXML/Firmadohaciendacr.php
// https://www.phpcentral.com/pregunta/534/firma-digital-en-php
//https://karoldabrowski.com/blog/solution-for-419-page-expired-error-in-laravel/
/* Comprobantes Electronico
    https://crlibre.org/
    https://github.com/CRLibre/API_Hacienda/tree/master/api   muy bueno
    https://www.royrojas.com/tag/factura-electronica-costa-rica/
    https://www.bccr.fi.cr/indicadores-economicos/cat%C3%A1logo-de-bienes-y-servicios
    Se debe instalar Win64OpenSSL
////https://www.royrojas.com/ejemplos-de-documentos-electronicos-4-3/
*/
// consulta estado del servidor "https://apis.gometa.org/status/"

?> 