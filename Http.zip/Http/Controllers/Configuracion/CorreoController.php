<?php

namespace App\Http\Controllers\Configuracion;

use Illuminate\Http\Request;
use App\Models\ConfiguracionCorreo;
use Webklex\IMAP\Client;

class CorreoController extends Controller
{
    public function index()
    {
        $correos = ConfiguracionCorreo::all();
        return view('configuracion_correos.index', compact('correos'));
    }

    public function create()
    {
        return view('configuracion_correos.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'correo' => 'required|email|unique:configuracion_correos,correo',
            'clave' => 'required|string|min:6',
            'servidor_imap' => 'required|string',
            'puerto' => 'required|integer',
            'encryption' => 'required|in:ssl,tls,none',
            'mail_driver' => 'required|in:imap,smtp',
        ]);

        ConfiguracionCorreo::create([
            'correo' => $request->correo,
            'clave' => $request->clave,
            'servidor_imap' => $request->servidor_imap,
            'puerto' => $request->puerto,
            'encryption' => $request->encryption,
            'mail_driver' => $request->mail_driver,
            'activo' => $request->has('activo'),
        ]);

        return redirect()->route('configuracion-correos.index')
            ->with('success', 'Configuración de correo creada exitosamente.');
    }

    public function edit($id)
    {
        $correo = ConfiguracionCorreo::findOrFail($id);
        return view('configuracion_correos.edit', compact('correo'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'correo' => 'required|email|unique:configuracion_correos,correo,' . $id,
            'clave' => 'required|string|min:6',
            'servidor_imap' => 'required|string',
            'puerto' => 'required|integer',
            'encryption' => 'required|in:ssl,tls,none',
            'mail_driver' => 'required|in:imap,smtp',
        ]);

        $correo = ConfiguracionCorreo::findOrFail($id);

        $correo->update([
            'correo' => $request->correo,
            'clave' => $request->clave,
            'servidor_imap' => $request->servidor_imap,
            'puerto' => $request->puerto,
            'encryption' => $request->encryption,
            'mail_driver' => $request->mail_driver,
            'activo' => $request->has('activo'),
        ]);

        return redirect()->route('configuracion-correos.index')
            ->with('success', 'Configuración de correo actualizada exitosamente.');
    }

    public function destroy($id)
    {
        $correo = ConfiguracionCorreo::findOrFail($id);
        $correo->delete();

        return redirect()->route('configuracion-correos.index')
            ->with('success', 'Configuración de correo eliminada exitosamente.');
    }

    public function probarConexion(Request $request)
{
    try {
        // C��digo para probar la conexi��n al servidor de correo.
        $transport = (new \Swift_SmtpTransport($request->servidor_imap, $request->puerto))
            ->setUsername($request->correo)
            ->setPassword($request->clave)
            ->setEncryption($request->encriptacion);

        $mailer = new \Swift_Mailer($transport);
        $mailer->getTransport()->start();

        return response()->json(['success' => true, 'message' => 'Conexión exitosa']);
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'message' => $e->getMessage()]);
    }
}

}