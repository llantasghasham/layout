<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ConfiguracionCorreo;
use Webklex\PHPIMAP\ClientManager;
use Swift_SmtpTransport;
use Swift_Mailer;
use Illuminate\Support\Facades\Log;

class ConfiguracionCorreoController extends Controller
{
    /**
     * Muestra la lista de todas las configuraciones de correos.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $correos = ConfiguracionCorreo::all();
        return view('configuracion_correos.index', compact('correos'));
    }

    /**
     * Muestra el formulario para crear una nueva configuración de correo.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('configuracion_correos.create');
    }

    /**
     * Almacena una nueva configuración de correo en la base de datos.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'correo' => 'required|email|unique:configuracion_correos,correo',
            'clave' => 'required|string|min:6',
            'servidor_imap' => 'required|string',
            'puerto' => 'required|integer|min:1|max:65535',
            'encryption' => 'required|in:ssl,tls,starttls,none',
            'mail_driver' => 'required|in:imap,pop3,smtp',
            'activo' => 'nullable|boolean',
        ]);

        $validatedData['activo'] = $request->has('activo') ? 1 : 0;

        ConfiguracionCorreo::create($validatedData);

        return redirect()->route('configuracion-correos.index')
            ->with('success', 'Configuración de correo creada exitosamente.');
    }

    /**
     * Muestra el formulario para editar una configuración existente.
     *
     * @param int $id
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $correo = ConfiguracionCorreo::findOrFail($id);
        return view('configuracion_correos.edit', compact('correo'));
    }

    /**
     * Actualiza una configuración de correo existente.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'correo' => 'required|email|unique:configuracion_correos,correo,' . $id,
            'clave' => 'required|string|min:6',
            'servidor_imap' => 'required|string',
            'puerto' => 'required|integer|min:1|max:65535',
            'encryption' => 'required|in:ssl,tls,starttls,none',
            'mail_driver' => 'required|in:imap,pop3,smtp',
            'activo' => 'nullable|boolean',
        ]);

        $validatedData['activo'] = $request->has('activo') ? 1 : 0;

        $correo = ConfiguracionCorreo::findOrFail($id);
        $correo->update($validatedData);

        return redirect()->route('configuracion-correos.index')
            ->with('success', 'Configuración de correo actualizada exitosamente.');
    }

    /**
     * Elimina una configuración de correo de la base de datos.
     *
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $correo = ConfiguracionCorreo::findOrFail($id);
        $correo->delete();

        return redirect()->route('configuracion-correos.index')
            ->with('success', 'Configuración de correo eliminada exitosamente.');
    }

    /**
     * Cambia el estado activo/inactivo de una configuración mediante AJAX.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function toggle(Request $request)
    {
        $request->validate([
            'id' => 'required|exists:configuracion_correos,id',
            'activo' => 'required|boolean',
        ]);

        try {
            $correo = ConfiguracionCorreo::findOrFail($request->id);
            $correo->activo = $request->activo;
            $correo->save();

            return response()->json([
                'success' => true,
                'message' => 'Estado actualizado correctamente.',
            ]);
        } catch (\Exception $e) {
            Log::error('Error al cambiar estado: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'No se pudo actualizar el estado: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Prueba la conexión a los servidores de correo (IMAP, POP3 o SMTP).
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function probar(Request $request)
    {
        Log::info('Intentando probar conexión con datos: ', $request->all());

        // Validar los datos de entrada
        $validated = $request->validate([
            'correo' => 'required|email',
            'clave' => 'required|string',
            'servidor_imap' => 'required|string',
            'puerto' => 'required|integer|min:1|max:65535',
            'encryption' => 'required|in:ssl,tls,starttls,none',
            'mail_driver' => 'required|in:imap,pop3,smtp',
        ]);

        $startTime = microtime(true);

        try {
            Log::info('Conectando con: ' . $validated['mail_driver'] . ' a ' . $validated['servidor_imap'] . ':' . $validated['puerto']);

            if (in_array($validated['mail_driver'], ['imap', 'pop3'])) {
                // Conexión IMAP o POP3
                $clientManager = new ClientManager();
                $client = $clientManager->make([
                    'host'          => $validated['servidor_imap'],
                    'port'          => $validated['puerto'],
                    'encryption'    => $validated['encryption'] === 'none' ? null : ($validated['encryption'] === 'starttls' ? 'tls' : $validated['encryption']),
                    'validate_cert' => false, // Desactivado para pruebas; cambiar a true en producción
                    'username'      => $validated['correo'],
                    'password'      => $validated['clave'],
                    'protocol'      => $validated['mail_driver'],
                ]);

                // Intentar conectar y manejar excepciones específicas
                $connection = $client->connect();
                if (!$connection) {
                    throw new \Exception('No se pudo establecer la conexión con el servidor.');
                }
                $client->disconnect();

                $tiempo = round((microtime(true) - $startTime) * 1000, 2);

                Log::info('Conexión exitosa con ' . $validated['mail_driver']);

                return response()->json([
                    'success' => true,
                    'message' => "Conexión {$validated['mail_driver']} establecida correctamente.",
                    'servidor_imap' => $validated['servidor_imap'],
                    'puerto' => $validated['puerto'],
                    'tiempo' => $tiempo,
                ]);
            } elseif ($validated['mail_driver'] === 'smtp') {
                // Conexión SMTP
                $transport = (new Swift_SmtpTransport($validated['servidor_imap'], $validated['puerto']))
                    ->setEncryption($validated['encryption'] === 'none' ? null : ($validated['encryption'] === 'starttls' ? 'tls' : $validated['encryption']))
                    ->setUsername($validated['correo'])
                    ->setPassword($validated['clave']);

                $mailer = new Swift_Mailer($transport);
                $mailer->getTransport()->start();
                $mailer->getTransport()->stop();

                $tiempo = round((microtime(true) - $startTime) * 1000, 2);

                Log::info('Conexión SMTP exitosa');

                return response()->json([
                    'success' => true,
                    'message' => 'Conexión SMTP establecida correctamente.',
                    'servidor_imap' => $validated['servidor_imap'],
                    'puerto' => $validated['puerto'],
                    'tiempo' => $tiempo,
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => 'Controlador de correo no soportado.',
                'detail' => 'El controlador de correo especificado no es compatible.',
                'servidor_imap' => $validated['servidor_imap'],
                'puerto' => $validated['puerto'],
            ], 400);
        } catch (\Exception $e) {
            Log::error('Error en prueba de conexión: ' . $e->getMessage() . ' - Contexto: ' . json_encode($validated));
            return response()->json([
                'success' => false,
                'message' => 'No se pudo conectar al servidor.',
                'detail' => $e->getMessage(),
                'servidor_imap' => $validated['servidor_imap'] ?? 'No disponible',
                'puerto' => $validated['puerto'] ?? 'No disponible',
            ], 500);
        }
    }
}