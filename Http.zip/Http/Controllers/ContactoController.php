<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ContactosRecepcion;

class ContactoController extends Controller
{
    public function getEmails(Request $request)
    {
        $search = $request->input('term');
        $emails = ContactoRecepcion::where('correo', 'LIKE', '%' . $search . '%')
            ->orWhere('nombre', 'LIKE', '%' . $search . '%')
            ->get(['correo', 'nombre']);

        return response()->json($emails);
    }

    public function addUser(Request $request)
    {
        $validatedData = $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|email|unique:contactos_recepcion',
            'telefono' => 'nullable|string|max:20',
        ]);

        $user = new ContactoRecepcion();
        $user->nombre = $validatedData['nombre'];
        $user->correo = $validatedData['correo'];
        $user->telefono = $validatedData['telefono'];
        $user->save();

        return response()->json(['success' => true, 'nombre' => $user->nombre, 'correo' => $user->correo]);
    }
}
