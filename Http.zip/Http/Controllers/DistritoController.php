<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Distritos;

class DistritoController extends Controller
{
    public function distritoByProCan($provincia_id, $canton_id)
    {
        $ditrito = Distritos::where('provincia_id', '=', $provincia_id)
                            ->where('canton_id', '=', $canton_id)
                            ->get();
        return $ditrito;
    }
}
