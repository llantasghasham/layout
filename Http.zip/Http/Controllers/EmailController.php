<?php

namespace App\Http\Controllers;

use App\Models\ContactosRecepcion;
use Illuminate\Http\Request;
use App\Models\Email;
use Illuminate\Support\Facades\Config;  // Importa la clase Config aquí
use Illuminate\Support\Facades\Mail;   // Importa la clase Mail si es necesaria

class EmailController extends Controller
{
    // Mostrar la lista de contactos
    public function index()
    {
        $emails = Email::all();
        return view('emails.index', compact('emails'));
    }
    public function addUser(Request $request)
    {
        $validatedData = $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|email|unique:contactos_recepcion',
            'telefono' => 'nullable|string|max:20',
        ]);

        $user = new ContactoRecepcion();
        $user->nombre = $validatedData['nombre'];
        $user->correo = $validatedData['correo'];
        $user->telefono = $validatedData['telefono'];
        $user->save();

        return redirect()->back()->with('success', 'Usuario añadido con éxito.');
    }

    // Almacenar un nuevo contacto
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|email',
            'telefono' => 'nullable|string|max:20',
        ]);

        // Crear el nuevo contacto
        Email::create($validatedData);

        return response()->json(['success' => true]);
    }


    // Editar un contacto
    public function edit($id)
    {
        $email = Email::findOrFail($id);
        return view('emails.edit', compact('email'));
    }

    // Actualizar un contacto
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'nombre' => 'required|string|max:255',
            'correo' => 'required|email',
            'telefono' => 'nullable|string|max:20',
            'es_defecto' => 'boolean',
        ]);

        // Si es predeterminado, desactivar el predeterminado anterior
        if ($request->es_defecto) {
            Email::where('es_defecto', true)->update(['es_defecto' => false]);
        }

        // Actualizar el contacto
        $email = Email::findOrFail($id);
        $email->update($validatedData);

        return redirect()->back()->with('success', 'Contacto actualizado correctamente.');
    }

    // Eliminar un contacto
    public function destroy($id)
    {
        $email = Email::findOrFail($id);
        $email->delete();

        return redirect()->back()->with('success', 'Contacto eliminado correctamente.');
    }

    public function send(Request $request)
    {
        $request->validate([
            'destinatarios' => 'required|array',
            'destinatarios.*' => 'email',
        ]);

        foreach ($request->destinatarios as $correo) {
            Mail::raw('Este es un correo de prueba.', function ($message) use ($correo) {
                $message->to($correo)->subject('Correo Automático');
            });
        }

        return redirect()->back()->with('success', 'Correos enviados correctamente.');
    }

    public function configuracion()
    {
        // Obtén el correo predeterminado desde el archivo de configuración
        $email_predeterminado = Config::get('app.email_predeterminado');
        return view('emails.configuracion', compact('email_predeterminado'));
    }

    public function guardarConfiguracion(Request $request)
    {
        $validatedData = $request->validate([
            'email_predeterminado' => 'required|email',
        ]);

        // Guardar en el archivo .env
        file_put_contents(app()->environmentFilePath(), str_replace(
            'EMAIL_PREDETERMINADO=' . env('EMAIL_PREDETERMINADO'),
            'EMAIL_PREDETERMINADO=' . $validatedData['email_predeterminado'],
            file_get_contents(app()->environmentFilePath())
        ));

        // Recargar las variables de entorno
        $this->refreshEnv();

        return redirect()->back()->with('success', 'Configuración guardada correctamente.');
    }

    protected function refreshEnv()
    {
        // Recarga el archivo .env para que los cambios tengan efecto inmediatamente
        if (file_exists(app()->environmentFilePath())) {
            foreach (file(app()->environmentFilePath(), FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                [$name, $value] = array_pad(explode('=', $line, 2), 2, null);
                $_ENV[$name] = $value;
                putenv("$name=$value");
            }
        }
    }

    public function getEmails(Request $request)
    {
        try {
            // Verificar si hay un término de búsqueda
            $search = $request->input('q');

            // Obtener los correos electrónicos desde la base de datos con búsqueda
            $emails = ContactosRecepcion::select('id', 'correo')
                        ->when($search, function ($query) use ($search) {
                            return $query->where('correo', 'like', '%' . $search . '%');
                        })
                        ->get();

            // Devolver los correos en formato JSON
            return response()->json($emails);
        } catch (\Exception $e) {
            // Manejar cualquier error y devolver una respuesta de error
            return response()->json(['error' => 'Ocurrió un error al cargar los correos.'], 500);
        }
    }
}
