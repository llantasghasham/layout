<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Fac_Elec_Controller extends Controller
{
    //
}
