<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Services\CorreoService;
use App\Models\ConfiguracionCorreo;
use App\Utils\TransactionUtil;
use App\Utils\FacturacioncostaricaUtil;
use Illuminate\Support\Facades\File;

class FacturasRecibidasController extends Controller
{
    protected $correoService;

    protected $transactionUtil;

    /**
     * Constructor
     * 
     * @param CorreoService $correoService
     */
    public function __construct(CorreoService $correoService,TransactionUtil $transactionUtil)
    {
        $this->correoService = $correoService;
        $this->transactionUtil = $transactionUtil;
        
    }

    /**
     * Muestra todas las facturas recibidas.
     */
    public function index()
    {
        $this->processAll();

        $facturas = DB::table('facturas_recibidas')->get();

        return view('facturas_recibidas.index', compact('facturas'));
    }

    /**
     * Descarga un archivo PDF de una factura.
     * 
     * @param int $id
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse|\Illuminate\Http\JsonResponse
     */
    public function downloadPDF($id)
    {
        $factura = DB::table('facturas_recibidas')->where('id', $id)->first();
        $directorioRemitente = public_path("facturas_recibidas/{$factura->id}-{$factura->correo_origen}/");

        $path = $directorioRemitente . $factura->nombre_archivo_pdf;

        if (!file_exists($path)) {
            return response()->json(['success' => false, 'message' => 'El archivo PDF no existe.'], 404);
        }

        return response()->download($path);
    }

    /**
     * Descarga un archivo XML de una factura.
     * 
     * @param int $id
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse|\Illuminate\Http\JsonResponse
     */
    public function downloadXML($id)
    {
        $factura = DB::table('facturas_recibidas')->where('id', $id)->first();
        $directorioRemitente = public_path("facturas_recibidas/{$factura->id}-{$factura->correo_origen}/");

        $path = $directorioRemitente . $factura->nombre_archivo_xml;

        if (!file_exists($path)) {
            return response()->json(['success' => false, 'message' => 'El archivo XML no existe.'], 404);
        }

        return response()->download($path);
    }

    /**
     * Elimina una factura recibida.
     * 
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $factura = DB::table('facturas_recibidas')->where('id', $id)->first();

        $directorioRemitente = public_path("facturas_recibidas/{$factura->id}-{$factura->correo_origen}/");

        if (!$factura) {
            return redirect()->route('facturas-recibidas.index')->with('error', 'Factura no encontrada.');
        }

        // Eliminar la carpeta del remitente
        $this->deleteFolder($directorioRemitente);

        // Elimina el registro de la base de datos
        DB::table('facturas_recibidas')->where('id', $id)->delete();

        return redirect()->route('facturas-recibidas.index')->with('success', 'Factura eliminada correctamente.');
    }

    /**
     * Obtiene correos configurados para importar facturas adjuntas.
     * 
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function importarCorreos(Request $request)
    {
        try {
            // Simula la obtención de correos
            $correosConfigurados = DB::table('configuracion_correos')
                ->where('activo', true)
                ->select('correo')
                ->get();

            if ($correosConfigurados->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'No hay correos configurados para importar.',
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Correos cargados correctamente.',
                'data' => $correosConfigurados,
            ]);
        } catch (\Exception $e) {
            \Log::error('Error al importar correos: ' . $e->getMessage()); // Log para errores
            return response()->json([
                'success' => false,
                'message' => 'Error al importar correos: ' . $e->getMessage(),
            ]);
        }
    }

    /**
     * Importa facturas de los correos seleccionados.
     * 
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function importarFacturas(Request $request)
    {
        $request->validate([
            'correoSeleccionado' => 'required|email',
        ]);

        try {
            $correoSeleccionado = $request->correoSeleccionado;

            // Llamar a la función para importar facturas con la configuración del correo
            $result = $this->correoService->importarCorreos($correoSeleccionado);

            return response()->json([
                'success' => true,
                'message' => 'Facturas importadas correctamente desde ' . $correoSeleccionado,
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al importar facturas: ' . $e->getMessage(),
            ]);
        }
    }

    public function read_xml($TMP_NAME, $NAME)
    {
        $archivo = null;
        $archivo = simplexml_load_file($TMP_NAME);
        $clave = strval($archivo->Clave);
        $consecutivo = strval($archivo->NumeroConsecutivo);

        //inicio de divicion de consecutivo
        $sucursal = substr($consecutivo, 0, 3);
        $tipodoc = substr($consecutivo, 8, 2);
        $puntoventa = substr($consecutivo, 3, 5);
        $numerofactura = substr($consecutivo, -10);
        // fin

        $fecha = strval($archivo->FechaEmision);
        $rutaxml = "xmlreception/facturacompra/".$NAME;
        $emisor = strval($archivo->Emisor->Nombre);
        $receptor = strval($archivo->Receptor->Nombre);
        $numeroe = strval($archivo->Emisor->Identificacion->Numero);
        $emisornombre = strval($archivo->Emisor->NombreComercial);

        $numeror = strval($archivo->Receptor->Identificacion->Numero);
        $total = strval($archivo->ResumenFactura->TotalComprobante);
        $impuesto = strval($archivo->ResumenFactura->TotalImpuesto);
        $productototal = strval($archivo->ResumenFactura->TotalComprobante);
        $cod_actividad = strval($archivo->CodigoActividad);
        $CodigoMoneda = "CRC";

        // inf adicional
        if ($tipodoc == '05' || $tipodoc == '01' || $tipodoc == '02' || $tipodoc == '03' || $tipodoc == '04') {
            $mensaje = 1;
        } elseif ($tipodoc == '06') {
            $mensaje = 2;
        } elseif ($tipodoc == '07') {
            $mensaje = 3;
        }

        $fecha_actual = date("yy-m-d", time());
        $data = array(
          "clave" => $clave,
          "emisor" => $emisor,
          "mensaje" => $mensaje,
          "impuesto" => $impuesto,
          "numerofactura" => $numerofactura,
          "puntoventa" => $puntoventa,
          "consecutivo" => $consecutivo,
          "total" => $total,
          "tipodoc" => $tipodoc,
          "sucursal" => $sucursal,
          "emisornombre" => $emisornombre,
          "productototal" => $productototal,
          "numero" => $numeroe,
          "rutaxml" => $rutaxml,
          "receptor" => $receptor,
          "numeror" => $numeror,
          "fecha" => $fecha,
          "status" => 0,
          "fecha_subido" => $fecha_actual,
          "cod_actividad" => $cod_actividad,
          "CodigoMoneda" => $CodigoMoneda,
          "success" => true,
        );

        return $data;
    }

    /**
     * Procesar archivo XML pero sin redireccionar.
     * 
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function processWithOutRedirect($id)
    {
        date_default_timezone_set('America/Costa_Rica');

        // Buscar la factura en la base de datos
        $factura = DB::table('facturas_recibidas')->where('id', $id)->first();
        if (!$factura) {
            return response()->json([
                'success' => false,
                'message' => 'Factura no encontrada.',
            ]);
        }

        // Construir la ruta del archivo XML
        $directorioRemitente = public_path("facturas_recibidas/{$factura->id}-{$factura->correo_origen}/");
        $path = $directorioRemitente . $factura->nombre_archivo_xml;

        // Verificar si el archivo existe
        if (!file_exists($path)) {
            return response()->json([
                'success' => false,
                'message' => 'El archivo XML no existe.',
            ]);
        }

        $xml = simplexml_load_file($path);
        $validar = strval($xml->NumeroConsecutivo);

        \Log::error('Validar: '.$validar);

        if ($validar != "") {
            // Leer y procesar el XML usando la función read_xml()
            $data = $this->read_xml($path, $factura->nombre_archivo_xml);
            $business_id = request()->session()->get('user.business_id');

            // Verificar si el documento ya está en la base de datos
            if (!$this->transactionUtil->getExistDocuments($data["consecutivo"])) {
                // Guardar en la base de datos
                $this->transactionUtil->addDocumentsReception($business_id, $data);
                File::move($path, $data["rutaxml"]);
                \Log::error('Documento movido de '.$path.' a '.$data["rutaxml"]);
            }else{
                \Log::error('Documento no movido de '.$path.' a '.$data["rutaxml"]);
            }

            // Obtener documentos pendientes de recepción
            $doc_recep = $this->transactionUtil->getDocumentsReceptionPend($business_id);
            
            if (count($doc_recep) > 0) {
                // Tomar el primer documento pendiente
                $doc = $doc_recep[0];
    
                // Datos de seguridad y conexión con Hacienda
                $certificado = 'xml/' . $doc->certificado;
                $clave_certificado = $doc->llavecripto;
                $credenciales_conexion = $doc->username;
                $clave_conexion = $doc->password;
    
                $xml = [
                    'tipoDocumento' => $doc->tipodoc, 
                    'sucursal' => $doc->sucursal, 
                    'puntoVenta' => $doc->puntoventa, 
                    'numeroFactura' => $doc->numerofactura, 
                    'fechaEmision' => $doc->fecha, 
                    'rutaxml' => $doc->rutaxml, 
                    'Emisor' => [
                        'NumeroCedulaEmisor' => $doc->numero,
                        'Mensaje' => $doc->mensaje, 
                        'MontoTotalImpuesto' => $doc->impuesto, 
                        'TotalFactura' => $doc->total, 
                        'DetalleMensaje' => 'Informacion detallada' 
                        ]
                ];

                \Log::error('xml: ' . json_encode($xml, JSON_PRETTY_PRINT));
    
                $seguridad = [
                    'certificado' => $certificado,
                    'clave_certificado' => $clave_certificado,
                    'credenciales_conexion' => $credenciales_conexion,
                    'clave_conexion' => $clave_conexion,
                    'client_id' => 'api-prod' // 'api-stag' para pruebas y 'api-prod' para producción
                ];

                \Log::error('seguridad: ' . json_encode($seguridad, JSON_PRETTY_PRINT));
    
                // Enviar documento a Hacienda
                $facturar = null;
                try {
                    $facturar = new FacturacioncostaricaUtil($xml, $seguridad);
                } catch (\Exception $e) {
                    return response()->json([
                        'success' => false,
                        'message' => $e->getMessage(),
                    ]);
                }
                
                \Log::error('Llegue aqui');
                $response = $facturar->envia_documento_receptor();

                // Marcar documento como procesado
                $this->transactionUtil->updateDocumentsReception($business_id, $doc->id);
                if($response == 400){
                    return response()->json([
                        'success' => false,
                        'message' => 'Este documento ya fue enviado.',
                    ]);
                }else{
                    if($factura->nombre_archivo_pdf != 'No') {
                        // Actualizar el valor en la base de datos
                        DB::table('facturas_recibidas')
                        ->where('id', $id)
                        ->update(['nombre_archivo_xml' => 'Procesado']);
                        Storage::delete($directorioRemitente . $factura->nombre_archivo_xml);
                    }else{
                        // Eliminar la carpeta del remitente y la factura de la base de datos
                        $this->deleteFolder($directorioRemitente);
                        DB::table('facturas_recibidas')->where('id', $id)->delete();
                    }
                    return response()->json([
                        'success' => true,
                        'message' => 'Factura enviada y eliminada del espacio temporal correctamente.',
                    ]);
                }
            }else{
                return response()->json([
                    'success' => false,
                    'message' => 'Este documento ya fue enviado.',
                ]);
            }
        }
        return response()->json([
            'success' => false,
            'message' => 'Este documento ya fue enviado.',
        ]);
    }

    /**
     * Procesa un archivo XML de una factura almacenada en el servidor.
     * 
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function process($id)
    {
        // Llamar a la función processWithOutRedirect
        $response = $this->processWithOutRedirect($id);

        // Decodificar la respuesta JSON
        $data = $response->getData(true);

        // Redirigir a la ruta facturas-recibidas.index con mensaje de éxito o error
        return redirect()->route('facturas-recibidas.index')->with(
            $data['success'] ? 'success' : 'error',
            $data['message']
        );
    }

    /**
     * Procesa todas las facturas almacenadas en la base de datos sin redirigir.
     * 
     * @return \Illuminate\Http\JsonResponse
     */
    public function processAll()
    {
        $facturas = DB::table('facturas_recibidas')->get();
        $procesadas = 0;
        $errores = 0;
        $detallesErrores = [];

        foreach ($facturas as $factura) {
            if ($factura->nombre_archivo_xml != "No" && $factura->nombre_archivo_xml != "Procesado") {
                $response = $this->processWithOutRedirect($factura->id);
                $data = $response->getData(true);

                if ($data['success']) {
                    $procesadas++;
                } else {
                    $errores++;
                    $detallesErrores[] = [
                        'factura_id' => $factura->id,
                        'mensaje' => $data['message']
                    ];
                }
            }
        }

        return response()->json([
            'success' => $errores === 0,
            'facturas_procesadas' => $procesadas,
            'errores' => $errores,
            'detalle_errores' => $detallesErrores
        ]);
    }

    /**
     * Elimina una carpeta y su contenido
     *
     * @param string $folderPath
     */
    private function deleteFolder($folderPath)
    {
        if (!is_dir($folderPath)) {
            return;
        }

        $files = array_diff(scandir($folderPath), ['.', '..']);

        foreach ($files as $file) {
            $filePath = $folderPath . DIRECTORY_SEPARATOR . $file;
            is_dir($filePath) ? $this->deleteFolder($filePath) : unlink($filePath);
        }

        rmdir($folderPath);
    }
}
