<?php

namespace App\Http\Controllers;

use App\Chat;
use App\Message;
use Illuminate\Http\Request;
use App\Notifications\NewMessage;

class MessageController extends Controller
{
    public function show($id)
    {
        $message = Message::findOrFail($id);

        return view('message.show', ['message' => $message]);
    }

    public function store(Request $request)
    {
        $chat = Chat::findOrFail($request->chat_id);

        if (!$chat->users->contains($request->user())) {
            return response('Forbidden', 403);
        }

        $message = new Message();
        $message->user_id = $request->user()->id;
        $message->chat_id = $request->chat_id;
        $message->content = $request->content;

        $message->save();

        foreach ($chat->users as $user) {
            if ($user->id != $request->user()->id) {
                $user->notify(new NewMessage($message));
            }
        }

        return back();
    }
}
