<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NotCreElc_Controller extends Controller
{
    //
}
