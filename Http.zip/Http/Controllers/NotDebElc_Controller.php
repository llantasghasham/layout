<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NotDebElc_Controller extends Controller
{
    //
}
