<?php

namespace App\Http\Controllers;

use App\BusinessLocation;
use App\Contact;
use App\TaxRate;
use App\User;
use App\Utils\BusinessUtil;
use App\Utils\ModuleUtil;
use App\Utils\ProductUtil;
use App\Utils\TransactionUtil;
use App\Utils\FacturacioncostaricaUtil;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\InvoicesReportMail; //referencia para el env���o de correos
use App\Account;
use App\ExpenseCategory;
use App\Exports\ReceiptsExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;

class RecElecController extends Controller
{
    protected $productUtil;
    protected $transactionUtil;
    protected $moduleUtil;

    public function __construct(
        ProductUtil $productUtil,
        TransactionUtil $transactionUtil,
        BusinessUtil $businessUtil,
        ModuleUtil $moduleUtil
    ) {
        $this->productUtil = $productUtil;
        $this->transactionUtil = $transactionUtil;
        $this->businessUtil = $businessUtil;
        $this->moduleUtil = $moduleUtil;

        $this->dummyPaymentLine = [
            'method' => 'cash',
            'amount' => 0,
            'note' => '',
            'card_transaction_number' => '',
            'card_number' => '',
            'card_type' => '',
            'card_holder_name' => '',
            'card_month' => '',
            'card_year' => '',
            'card_security' => '',
            'cheque_number' => '',
            'bank_account_number' => '',
            'is_return' => 0,
            'transaction_no' => ''
        ];
    }

    // Funci���n para mostrar la vista principal de las recepciones electr���nicas
    public function index()
    {
        $business_id = request()->session()->get('user.business_id');

        // Verificar si la suscripci���n est��� activa
        if (!$this->moduleUtil->isSubscribed($business_id)) {
            return $this->moduleUtil->expiredResponse(action('ExpenseController@index'));
        }

        // Obtener las ubicaciones de negocio, usuarios, impuestos, etc.
        $business_locations = BusinessLocation::forDropdown($business_id, false, true);
        $bl_attributes = $business_locations['attributes'];
        $business_locations = $business_locations['locations'];
        $expense_categories = ExpenseCategory::where('business_id', $business_id)->pluck('name', 'id');
        $users = User::forDropdown($business_id, true, true);
        $taxes = TaxRate::forBusinessDropdown($business_id, true, true);
        $payment_line = $this->dummyPaymentLine;
        $payment_types = $this->transactionUtil->payment_types(null, false, $business_id);
        $contacts = Contact::contactDropdown($business_id, false, false);
        $accounts = [];

        if ($this->moduleUtil->isModuleEnabled('account')) {
            $accounts = Account::forDropdown($business_id, true, false, true);
        }

        return view('recepcion_electronica.index')
            ->with(compact('expense_categories', 'business_locations', 'users', 'taxes', 'payment_line', 'payment_types', 'accounts', 'bl_attributes', 'contacts'));
    }

    // Funci���n para listar las recepciones electr���nicas
    public function listado(Request $request)
    {
        $business_id = request()->session()->get('user.business_id');

        if ($request->ajax()) {
            $start_date = $request->start_date ?? date("Y-m-d", strtotime('-90 days'));
            $end_date = $request->end_date ?? date("Y-m-d");
            $location_id = $request->location_id ?? null;
            $statuses_id = $request->statuses_id ?? null;

            // Obtener las recepciones de documentos, asegur���ndonos de seleccionar el campo 'consecutivo'
            $purchases = $this->transactionUtil->getDocumentsReception($business_id, $start_date, $end_date, $location_id, $statuses_id);

            return Datatables::of($purchases)
                ->addColumn('rutaxml', function ($row) {
                    return '<a href="'.url($row->rutaxml).'" download type="button" class="btn btn-info btn-xs">Descargar</a>';
                })
                ->editColumn('fecha', '{{@format_datetime($fecha)}}')
                ->editColumn('impuesto', '<span class="final_total text-right" data-orig-value="{{$impuesto}}">@format_currency($impuesto)</span>')
                ->editColumn('total', '<span class="final_total" data-orig-value="{{$total}}">@format_currency($total)</span>')
                ->editColumn('status', '<span class="label label-success">@if ($status == 1) Aceptado @else Rechazado @endif </span>')
                ->addColumn('consecutivo', function ($row) { // A���adir la columna 'consecutivo'
                    return $row->consecutivo;
                })
                ->rawColumns(['rutaxml', 'fecha', 'impuesto', 'total', 'status', 'consecutivo'])
                ->make(true);
        }

        // Cargar las ubicaciones de negocio, proveedores, y estados
        $business_locations = BusinessLocation::forDropdown($business_id);
        $suppliers = Contact::suppliersDropdown($business_id, false);
        $statuses = [
            "0" => "Pendiente",
            "1" => "Aceptado",
            "2" => "Rechazado",
        ];

        return view('recepcion_electronica.listado')->with(compact('business_locations', 'suppliers', 'statuses'));
    }


    // Funci���n para enviar reportes de recepciones electr���nicas por correo
    public function sendRecepcionesReport(Request $request)
    {
        $receipts = $this->transactionUtil->getDocumentsReception(
            request()->session()->get('user.business_id'),
            $request->input('start_date'),
            $request->input('end_date'),
            $request->input('location_id'),
            $request->input('statuses_id')
        );

        // Aseg���rate de que $receipts es una colecci���n
        $receiptsCollection = collect($receipts);

        // Generar el archivo Excel
        $fileName = 'reporte_facturas_' . now()->format('Ymd_His') . '.xlsx';
        Excel::store(new ReceiptsExport($receiptsCollection), $fileName);

        // Enviar el correo con el archivo adjunto
        Mail::to($request->input('emails'))->send(new InvoicesReportMail($fileName));

        // Eliminar el archivo despu���s de enviarlo
        Storage::delete($fileName);

        return back()->with('success', 'Reporte enviado con ���xito.');
    }


    public function send()
    {
        $valor = array();
        $this->db->where('company', $_GET['id']);
        $q = $this->db->get('data_factura_electronica');

        if ($q->num_rows() == 0) {
            $datos = false;
            $datos["elementos"] = 0;
            $datos["hacienda"] = 0;
            echo json_encode($datos);
        } else {
            $datos["elementos"] = $q->result();
            $elementos = $q->row();
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.hacienda.go.cr/fe/ae?identificacion=".$elementos->identification,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => false,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "GET",
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            $datos["hacienda"] = "cURL Error #:" . $err;
        } else {
            $datos["hacienda"] = array(trim($response, " \n."));
        }

        $valor[] = $datos;

        echo json_encode($datos);
    }

    public function read_xml($TMP_NAME, $NAME)
    {
        $archivo = null;
        $archivo = simplexml_load_file($TMP_NAME);
        $clave = strval($archivo->Clave);
        $consecutivo = strval($archivo->NumeroConsecutivo);

        //inicio de divicion de consecutivo
        $sucursal = substr($consecutivo, 0, 3);
        $tipodoc = substr($consecutivo, 8, 2);
        $puntoventa = substr($consecutivo, 3, 5);
        $numerofactura = substr($consecutivo, -10);
        // fin

        $fecha = strval($archivo->FechaEmision);
        $rutaxml = "xmlreception/facturacompra/".$NAME;
        $emisor = strval($archivo->Emisor->Nombre);
        $receptor = strval($archivo->Receptor->Nombre);
        $numeroe = strval($archivo->Emisor->Identificacion->Numero);
        $emisornombre = strval($archivo->Emisor->NombreComercial);

        $numeror = strval($archivo->Receptor->Identificacion->Numero);
        $total = strval($archivo->ResumenFactura->TotalComprobante);
        $impuesto = strval($archivo->ResumenFactura->TotalImpuesto);
        $productototal = strval($archivo->ResumenFactura->TotalComprobante);
        $cod_actividad = strval($archivo->CodigoActividad);
        $CodigoMoneda = "CRC";

        // inf adicional
        if ($tipodoc == '05' || $tipodoc == '01' || $tipodoc == '02' || $tipodoc == '03' || $tipodoc == '04') {
            $mensaje = 1;
        } elseif ($tipodoc == '06') {
            $mensaje = 2;
        } elseif ($tipodoc == '07') {
            $mensaje = 3;
        }

        $fecha_actual = date("yy-m-d", time());
        $data = array(
          "clave" => $clave,
          "emisor" => $emisor,
          "mensaje" => $mensaje,
          "impuesto" => $impuesto,
          "numerofactura" => $numerofactura,
          "puntoventa" => $puntoventa,
          "consecutivo" => $consecutivo,
          "total" => $total,
          "tipodoc" => $tipodoc,
          "sucursal" => $sucursal,
          "emisornombre" => $emisornombre,
          "productototal" => $productototal,
          "numero" => $numeroe,
          "rutaxml" => $rutaxml,
          "receptor" => $receptor,
          "numeror" => $numeror,
          "fecha" => $fecha,
          "status" => 0,
          "fecha_subido" => $fecha_actual,
          "cod_actividad" => $cod_actividad,
          "CodigoMoneda" => $CodigoMoneda,
          "success" => true,
          "mensaje" => $mensaje
        );

        return $data;
    }

    public function load()
    {
        $html = "";
        $documents = array(
           "data" => array(),
           "html" => "",
           "success" => true,
           "msg" => ""
        );
        $FILES = $_FILES["upload_document"];
        $i = 0;
        foreach ($FILES["tmp_name"] as $TMP_NAME) {
            $xml = simplexml_load_file($TMP_NAME);
            $validar = strval($xml->NumeroConsecutivo);
            if ($validar != "") {
                $NAME = $FILES["name"][$i];
                $rxml = $this->read_xml($TMP_NAME, $NAME);
                $html .= '<tr>'
                         . '<td class="w-16">'.$rxml["consecutivo"].'</th>'
                         . '<td class="w-16">'.$rxml["fecha"].'</th>'
                         . '<td>'.$rxml["emisor"].'</th>'
                         . '<td>'.$rxml["receptor"].'</th>'
                         . '<td>'.$rxml["impuesto"].'</th>'
                         . '<td>'.$rxml["rutaxml"].'</th>'
                      . '</tr>';
                array_push($documents["data"], $rxml);
            }
            $i++;
        }
        $documents["html"] = $html;
        $documents["msg"] = "Documentos cargados satisfactoriamente";

        echo json_encode($documents);
    }

    public function process()
    {
        date_default_timezone_set('America/Costa_Rica');

        $FILES = $_FILES["upload_document"];
        $i = 0;
        foreach ($FILES["tmp_name"] as $TMP_NAME) {
            $xml = simplexml_load_file($TMP_NAME);
            $validar = strval($xml->NumeroConsecutivo);

            if ($validar != "") {
                $NAME = $FILES["name"][$i];
                $data = $this->read_xml($TMP_NAME, $NAME);

                $business_id = request()->session()->get('user.business_id');
                if (!$this->transactionUtil->getExistDocuments($data["consecutivo"])) {
                    $reception = $this->transactionUtil->addDocumentsReception($business_id, $data);
                    move_uploaded_file($TMP_NAME, $data["rutaxml"]);
                }

                $doc_recep = $this->transactionUtil->getDocumentsReceptionPend($business_id);
                if (count($doc_recep) > 0) {
                    $certificado = 'xml/'.$doc_recep[0]->certificado;
                    $clave_certificado =  $doc_recep[0]->llavecripto;
                    $credenciales_conexion = $doc_recep[0]->username;
                    $clave_conexion = $doc_recep[0]->password;
                    $NombreComercial = $doc_recep[0]->name;

                    $province = 5;
                    $canton = "0.3";
                    $district = "0.1";
                    $neighborhood = 27;
                    $neighborhood = 27;

                    $xml = [
                       'tipoDocumento' => $doc_recep[0]->tipodoc, // 05 Aceptado 06 Parcialmente aceptado 07 rechazado
                       'sucursal' => $doc_recep[0]->sucursal , // 3 digitos sucursal de donde proviene el documento para el armado de clave
                       'puntoVenta' => $doc_recep[0]->puntoventa, // 5 digitos punto de venta del cual se armo el documento
                       'numeroFactura' =>  $doc_recep[0]->numerofactura, //correspondiente al numero del documento para el receptor
                       'fechaEmision' => $doc_recep[0]->fecha, // fecha de emision del documento no mayor a 72 horas, date_default_timezone_set debe ser costa rica
                       'rutaxml' => $doc_recep[0]->rutaxml, // ruta del xml para la factura es el XML recibido por el emisor
                       'Emisor' => array(
                          'NumeroCedulaEmisor' => $doc_recep[0]->numero, // cedula del emisor del documento
                          'Mensaje' => $doc_recep[0]->mensaje, // 1 para cuando el mensaje es aceptado, o en su defecto igual a 05, 2 para 06 y 3 para 07
                          'MontoTotalImpuesto' => $doc_recep[0]->impuesto, // Monto total del impuesto de la factura
                          'TotalFactura' => $doc_recep[0]->total, // Monto total de la factura
                          'DetalleMensaje' => 'Informacion detallada' // Alguna nota o detalle que queramos agregar para el Mensaje Receptor
                       )
                    ];

                    $seguridad =  [
                       'certificado' => $certificado, // Ruta del certificado donde se encuentra
                       'clave_certificado' => $clave_certificado, //clave del certificado .p12
                       'credenciales_conexion' => $credenciales_conexion, //credenciales de Hacienda
                       'clave_conexion' => $clave_conexion, //Contraseña de hacienda
                       'client_id' => 'api-prod' //api-stag para pruebas y api-prod para el entorno produccion
                    ];

                    $facturar = new FacturacioncostaricaUtil($xml, $seguridad);
                    $response = $facturar->envia_documento_receptor();
                    if ($response == 400) {
                        $this->transactionUtil->updateDocumentsReception($business_id, $doc_recep[0]->id);
                        $data = array(
                           "success" => false,
                           "msg" => "Este documento ya fue enviado!"
                        );
                    } else {
                        $this->transactionUtil->updateDocumentsReception($business_id, $doc_recep[0]->id);
                        $data = array(
                           "success" => true,
                           "msg" => "Facturas enviadas correctamente!"
                        );
                    }
                } else {
                    $data = array(
                       "success" => false,
                       "msg" => "Este documento ya fue enviado!"
                    );
                }
            }

            $i++;
        }

        echo json_encode($data);
    }

}

?> 