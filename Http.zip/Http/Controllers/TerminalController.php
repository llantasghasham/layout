<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Terminals;

class TerminalController extends Controller
{
    public function terminalByLocation($id_location)
    {
        $maquina = gethostbyaddr($_SERVER['REMOTE_ADDR']);
        $terminal = Terminals::where('id_location', '=', $id_location)
                            ->where('maquina', '=', $maquina)
                            ->get();
        return $terminal;
    }
    public function useterminal($id_location, $id_terminal)
    {
        $business_id = request()->session()->get('user.business_id');
        $user_id = request()->session()->get('user.id');

        $hoy = date('Y-m-d');
        $tabla = "terminals ";
        $datos = "* ";
        $condicion = "";

        $condicion = $condicion.'business_id='.$business_id.' ';
        /*$condicion=$condicion.'and id_location='.$id_location.' ';
        */
        $condicion = $condicion.'and fecha_used="'.$hoy.'" ';
        $condicion = $condicion.'and user_id='.$user_id.' ';
        $sql = 'select '.$datos.'from '.$tabla.'WHERE '.$condicion;
        $terminal = DB::select($sql);
        if (count($terminal) > 0) {
            $output = [
                'success' => true,
                'msg' => 'Ya ha elegido otro terminal.',
                'location_id' => $terminal[0]->id_location,
                'terminal_id' => $terminal[0]->id
            ];
            return $output;
        }

        $tabla = "terminals ";
        $datos = "* ";
        $condicion = "";
        $condicion = $condicion."business_id=".$business_id." ";
        $condicion = $condicion.'and id_location='.$id_location." ";
        $condicion = $condicion.'and id='.$id_terminal." ";
        $sql = 'select '.$datos.'from '.$tabla.'WHERE '.$condicion;
        $terminal = DB::select($sql);
        if (count($terminal) < 1) {
            $output = [
                'success' => false,
                'msg' => 'Ubicación no tiene terminal.'
            ];
            return $output;
        }
        $maquina = gethostbyaddr($_SERVER['REMOTE_ADDR']);
        if (!$terminal[0]->maquina == $maquina) {
            //si es administrador pasa
            $output = [
                'success' => false,
                'msg' => 'Terminal asignado a otra maquina.'
            ];
            return $output;
        }
        if (!$terminal[0]->user_id == $user_id and $terminal[0]->fecha_used == $hoy) {
            $output = [
                'success' => false,
                'msg' => 'Otro usuario lo esta usando.'
            ];
            return $output;
        } else {
            $tabla = "terminals ";
            $datos = "";
            //$datos=$datos."maquina='".$maquina."',";
            $datos = $datos."fecha_used='".$hoy."',";
            $datos = $datos."user_id=".$user_id." ";
            $condicion = "";
            $condicion = $condicion."business_id=".$business_id." ";
            $condicion = $condicion.'and id_location='.$id_location." ";
            $condicion = $condicion.'and id='.$id_terminal." ";
            $sql = 'UPDATE '.$tabla.'SET '.$datos.'WHERE '.$condicion;
            $voucher_electronic = DB::select($sql);
            $output = [
                'success' => true,
                'msg' => 'Terminal elegido.'
            ];
            return $output;
        }
    }
    public function addterminal($id_location)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            $maquina = gethostbyaddr($_SERVER['REMOTE_ADDR']);
            $tabla = "terminals ";
            $datos = "* ";
            $condicion = "";
            $condicion = $condicion."business_id=".$business_id." ";
            $condicion = $condicion.'and id_location='.$id_location." ";
            $condicion = $condicion."and maquina='".$maquina."' ";
            $sql = 'select '.$datos.'from '.$tabla.'WHERE '.$condicion;
            $terminal = DB::select($sql);
            if (count($terminal) < 1) {
                $business_id = request()->session()->get('user.business_id');
                $maquina = gethostbyaddr($_SERVER['REMOTE_ADDR']);
                $campos = "(business_id,id_location,maquina) ";
                $datos = "(".$business_id.",".$id_location.",'".$maquina."')";
                $sql = 'INSERT INTO '.$tabla.$campos.'VALUES '.$datos;
                $var = DB::select($sql);
                $output = [
                    'success' => true,
                    'msg' => "Un terminal fue creado. "
                ];
            } else {
                $output = [
                    'success' => false,
                    'msg' => "La maquina tiene el terminal ".$terminal[0]->id."."
                ];
            }
            return $output;
        } catch (Exception $e) {
            $output = [
                'success' => false,
                'msg' => $e->getMessage()
            ];
            return $output;
        }
    }
    public function delterminal($id_location, $id_terminal)
    {
        try {
            $business_id = request()->session()->get('user.business_id');
            $tabla = "terminals ";
            $condicion = "";
            $condicion = $condicion."business_id=".$business_id." ";
            $condicion = $condicion.'and id_location='.$id_location." ";
            $condicion = $condicion.'and id='.$id_terminal." ";
            $sql = 'DELETE FROM '.$tabla.'WHERE '.$condicion;
            $var = DB::select($sql);
            $output = [
                'success' => true,
                'msg' => "Un terminal borrado. "
            ];
            return $output;
        } catch (Exception $e) {
            $output = [
                'success' => false,
                'msg' => $e->getMessage()
            ];
            return $output;
        }
    }
}
