<?php 
namespace App\Http\Controllers;

use DB;
use App\BusinessLocation;
use App\Contact;
//use App\Utils\ModuleUtil;
use App\Utils\BusinessUtil;
use App\Utils\Util;
use Illuminate\Http\Request;
//use Spatie\Permission\Models\Permission;
//use Yajra\DataTables\Facades\DataTables;
use App\Utils\TransactionUtil;

require "../vendor/autoload.php";

class VoucherController extends Controller
{
    protected $commonUtil;
    protected $transactionUtil;
    protected $business_id;
    protected $businessUtil;

    public $data;
    public $ConfigMail;
    public $Asunto;
    public $certs;
    public $serial;
    public $name_space;

    public function __construct(
        BusinessUtil $businessUtil,
        Util $commonUtil,
        TransactionUtil $transactionUtil
    ) {
        $this->commonUtil     = $commonUtil;
        $this->transactionUtil = $transactionUtil;
        $this->businessUtil  = $businessUtil;

        $this->data      = '';
        $this->ConfigMail = '';
        $this->Asunto    = 'Asunto';

        $this->certs     = [];
        $this->serial    = "";
        $this->name_space = "";
    }
    public function index()
    {
        $this->business_id = request()->session()->get('user.business_id');
        //      $permitted_locations = auth()->user()->permitted_locations();
        $limite = 5;
        $pagina = 1;
        $Obj_Act = 'home_voucher_list';
        $datos = [
            'limite'     => $limite,
            'pagina'     => $pagina,
            'Obj_Act'    => $Obj_Act
        ];
        $text_pagina = $this->SpaginarHome($datos);
        $business_locations = BusinessLocation::forDropdown($this->business_id, false);
        $customers = Contact::customersDropdown($this->business_id, false);
        global $tipoCompro,$estadoCompro;
        include 'tablas.php';
        return view('home.index')
        ->with(compact(   //     'sources',
            'business_locations',
            'customers',
            'tipoCompro',
            'estadoCompro',
            'text_pagina'
        ));
    }
    public function paginarHome(Request $request)
    {
        $datos = $request->all();
        $salida = $this->SpaginarHome($datos);
        echo $salida;
    }
    public function SpaginarHome($datos)
    {
        $limite     = $datos['limite'];
        $pagina     = $datos['pagina'];
        $Obj_Act    = $datos['Obj_Act'];

        $respuesta = $this->consultaSqL($limite, $pagina);

        $VoucherElectronic = $respuesta['resultado'];
        $num_voucher = $respuesta['todos'];
        $desde = $respuesta['inicio'];
        $hasta = $respuesta['hasta'];
        if ($num_voucher < $hasta) {
            $hasta = $num_voucher;
        }

        global $tipoCompro,$estadoCompro;
        include 'tablas.php';
        $color = [
        '00' => '#EB984E',
        '01' => '#FEFEFE',
        '02' => '#FCE4C4',
        '03' => '#C0B99D',
        '04' => '#C3A492',
        '05' => '#D2B4DE',
        '06' => '#F8E469',
        '07' => '#ABEBC6',
        '08' => '#F1948A',
        '09' => '#58C3BB',
        '10' => '#58D68D'
        ];
        //

        $pagina_html = '';
        $pagina_html = $pagina_html.'<div class="table-responsive">';
        $pagina_html = $pagina_html.'<table class="table table-bordered table-striped ajax_view" id="voucher_electronico_table">';
        $pagina_html = $pagina_html.'<thead>';
        $pagina_html = $pagina_html.'<tr> ';
        $pagina_html = $pagina_html.'<th>&nbsp&nbsp&nbspFecha&nbsp&nbsp&nbsp</th>';
        $pagina_html = $pagina_html.'<th>Nº Transacción</th>';
        $pagina_html = $pagina_html.'<th>Nº del Comprobante</th>';
        $pagina_html = $pagina_html.'<th>Tipo del Comprobante</th>';
        $pagina_html = $pagina_html.'<th>Estado del Comprobante</th>';
        $pagina_html = $pagina_html.'<th>Monto Total</th>';
        $pagina_html = $pagina_html.'<th>Nº de Artículos</th>';
        $pagina_html = $pagina_html.'</tr>';
        $pagina_html = $pagina_html.'</thead>';
        $pagina_html = $pagina_html.'<tbody>';
        $lineaPagina = "";
        foreach ($VoucherElectronic as $Voucher) {
            $cod_comprobante = str_pad($Voucher->vauchertype, 2, "0", STR_PAD_LEFT);
            $cod_estadoCompro = str_pad($Voucher->vaucherElect_status, 2, "0", STR_PAD_LEFT);
            $lineaPagina = $lineaPagina.'<tr>';
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;">'.$Voucher->fechaEmision.'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;">'.$Voucher->invoice_no.'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;">';
            $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #FADBD8; color:#17202A; font-size: 100%" title="No enviado a hacienda" ';

            if ($Voucher->status == 1) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F9FB22; color:#17202A; font-size: 100%" title="Enviado a hacienda" ';
            }
            if ($Voucher->status == 2) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F8C471; color:#17202A; font-size: 100%" title="Recibido por hacienda" ';
            }
            if ($Voucher->status == 3) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #88FA64; color:#17202A; font-size: 100%" title="Aceptado por hacienda" ';
            }
            if ($Voucher->status == 4) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F1948A; color:#17202A; font-size: 100%" title="Rechazado por hacienda" ';
            }
            if ($Voucher->status == 5) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #D6EAF8; color:#17202A; font-size: 100%" title="Procesando por hacienda" ';
            }
            if ($Voucher->status == 6) {
                $atributo = 'padding-top:1px; padding-right:1px; padding-bottom:1px; padding-left:1px; background-color: #F1948A; color:#17202A; font-size: 100%" title="Error en el xml o ya se envio" ';
            }


            $lineaPagina = $lineaPagina.'<div style="'.$atributo.'" class="btn-group">&nbsp'.$Voucher->NumeroConsecutivo.'&nbsp</div>';
            '</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;">'.$tipoCompro[$cod_comprobante].'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;"><i> '.$estadoCompro[$cod_estadoCompro].' </i></td>'; //style="background-color:#EB984E"  '.$color[$cod_estadoCompro].'
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;">'.number_format($Voucher->final_total, 2).'</td>';
            $lineaPagina = $lineaPagina.'<td style="font-size:100%;">'.$Voucher->num_product.'</td>';
            $lineaPagina = $lineaPagina.'</tr>';
        }
        $pagina_html = $pagina_html.$lineaPagina;
        $pagina_html = $pagina_html.'</tbody>';
        $pagina_html = $pagina_html.'</table>';
        $pagina_html = $pagina_html.'</div>';
        //FOOTER
        $pagina_html = $pagina_html.'<div id="viendo">';
        $Cuantaslineas = 'Mostrando '.$desde.' a '.$hasta.' de '.$num_voucher.' entradas';
        $pagina_html = $pagina_html.$Cuantaslineas;
        $pagina_html = $pagina_html.'</div>';

        $pagina_html = $pagina_html.'<div class="card-body float-left" >';

        $pagina_html = $pagina_html.'<nav aria-label="Page navigation example" id="Para_ver">';
        $pagina_html = $pagina_html.'<ul class="pagination" id="Paginar">';
        $paginar = '';
        $total_pages = ceil($num_voucher / $limite);
        if ($total_pages > 1) {
            $control = '/VoucherController';
            if ($pagina > 1) {
                $primero = 1;
                $antes = $pagina - 1;
                $toEjecutar = $limite.",".$primero.",'".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginarinHome('.$toEjecutar.')"><span aria-hidden="true">Primero</span></a></li>';
                $toEjecutar = $limite.",".$antes.",'".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginarinHome('.$toEjecutar.')"><span aria-hidden="true">Anterior</span></a></li>';
            }

            $muestra = 1;
            $verPagina = 1;
            if ($pagina > 3) {
                $verPagina = $pagina - 2;
            }
            for ($i = $verPagina;$i <= $total_pages;$i++) {
                $toEjecutar = $limite.",".$i.",'".$Obj_Act."'";
                if ($pagina == $i) {
                    $paginar = $paginar.'<li class="page-item active"><a class="page-link" >'.$i.'</a></li>';
                } else {
                    $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginarinHome('.$toEjecutar.')">'.$i.'</a></li>';
                }
                $muestra = $muestra + 1;
                if ($muestra > 5) {
                    break;
                }
            }

            if ($pagina != $total_pages) {
                $despues = $pagina + 1;
                $toEjecutar = $limite.",".$despues.",'".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginarinHome('.$toEjecutar.')"><span aria-hidden="true">Siguiente</span></a></li>';
                $toEjecutar = $limite.",".$total_pages.",'".$Obj_Act."'";
                $paginar = $paginar.'<li class="page-item"><a class="page-link" href="javascript:paginarinHome('.$toEjecutar.')"><span aria-hidden="true">Ultima</span></a></li>';
            }
        }
        $pagina_html = $pagina_html.$paginar;
        $pagina_html = $pagina_html.'</ul>';
        $pagina_html = $pagina_html.'</nav>';
        $pagina_html = $pagina_html.'</div>';
        return $pagina_html;
    }
    public function consultaSqL($limite, $pagina)
    {
        $this->business_id = request()->session()->get('user.business_id');
        if ($pagina == 0) {
            $pagina = 1;
        }
        $inicio = ($pagina - 1) * $limite;
        // ************************
        // cuantos voucher electronicos hay
        $tabla = "voucher_electronic AS a ";
        $tabla = $tabla."INNER JOIN transactions AS b ON a.transaction_id=b.id ";
        $datos       = "COUNT(*) as num_voucher ";
        $condicion = "";
        $condicion = $condicion."a.business_id=".$this->business_id." ";

        //$agrupa="a.transaction_id,a.vauchertype,a.vaucherElect_status ";
        $agrupa = "a.transaction_id ";
        $sql = 'SELECT '.$datos;
        $sql = $sql.'FROM '.$tabla;
        $sql = $sql.'WHERE '.$condicion;
        $VoucherElectronic = DB::select($sql);
        $num_voucher = $VoucherElectronic[0]->num_voucher;

        //**********************
        $tabla = "voucher_electronic AS a ";
        $tabla = $tabla."INNER JOIN transactions AS b ON a.transaction_id=b.id ";
        $tabla = $tabla."LEFT JOIN transaction_sell_lines AS c ON a.transaction_id=c.transaction_id ";
        $datos       = "a.*, ";
        $datos = $datos."b.final_total,b.invoice_no,COUNT(a.transaction_id) as num_product ";
        $ordenar = "a.fechaEmision desc,a.transaction_id asc ";
        $sql = 'SELECT '.$datos;
        $sql = $sql.'FROM '.$tabla;
        $sql = $sql.'WHERE '.$condicion;
        $sql = $sql.'GROUP BY '.$agrupa;
        $sql = $sql.'ORDER BY '.$ordenar;
        $sql = $sql.'LIMIT '.$inicio.','.$limite;
        //$respuesta= $sql;
        $VoucherElectronic = DB::select($sql);

        $hasta = $inicio + $limite;
        $inicio = $inicio + 1;
        $respuesta = [
            'inicio' => $inicio,
            'hasta' => $hasta,
            'todos' => $num_voucher,
            'resultado' => $VoucherElectronic,
            'Consulta' => $sql
        ];
        return $respuesta;
        // ************************
    }
}
?> 