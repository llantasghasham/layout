<?php

namespace App\Http\Controllers;

use DB;
use DOMDocument;
use App\Voucher_Electronic;
use App\BusinessLocation;
use App\Contact;
use App\Transaction;
use Illuminate\Http\Request;
use App\Http\Requests;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Mail;
use App\Mail\InvoicesReportMail; // Añadimos esta referencia para el envío de correos

class VoucherElectronicController extends Controller
{
    public function index()
    {
        // Cargar todas las ubicaciones de negocios (sucursales)
        $business_locations = BusinessLocation::pluck('name', 'id');

        // Devolver la vista con las ubicaciones
        return view('voucher_electronic.index')->with(compact('business_locations'));
    }

    public function getVouchers(Request $request)
    {
        \Log::info('Fetching vouchers...');

        // Filtrar los comprobantes según los parámetros de búsqueda
        $vouchers = Voucher_Electronic::select([
            'transaction_id as transaction_no',
            'NumeroConsecutivo as voucher_no',
            'vauchertype as voucher_type',
            'vaucherElect_status as voucher_status',
            'TotalFactura as total_amount',
            'id'
        ]);

        // Aplicar filtros según la ubicación y el rango de fechas
        if ($request->has('voucher_location_id')) {
            $vouchers->where('location_id', $request->voucher_location_id);
        }
        if ($request->has('voucher_date_range')) {
            $dateRange = explode(' - ', $request->voucher_date_range);
            $vouchers->whereBetween('created_at', [$dateRange[0], $dateRange[1]]);
        }

        // Devuelve la tabla de datos
        return DataTables::of($vouchers)
            ->addColumn('action', function ($row) {
                return '<a href="'.route('vouchers.view', $row->id).'" class="btn btn-primary">Ver</a>
                        <a href="'.route('vouchers.download', $row->id).'" class="btn btn-success">Descargar</a>';
            })
            ->make(true);
    }

    // Función para descargar el comprobante
    public function download($id)
    {
        $voucher = Voucher_Electronic::find($id);

        // Aquí podrías generar un PDF o cualquier otro formato y devolverlo como una respuesta de descarga
        return response()->download(storage_path('app/public/vouchers/' . $voucher->file_name));
    }

    // Función para ver el comprobante
    public function view($id)
    {
        $voucher = Voucher_Electronic::findOrFail($id);
        return view('voucher_electronic.view', compact('voucher'));
    }

    // Función para enviar el reporte de facturas electrónicas por correo
    public function sendInvoicesReport(Request $request)
    {
        // Filtrar facturas electrónicas según los filtros aplicados
        $filters = $request->all();
        $invoices = Voucher_Electronic::filter($filters)->get();

        // Generar el reporte y enviarlo por correo
        Mail::to($request->emails)->send(new InvoicesReportMail($invoices));

        return back()->with('success', 'El reporte ha sido enviado con éxito.');
    }
}
