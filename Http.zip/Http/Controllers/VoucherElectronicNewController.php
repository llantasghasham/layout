<?php

namespace App\Http\Controllers;

use App\Mail\VoucherMail;
use App\Models\VoucherElectronic;
use App\Models\BusinessLocation;
use App\Models\Contact;
use Illuminate\Http\Request;
use phpDocumentor\Reflection\Types\Boolean;
use Yajra\DataTables\Facades\DataTables;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\VouchersByCompanyExport;
use App\Mail\VouchersListMail;
use App\Mail\VouchersCompressedMail;
use ZipArchive;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class VoucherElectronicNewController extends Controller
{
    public function index(Request $request)
    {
        $locations = BusinessLocation::all();
        $clients = Contact::all();

        $document_types = [
            '1' => 'Factura Electrónica',
            '2' => 'Nota Débito Electrónica',
            '3' => 'Nota Crédito Electrónica',
            '4' => 'Tiquete Electrónico',
            '5' => 'Mensaje Receptor',
            '7' => 'Rechazo Receptor',
            '8' => 'Factura Electrónica de Compra',
            '9' => 'Factura Electrónica de Exportación',
        ];

        return view('voucher_electronic_new.index', compact('locations', 'clients', 'document_types'));
    }


    public function getData(Request $request)
    {
        $query = VoucherElectronic::with(['businessLocation', 'contact'])
            ->when($request->location_id, function ($query) use ($request) {
                return $query->whereHas('businessLocation', function ($q) use ($request) {
                    $q->where('city', $request->location_id);
                });
            })
            ->when($request->company_id, function ($query) use ($request) {
                return $query->whereHas('businessLocation', function ($q) use ($request) {
                    $q->where('name', $request->company_id);
                });
            })
            ->when($request->client_id, function ($query) use ($request) {
                return $query->whereHas('contact', function ($q) use ($request) {
                    $q->where('name', $request->client_id);
                });
            })
            ->when($request->status, function ($query) use ($request) {
                return $query->where('status', $request->status);
            })
            ->when($request->date_range, function ($query) use ($request) {
                [$start, $end] = explode(' ~ ', $request->date_range);
                return $query->whereBetween('fechaEmision', [$start, $end]);
            })
            ->orderBy('fechaEmision', 'desc');

        return DataTables::of($query)
            ->addColumn('location_city', function ($row) {
                return $row->businessLocation->city ?? 'N/A';
            })
            ->addColumn('company_name', function ($row) {
                return $row->businessLocation->name ?? 'N/A';
            })
            ->addColumn('client_name', function ($row) {
                return $row->cliente ?? 'N/A';
            })
            ->addColumn('numero_factura_interna', function ($row) {
                return $row->numero_factura_interna ?? 'N/A';
            })
            ->editColumn('total_factura', function ($row) {
                return number_format($row->total_factura, 2, '.', ',');
            })
            ->editColumn('impuesto_total', function ($row) {
                return number_format($row->impuesto_total, 2, '.', ',');
            })
            ->editColumn('invoice_no', function ($row) {
                $invoice_no = $row->invoice_no;
                $atributo = 'padding: 1px; background-color: #FADBD8; color:#17202A; font-size: 12px" title="No enviado a hacienda"';
                if (isset($row->estado)) {
                    $estado = str_pad($row->estado, 2, "0", STR_PAD_LEFT);
                    $color = [
                        '00' => '#FFFFFF',
                        '01' => '#F9FB22',
                        '02' => '#F8C471',
                        '03' => '#77DD77',
                        '04' => '#FF0000',
                        '05' => '#D6EAF8',
                        '06' => '#F1948A',
                    ];

                    $mensaje = [
                        '00' => 'No enviado a hacienda',
                        '01' => 'Enviado a hacienda',
                        '02' => 'Recibido por hacienda',
                        '03' => 'Aceptado por hacienda',
                        '04' => 'Rechazado por hacienda',
                        '05' => 'Procesando por hacienda',
                        '06' => 'Error en el xml o ya fue enviado',
                    ];
                    $atributo = 'padding: 1px; background-color: ' . $color[$estado] . '; color:#17202A; font-size: 12px" title="' . $mensaje[$estado] . '"';
                }

                return '<div style="' . $atributo . '" class="btn-group">&nbsp' . $invoice_no . '&nbsp</div>';
            })
            ->addColumn('voucher_type', function ($row) {
                return $this->getVoucherTypeText($row->vauchertype)['desTipoDoc'];
            })
            ->addColumn('voucher_status', function ($row) {
                return $this->getVoucherStatusText($row->status);
            })
            ->addColumn('action', function ($row) {
                return $this->getActionButtons($row);
            })
            ->rawColumns(['action', 'invoice_no'])
            ->make(true);
    }

    public function processVoucher($voucherId)
    {
        $xmlPath = $this->getXmlPathForVoucher($voucherId);
        if (!file_exists($xmlPath)) {
            Log::warning("No se encontró el archivo XML para el voucher ID: {$voucherId}");
            return;
        }

        try {
            $xmlString = file_get_contents($xmlPath);
            $xml = simplexml_load_string($xmlString);

            // Manejo de namespaces si existen
            $namespaces = $xml->getNamespaces(true);
            $xml->registerXPathNamespace('ns', $namespaces[''] ?? '');

            // Extracción del nombre del cliente
            $clientName = (string) $xml->xpath("//ns:Receptor/ns:Nombre")[0];
            if (!$clientName) {
                Log::warning("No se encontró el nombre del cliente en el XML del voucher ID: {$voucherId}");
                $clientName = "N/A";
            }

            // Extracción del número de factura interna
            $numeroFacturaInterna = "N/A";
            foreach ($xml->xpath("//ns:Otros/ns:OtroTexto") as $otroTexto) {
                if (strpos($otroTexto, 'Codigo:') !== false) {
                    $numeroFacturaInterna = trim(explode('Codigo:', $otroTexto)[1]);
                    break;
                }
            }

            Log::info("Cliente: {$clientName}, Numero Factura Interna: {$numeroFacturaInterna}");

        } catch (\Exception $e) {
            Log::error("Error al procesar el voucher ID: {$voucherId} - " . $e->getMessage());
        }
    }

    public function pruebaCliente()
    {
        $xmlPath = '/home3/llantase/public_html/POS/public/xml/liberia/014000010100000059141FE.xml';

        if (file_exists($xmlPath)) {
            try {
                $xmlString = file_get_contents($xmlPath);
                $xml = simplexml_load_string($xmlString);

                // Registrar el namespace con un alias (por ejemplo, "ns")
                $namespaces = $xml->getNamespaces(true);
                $xml->registerXPathNamespace('ns', $namespaces['']);

                // Verifica el nombre del cliente usando el namespace
                $clienteElement = $xml->xpath('//ns:Receptor/ns:Nombre');
                $cliente = !empty($clienteElement) && isset($clienteElement[0]) ? (string)$clienteElement[0] : 'No se encontró el nombre del cliente';

                // Verifica el número de factura interna usando el namespace
                $otrosElement = $xml->xpath('//ns:Otros/ns:OtroTexto');
                $numeroFacturaInterna = 'No se encontró el número de factura interna';
                if (!empty($otrosElement) && isset($otrosElement[0])) {
                    preg_match('/Codigo: (FE\d+)/', (string)$otrosElement[0], $matches);
                    $numeroFacturaInterna = $matches[1] ?? 'No se encontró el número de factura interna';
                }

                // Mostrar los resultados
                return "El nombre del cliente es: $cliente <br> El número de factura interna es: $numeroFacturaInterna";

            } catch (\Exception $e) {
                return "Error al leer el XML: " . $e->getMessage();
            }
        } else {
            return "El archivo XML no existe en la ruta especificada.";
        }
    }

    private function getStatusColor($status)
    {
        $colors = [
            '1' => '#58D68D', // Aceptado - Verde
            '2' => '#F1948A', // Rechazado - Rojo
            '3' => '#F8E469', // Pendiente - Amarillo
        ];

        return $colors[$status] ?? '#C0C0C0'; // Color por defecto si el estado no coincide
    }

    public function view($id)
    {
        $voucher = VoucherElectronic::findOrFail($id);
        return view('voucher_electronic_new.view', compact('voucher'));
    }

    public function show($type, $id)
    {
        $voucher = VoucherElectronic::findOrFail($id);
        $filePath = '';

        switch ($type) {
            case 'xml':
                $filePath = $voucher->xml;
                break;
            case 'response':
                $filePath = $voucher->xml_respuesta;
                break;
            case 'pdf':
                $filePath = $voucher->pdf;
                break;
            default:
                abort(404, 'Tipo de archivo no válido');
        }

        return response()->file($filePath);
    }

    public function download($type, $id)
    {
        $voucher = VoucherElectronic::findOrFail($id);
        $filePath = '';

        switch ($type) {
            case 'xml':
                $filePath = $voucher->xml;
                break;
            case 'response':
                $filePath = $voucher->xml_respuesta;
                break;
            case 'pdf':
                $filePath = $voucher->pdf;
                break;
            case 'zip':
                $filePath = $this->createZip($voucher);
                break;
            default:
                abort(404, 'Tipo de archivo no válido');
        }

        return response()->download($filePath);
    }

    private function createZip($voucher)
    {
        $zipFileName = "{$voucher->NumeroConsecutivo}.zip";
        $zipDirectory = storage_path('app/public/zip');

        if (!file_exists($zipDirectory)) {
            mkdir($zipDirectory, 0755, true);
        }

        $zipPath = "{$zipDirectory}/{$zipFileName}";
        $zip = new ZipArchive();

        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $filesToZip = [
                $voucher->xml,
                $voucher->xml_respuesta,
                $voucher->pdf,
            ];

            foreach ($filesToZip as $file) {
                if (file_exists($file)) {
                    $zip->addFile($file, basename($file));
                }
            }

            $zip->close();
        } else {
            abort(500, 'No se pudo crear el archivo ZIP');
        }

        return $zipPath;
    }

    public function sendVouchersListByEmail(Request $request)
    {
        $request->validate([
            'emails' => 'required|string',
            'date_range' => 'nullable|string',
            'month' => 'nullable|string',
            'year' => 'nullable|string',
        ]);

        $vouchers = VoucherElectronic::query();
        if ($request->filled('date_range')) {
            [$start, $end] = explode(' ~ ', $request->date_range);
            $vouchers->whereBetween('fechaEmision', [$start, $end]);
        } elseif ($request->filled('month')  && $request->filled('year')) {
            $vouchers->whereRaw('MONTH(fechaEmision) = ? AND YEAR(fechaEmision) = ?', [$request->month, $request->year]);
        } elseif ($request->filled('month')) {
            $vouchers->whereMonth('fechaEmision', $request->month);
        } elseif ($request->filled('year')) {
            $vouchers->whereYear('fechaEmision', $request->year);
        }

        $vouchers = $vouchers->get();
        $export = new VouchersByCompanyExport($vouchers);
        $fileName = 'vouchers_' . now()->format('Y-m-d_His') . '.xlsx';
        Excel::store($export, $fileName, 'public');

        $emails = explode(',', $request->emails);
        // Verifica si el checkbox "miemail" está activo
        if ($request->filled('miemail')) {
            $emails[] = auth()->user()->email; // Agrega el correo del usuario autenticado
        }

        try {
            Log::info('Intentando enviar el correo a: ' . implode(', ', $emails));
            Mail::to($emails)->send(new VouchersListMail($fileName));
            Log::info('Correo enviado exitosamente');
            return redirect()->back()->with('success', 'Listado enviado correctamente.');
        } catch (\Exception $e) {
            Log::error('Error al enviar el correo: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'No se pudo enviar el correo. Error: ' . $e->getMessage()]);
        }
    }
    
    public function sendVouchersListByWhatsApp(Request $request)
    {
        $request->validate([
            'phone' => 'required|string',
            'date_range' => 'nullable|string',
            'month' => 'nullable|string',
            'year' => 'nullable|string',
        ]);

        // Obtener los datos de los vouchers según el rango de fechas o mes
        $vouchers = VoucherElectronic::query();
        if ($request->filled('date_range')) {
            [$start, $end] = explode(' ~ ', $request->date_range);
            $vouchers->whereBetween('fechaEmision', [$start, $end]);
        } elseif ($request->filled('month')  && $request->filled('year')) {
            $vouchers->whereRaw('MONTH(fechaEmision) = ? AND YEAR(fechaEmision) = ?', [$request->month, $request->year]);
        } elseif ($request->filled('month')) {
            $vouchers->whereMonth('fechaEmision', $request->month);
        } elseif ($request->filled('year')) {
            $vouchers->whereYear('fechaEmision', '=', $request->year);
        }

        $vouchers = $vouchers->get();
        $export = new VouchersByCompanyExport($vouchers);
        $fileName = 'vouchers_' . now()->format('Y-m-d_His') . '.xlsx';
        $filePath = storage_path('app/public/' . $fileName);

        // Guardar el archivo Excel
        Excel::store($export, $fileName, 'public');

        // Obtener el número de teléfono del formulario
        $phone = $request->input('phone');
        $message = 'Aquí tienes el listado de vouchers solicitado.';

        // Preparar datos para la API de WhatsApp
        $apiUrl = 'https://apiwhats.shakarbakar.com/api/messages/send';
        $token = 'A75FHlTwR8sy2a5v8IFsUwLA1bcP0c';

        try {
            // Usar Http para enviar la solicitud en formato multipart/form-data
            $response = Http::withHeaders([
                'Authorization' => "Bearer $token",
            ])->attach(
                'medias', file_get_contents($filePath), $fileName // Archivo adjunto
            )->post($apiUrl, [
                'number' => $phone,
                'body' => $message,
                'sendSignature' => 'false', // Cambiar según sea necesario
                'closeTicket' => 'false',  // Cambiar según sea necesario
            ]);
    
            // Procesar la respuesta de la API
            if ($response->successful() && $response->json('status') === 'SUCCESS') {
                return redirect()->back()->with('success', 'Listado enviado correctamente por WhatsApp.');
            } else {
                $errorMessage = $response->json('message') ?? 'Error desconocido al enviar el mensaje.';
                throw new \Exception($errorMessage);
            }
        } catch (\Exception $e) {
            Log::error('Error al enviar el mensaje por WhatsApp: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'No se pudo enviar el mensaje por WhatsApp. Error: ' . $e->getMessage()]);
        }
    }

    public function sendCompressedFiles($id)
    {
        $voucher = VoucherElectronic::findOrFail($id);

        // Asumiendo que tienes las rutas de los archivos
        $xmlFile = storage_path("app/public/vouchers/{$voucher->xml_file}");
        $pdfFile = storage_path("app/public/vouchers/{$voucher->pdf_file}");
        $responseXmlFile = storage_path("app/public/vouchers/{$voucher->response_xml_file}");

        // Nombre del archivo ZIP
        $zipFileName = "voucher_files_{$voucher->id}.zip";
        $zipFilePath = storage_path("app/public/vouchers/{$zipFileName}");

        // Crear el archivo ZIP
        $zip = new ZipArchive();
        if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            // Añadir archivos al ZIP
            $zip->addFile($xmlFile, basename($xmlFile));
            $zip->addFile($pdfFile, basename($pdfFile));
            $zip->addFile($responseXmlFile, basename($responseXmlFile));
            $zip->close();
        } else {
            return back()->withErrors(['error' => 'No se pudo crear el archivo ZIP.']);
        }

        // Define the recipient emails
        $emails = ['cliente@correo.com']; // Replace with actual emails or retrieve from request

        // Enviar el archivo ZIP por correo
        try {
            Log::info('Intentando enviar el correo a: ' . implode(', ', $emails));
            Mail::to($emails)->send(new VouchersCompressedMail($zipFileName, $zipFilePath));
            Log::info('Correo enviado exitosamente');
            return back()->with('success', 'Archivo ZIP enviado correctamente.');
        } catch (\Swift_TransportException $e) {
            Log::error('Error de transporte de correo: ' . $e->getMessage());
            return back()->withErrors(['error' => 'No se pudo enviar el correo. Error del servidor de correo: ' . $e->getMessage()]);
        } catch (\Exception $e) {
            Log::error('Error al enviar el correo: ' . $e->getMessage());
            return back()->withErrors(['error' => 'No se pudo enviar el correo. Error: ' . $e->getMessage()]);
        }
    }

    public function getVouchers()
    {
        $vouchers = VoucherElectronic::all();

        $vouchers = $vouchers->map(function ($voucher) {
            return [
                'sucursal' => $voucher->sucursal,
                'empresa' => $voucher->empresa,
                'cliente' => $voucher->cliente,
                'numero_consecutivo' => $voucher->numero_consecutivo,
                'total_factura' => $voucher->total_factura,
                'impuesto_total' => $voucher->impuesto_total,
                'fecha' => $voucher->fecha->format('d/m/Y'),
                'tipo_documento' => $this->getVoucherTypeText($voucher->vauchertype),
                'estado' => $this->getVoucherStatusText($voucher->status)
            ];
        });

        return view('vouchers.list', compact('vouchers'));
    }

    private function getVoucherTypeText($vauchertype)
    {
        $sigTipoDoc = 'Desconocido';
        $desTipoDoc = 'Tipo desconocido';

        switch ($vauchertype) {
            case 1:
                $sigTipoDoc = "FE";
                $desTipoDoc = "Factura Electrónica";
                break;
            case 2:
                $sigTipoDoc = "ND";
                $desTipoDoc = "Nota Débito Electrónica";
                break;
            case 3:
                $sigTipoDoc = "NC";
                $desTipoDoc = "Nota Crédito Electrónica";
                break;
            case 4:
                $sigTipoDoc = "TE";
                $desTipoDoc = "Tiquete Electrónico";
                break;
            case 5:
                $sigTipoDoc = "MR";
                $desTipoDoc = "Mensaje Receptor";
                break;
            case 7:
                $sigTipoDoc = "RR";
                $desTipoDoc = "Rechazo Receptor";
                break;
            case 8:
                $sigTipoDoc = "FC";
                $desTipoDoc = "Factura Electrónica de Compra";
                break;
            case 9:
                $sigTipoDoc = "FX";
                $desTipoDoc = "Factura Electrónica de Exportación";
                break;
        }

        return ['sigTipoDoc' => $sigTipoDoc, 'desTipoDoc' => $desTipoDoc];
    }

    private function getVoucherStatusText($status)
    {
        $statuses = [
            '1' => 'Aceptado',
            '2' => 'Rechazado',
            '3' => 'Pendiente'
        ];

        return $statuses[$status] ?? 'Estado desconocido';
    }

    private function getActionButtons($row)
    {
        $viewUrl = route('vouchers.new.view', $row->id);
        $showXmlUrl = route('vouchers.new.show', ['type' => 'xml', 'id' => $row->id]);
        $showResponseUrl = route('vouchers.new.show', ['type' => 'response', 'id' => $row->id]);
        $showPdfUrl = route('vouchers.new.show', ['type' => 'pdf', 'id' => $row->id]);

        $downloadXmlUrl = route('vouchers.new.download', ['type' => 'xml', 'id' => $row->id]);
        $downloadResponseUrl = route('vouchers.new.download', ['type' => 'response', 'id' => $row->id]);
        $downloadPdfUrl = route('vouchers.new.download', ['type' => 'pdf', 'id' => $row->id]);
        $downloadZipUrl = route('vouchers.new.download.zip', $row->id);
        $sendEmailUrl = action('VoucherElectronicNewController@getVoucherToSend', [$row->id]);

        return '
            <div class="btn-group">
                <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    Acciones <span class="caret"></span>
                </button>
                <ul class="dropdown-menu" role="menu">
                    <li><a href="' . $viewUrl . '">Ver Información</a></li>
                    <li class="dropdown-submenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ver Archivos</a>
                        <ul class="dropdown-menu">
                            <li><a href="' . $showXmlUrl . '">Ver XML</a></li>
                            <li><a href="' . $showResponseUrl . '">Ver Respuesta</a></li>
                            <li><a href="' . $showPdfUrl . '">Ver PDF</a></li>
                        </ul>
                    </li>
                    <li class="dropdown-submenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Descargar Archivos</a>
                        <ul class="dropdown-menu">
                            <li><a href="' . $downloadXmlUrl . '">Descargar XML</a></li>
                            <li><a href="' . $downloadResponseUrl . '">Descargar Respuesta</a></li>
                            <li><a href="' . $downloadPdfUrl . '">Descargar PDF</a></li>
                        </ul>
                    </li>
                    <li><a href="' . $downloadZipUrl . '">Descargar ZIP</a></li>
                    <li><a href="' . $sendEmailUrl . '" class="view-voucher">Enviar por Correo</a></li>
                </ul>
            </div>';
    }
    public function getVoucherToSend($id)
    {
        try {
            $voucher = VoucherElectronic::findOrFail($id);

            return view('voucher_electronic_new.view_send_voucher')->with(compact(
                'voucher'
            ));
        } catch (\Exception $e) {
            \Log::emergency("File:" . $e->getFile(). "Line:" . $e->getLine(). "Message:" . $e->getMessage());
        }
    }
    public function getFiles($id)
    {
        $voucher = VoucherElectronic::findOrFail($id);

        $files = [
            'xml' => $voucher->xml,
            'response' => $voucher->xml_respuesta,
            'pdf' => $voucher->pdf,
        ];

        return $files;
    }

    public function sendVoucherFilesByEmail(Request $request)
    {
        $emails = explode(',', $request->input('emails')); // Convertir los correos en array
        $voucher = $request->input('voucher');

        $files = [
            'xml' => $voucher['xml'] ?? null,
            'response' => $voucher['xml_respuesta'] ?? null,
            'pdf' => $voucher['pdf'] ?? null,
        ];

        try {
            Log::info('Intentando enviar el correo a: ' . implode(', ', $emails));
            // Enviar correo con los archivos adjuntos
            Mail::to($emails)->send(new VoucherMail($files));
            Log::info('Correo enviado exitosamente');
            return response()->json([
                'success' => true,
                'message' => 'Archivos enviados correctamente por Correo.',
            ]);
        } catch (\Exception $e) {
            Log::error('Error al enviar el correo: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'No se pudo enviar el correo.',
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function sendVoucherFilesByWhatsApp(Request $request)
    {
        $voucher = $request->input('voucher');
        $phone = $request->input('phone');
        $apiUrl = 'https://apiwhats.shakarbakar.com/api/messages/send';
        $token = 'A75FHlTwR8sy2a5v8IFsUwLA1bcP0c';

        // Definir los archivos con sus rutas absolutas
        $files = [
            'pdf' => ['path' => $voucher['pdf'] ?? null, 'name' => 'Voucher.pdf'],
            'xml' => ['path' => $voucher['xml'] ?? null, 'name' => 'Voucher.xml'],
            'response' => ['path' => $voucher['xml_respuesta'] ?? null, 'name' => 'Respuesta_Sunat.xml'],
        ];

        try {
            Log::info("Preparando el envío de WhatsApp a: $phone");
            // Procesar y enviar los archivos
            foreach ($files as $file) {
                if ($file['path']) {
                    $originalPath = $file['path'];
                    $fileName = $file['name'];

                    if (!file_exists($originalPath)) {
                        Log::warning("Archivo no encontrado: $originalPath");
                        continue;
                    }

                    // Guardar en el storage correctamente
                    $storagePath = storage_path("app/public/{$fileName}");
                    file_put_contents($storagePath, file_get_contents($originalPath));
                    chmod($storagePath, 0777);

                     // Verificar si el archivo copiado tiene contenido antes de enviarlo
                    if (filesize($storagePath) == 0) {
                        Log::warning("Archivo copiado está vacío, omitiendo: $storagePath");
                        continue;
                    }

                    // Obtener la URL pública del archivo
                    Log::info("Archivo copiado y accesible en: $storagePath");
                    $message = "Hola, aquí puedes revisar: {$fileName}.";

                    // Enviar archivo por WhatsApp desde la URL pública
                    $fileResponse = Http::withHeaders([
                        'Authorization' => "Bearer $token",
                    ])->attach(
                        'medias', file_get_contents($storagePath), $fileName
                    )->post($apiUrl, [
                        'number' => $phone,
                        'body' => $message,
                        'sendSignature' => 'false',
                        'closeTicket' => 'false',
                    ]);

                    if (!$fileResponse->successful()) {
                        Log::info('Respuesta de WhatsApp API: ' . $fileResponse->body());
                        throw new \Exception("Error al enviar {$fileName} por WhatsApp.");
                    }
                }
            }
            
            Log::info('Archivos enviados exitosamente por WhatsApp.');
            return response()->json([
                'success' => true,
                'message' => 'Archivos enviados correctamente por WhatsApp.',
            ]);
        } catch (\Exception $e) {
            Log::error('Error al enviar los archivos por WhatsApp: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => 'No se pudo enviar los archivos por WhatsApp.',
                'message' => $e->getMessage(),
            ], 500);
        }
    }

}