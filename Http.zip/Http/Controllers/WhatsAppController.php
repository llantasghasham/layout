<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class WhatsAppController extends Controller
{
    public function enviarMensaje(Request $request)
    {
        $numero = $request->input('numero');
        $mensaje = $request->input('mensaje');

        $url = 'https://apiwhaticket.shakarbakar.com/api/messages/send';

        $respuesta = Http::withHeaders([
            'Authorization' => config('app.apiwhaticket_token'),
            'Content-Type' => 'application/json',
        ])->post($url, [
            'number' => $numero,
            'body' => $mensaje,
        ]);

        // Manejar la respuesta de la API y realizar las acciones correspondientes en tu sistema UltimatePOS

        // Por ejemplo, redirigir a una página de éxito o mostrar un mensaje de confirmación
        return redirect()->back()->with('success', 'Mensaje de WhatsApp enviado con éxito');
    }
}
