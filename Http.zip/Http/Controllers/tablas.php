<?php

$tipoIdenLis = [
    '1' => ' Cédula Física ',
    '2' => ' Cédula Jurídica ',
    '3' => ' DIMEX ',
    '4' => ' NITE ',
    '5' => ' Proveedor No Domiciliado '
];

$condicionventa = [
    '01' => ' Contado ',
    '02' => ' Crédito ',
    '03' => ' Consignación ',
    '04' => ' Apartado ',
    '05' => ' Arrendamiento con opción de compra ',
    '06' => ' Arrendamiento en función financiera ',
    '07' => ' Cobro a favor de un tercero ',
    '08' => ' Servicios al Estado a crédito ',
    '09' => ' Servicios al Estado ',
    '10' => ' Ventas Sucesivas ',
    '99' => ' Otros '
];

$tipoCompro = [
    'URL' => 'https://cdn.comprobanteselectronicos.go.cr/xml-schemas/v4.3/',
    '00' => 'Factura electrónica',
    '01' => 'Factura electrónica',
    '02' => 'Nota Débito eletrónica',
    '03' => 'Nota Crédito eletrónica',
    '04' => 'Tickete Electrónico',
    '05' => 'Aceptación del Receptor',
    '06' => 'Aceptación Parcial del Receptor',
    '07' => 'Rechazo del Receptor'
];

$estadoCompro = [
    '00' => ' No Enviado al Minsterio ',
    '01' => ' Enviado al Minsterio ',
    '02' => ' Enviada Por Contingencia ',
    '03' => ' Enviada Por falta de Internet ',

    '04' => ' Esperando por Hacienda ',
    '05' => ' Rechazado por Hacienda ',
    '06' => ' Aprobado por Hacienda ',

    '07' => ' Enviado al Cliente ',
    '08' => ' Rechazado por el Cliente ',
    '09' => ' Confirmado por el Cliente ',
    '10' => ' Terminada '
];

$servidoresMail = [
    'hotmail.com' => ['SMTPSecure' => 'tls',
                    'transport'  => 'smtp',
                    'Host'       => 'smtp.live.com',
                    'Port'       => 587
                ],
    'outlook.com' => ['SMTPSecure' => 'tls',
                    'transport'  => 'smtp',
                    'Host'       => 'smtp.live.com',
                    'Port'       => 587
                ],
    'gmail.com'  => ['SMTPSecure' => 'tls',
                    'transport'  => 'smtp',
                    'Host'       => 'smtp.gmail.com',
                    'Port'       => 587
                ],
    'mailtrap.io' => ['SMTPSecure' => 'tls',  //encryption
                    'transport'  => 'smtp',
                    'Host'       => 'smtp.mailtrap.io',
                    'Port'       => 2525
                ],
    'yahoo.com'  => ['SMTPSecure' => 'ssl',  //encryption
                    'transport'  => 'smtp',
                    'Host'       => 'smtp.mail.yahoo.com',
                    'Port'       => 465
                ],
    'llantasghasham.com'  => ['SMTPSecure' => 'tls',  //encryption
                    'transport'  => 'smtp',
                    'Host'       => 'mail.llantasghasham.com',
                    'Port'       => 587
            ],
    'llantaselpana.com'  => ['SMTPSecure' => 'tls',  //encryption
                'transport'  => 'smtp',
                'Host'       => 'mail.llantaselpana.com',
                'Port'       => 587
            ]
];
