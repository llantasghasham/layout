https://soenac.com/facturacion-electronica-validacion-previa-dian-ubl-2-1-php/

$pathCertificate = 'PATH_CERTIFICATE.p12';
$passwors = 'PASSWORS_CERTIFICATE';

$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<Invoice>
    <ext:UBLExtensions>
        <ext:UBLExtension>
            <ext:ExtensionContent/>
        </ext:UBLExtension>
        <ext:UBLExtension>
            <ext:ExtensionContent/>
        </ext:UBLExtension>
    </ext:UBLExtensions>
</Invoice>
XML;

$domDocument = new DOMDocument();
$domDocument->loadXML($xmlString);

$xadesDIAN = new XAdESDIAN($pathCertificate, $passwors, $this->xmlString);

file_put_contents('./SING256.xml', $xadesDIAN->xml);