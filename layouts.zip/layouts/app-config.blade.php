@inject('request', 'Illuminate\Http\Request')
@php
$pos_layout = false;
@endphp
@if($request->segment(1) == 'pos' && ($request->segment(2) == 'create' || $request->segment(3) == 'edit'))
    @php
        $pos_layout = true;
    @endphp
@endif
@php
    $whitelist = ['127.0.0.1', '::1'];
    $logo = session('business.logo') ? asset(session('business.logo')) : asset('images/multillantas-logo.png');
@endphp

<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ in_array(session()->get('user.language', config('app.locale')), config('constants.langs_rtl')) ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', session('business.name', 'Sistema'))</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" integrity="sha384-tViUnnbYAV00FLIhhi3v/dWt3RoGD+af5Wws+mr2gvev7+4I4qhiL6V2FbnSag2" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Toastr CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">

    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Google Fonts (Inter) -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Estilos Personalizados del Sistema -->
    @include('layouts.partials.css')

    <!-- Estilos Personalizados Ajustados -->
    <style>
        body {
            background-color: #F9FAFB;
            font-family: 'Inter', sans-serif;
            color: #1F2937;
            font-size: 13px;
            line-height: 1.5;
            overflow-x: hidden;
        }
        .content-wrapper {
            padding: 15px;
            min-height: 100vh;
            background-color: #F9FAFB;
            transition: margin-left 0.3s ease;
        }
        .navbar {
            background: linear-gradient(90deg, #4B1C71, #6D28D9);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            padding: 8px 15px;
        }
        .navbar-brand img {
            height: 25px;
            margin-right: 8px;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: #FFFFFF !important;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #EDE9FE !important;
        }
        .navbar .nav-link i {
            font-size: 14px;
        }
        .navbar-toggler {
            border: none;
            color: #FFFFFF;
            font-size: 14px;
        }
        /* Ajustes para el sidebar del sistema */
        .main-sidebar {
            background-color: #1F2937;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            width: 230px;
            box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .sidebar-collapse .main-sidebar {
            transform: translateX(-230px);
        }
        .nav-sidebar .nav-link {
            color: #D1D5DB !important;
            font-size: 13px;
            padding: 10px 15px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
        }
        .nav-sidebar .nav-link:hover, .nav-sidebar .nav-link.active {
            background-color: #6D28D9;
            color: #FFFFFF !important;
        }
        .nav-sidebar .nav-link i {
            font-size: 14px;
            margin-right: 8px;
        }
        .nav-sidebar .nav-header {
            color: #9CA3AF;
            font-size: 11px;
            padding: 8px 15px;
            text-transform: uppercase;
        }
        .nav-sidebar .nav-treeview .nav-link {
            padding-left: 35px;
            font-size: 12px;
        }
        .nav-sidebar .nav-treeview .nav-link:hover {
            background-color: #4B1C71;
        }
        .btn {
            border-radius: 6px;
            padding: 6px 12px;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }
        .btn-primary {
            background-color: #6D28D9;
            color: #FFFFFF;
        }
        .btn-primary:hover {
            background-color: #4B1C71;
        }
        .btn-success {
            background-color: #10B981;
            color: #FFFFFF;
        }
        .btn-success:hover {
            background-color: #059669;
        }
        .btn-danger {
            background-color: #EF4444;
            color: #FFFFFF;
        }
        .btn-danger:hover {
            background-color: #DC2626;
        }
        .btn-secondary {
            background-color: #E5E7EB;
            color: #4B1C71;
        }
        .btn-secondary:hover {
            background-color: #D1D5DB;
        }
        .btn-warning {
            background-color: #F59E0B;
            color: #FFFFFF;
        }
        .btn-warning:hover {
            background-color: #D97706;
        }
        .card {
            border: none;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            background: #FFFFFF;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-3px);
        }
        .card-header {
            background: linear-gradient(90deg, #4B1C71, #6D28D9);
            color: #FFFFFF;
            border-radius: 8px 8px 0 0;
            padding: 10px;
            font-size: 16px;
            font-weight: 600;
        }
        .form-control, .form-select {
            border: 1px solid #D1D5DB;
            border-radius: 6px;
            padding: 6px 10px;
            font-size: 13px;
            transition: border-color 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #6D28D9;
            box-shadow: 0 0 3px rgba(109, 40, 217, 0.2);
        }
        .form-label {
            font-weight: 500;
            color: #1F2937;
            font-size: 13px;
        }
        .alert {
            border-radius: 6px;
            border-left: 4px solid;
            padding: 10px;
            font-size: 13px;
        }
        .alert-warning {
            background-color: #FFF3CD;
            border-left-color: #FFECB5;
            color: #856404;
        }
        .scroll-to-top {
            position: fixed;
            bottom: 15px;
            right: 15px;
            background-color: #6D28D9;
            color: #FFFFFF;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            transition: opacity 0.3s ease, transform 0.3s ease;
            font-size: 14px;
        }
        .scroll-to-top.visible {
            opacity: 1;
        }
        .scroll-to-top:hover {
            background-color: #4B1C71;
            transform: scale(1.05);
        }
        .table-responsive {
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        .table th, .table td {
            vertical-align: middle;
            padding: 8px;
            text-align: center;
            font-size: 13px;
        }
        .table thead th {
            background: linear-gradient(90deg, #4B1C71, #6D28D9);
            color: #FFFFFF;
            border-bottom: 2px solid #6D28D9;
        }
        .table tbody tr:nth-child(even) {
            background-color: #F9FAFB;
        }
        .table tbody tr:hover {
            background-color: #EDE9FE;
        }
        .form-check-input {
            width: 18px;
            height: 18px;
            margin-right: 6px;
        }
        /* Estilos para botones flotantes heredados */
        .buttons-container {
            position: fixed;
            bottom: 15px;
            right: -120px;
            z-index: 9999;
            transition: right 0.3s ease;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .buttons-container a {
            padding: 8px 12px;
            border-radius: 4px;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 12px;
            font-weight: 500;
        }
        .buttons-container a:hover {
            opacity: 0.8;
        }
        .pos-button { background-color: #28a745; }
        .inicio-button { background-color: #007bff; }
        .product-button { background-color: #ffc107; color: #212529; }
        .gasto-button { background-color: #dc3545; }
        .venta-button { background-color: #17a2b8; }
        .compra-button { background-color: #6f42c1; }
        @media (max-width: 768px) {
            .buttons-container {
                display: none;
            }
        }
        @media print {
            .buttons-container, .scroll-to-top {
                display: none;
            }
        }
        /* Ajustes para vistas POS */
        .lockscreen .lockscreen-wrapper {
            max-width: 100%;
            margin: 0 auto;
            padding: 15px;
        }
        .lockscreen .lockscreen-wrapper .lockscreen-item {
            margin-bottom: 15px;
        }
        .lockscreen .lockscreen-wrapper .lockscreen-item .lockscreen-image {
            margin-bottom: 10px;
        }
        .lockscreen .lockscreen-wrapper .lockscreen-item .lockscreen-credentials {
            margin-bottom: 10px;
        }
        /* Asegurar compatibilidad con íconos del sistema */
        i[class^="fa"], i[class^="bi"] {
            font-size: 14px !important;
            margin-right: 5px;
        }
        /* Asegurar compatibilidad con el sistema */
        .sidebar-mini .main-sidebar {
            width: 230px !important;
        }
        .sidebar-mini .main-sidebar .nav-sidebar .nav-link {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .sidebar-mini.sidebar-collapse .main-sidebar {
            width: 50px !important;
        }
        .sidebar-mini.sidebar-collapse .main-sidebar .nav-sidebar .nav-link {
            padding: 10px 5px;
        }
        .sidebar-mini.sidebar-collapse .main-sidebar .nav-sidebar .nav-link i {
            margin-right: 0;
        }
        .sidebar-mini.sidebar-collapse .main-sidebar .nav-sidebar .nav-link p {
            display: none;
        }
    </style>

    @yield('css')
</head>
<body class="@if($pos_layout) hold-transition lockscreen @else hold-transition skin-@if(!empty(session('business.theme_color'))){{session('business.theme_color')}}@else{{'purple-dark'}}@endif sidebar-mini @endif">
    <div class="wrapper thetop">
        <!-- Manejo del colapso del sidebar -->
        <script type="text/javascript">
            if (localStorage.getItem("upos_sidebar_collapse") === 'true') {
                document.body.classList.add("sidebar-collapse");
            }
        </script>

        <!-- Header -->
        @if(!$pos_layout)
            @include('layouts.partials.header')
            @include('layouts.partials.sidebar')
        @else
            @include('layouts.partials.header-pos')
        @endif

        @if(in_array($_SERVER['REMOTE_ADDR'], $whitelist))
            <input type="hidden" id="__is_localhost" value="true">
        @endif

        <div class="@if(!$pos_layout) content-wrapper @endif">
            <div id="app">
                @yield('vue')
            </div>
            <input type="hidden" id="__code" value="{{session('currency')['code']}}">
            <input type="hidden" id="__symbol" value="{{session('currency')['symbol']}}">
            <input type="hidden" id="__thousand" value="{{session('currency')['thousand_separator']}}">
            <input type="hidden" id="__decimal" value="{{session('currency')['decimal_separator']}}">
            <input type="hidden" id="__symbol_placement" value="{{session('business.currency_symbol_placement')}}">
            <input type="hidden" id="__precision" value="{{config('constants.currency_precision', 2)}}">
            <input type="hidden" id="__quantity_precision" value="{{config('constants.quantity_precision', 2)}}">

            @if (session('status'))
                <input type="hidden" id="status_span" data-status="{{ session('status.success') }}" data-msg="{{ session('status.msg') }}">
            @endif
            @yield('content')

            <div class='scrolltop no-print'>
                <div class='scroll icon'><i class="fas fa-angle-up"></i></div>
            </div>

            @if(config('constants.iraqi_selling_price_adjustment'))
                <input type="hidden" id="iraqi_selling_price_adjustment">
            @endif

            <section class="invoice print_section" id="receipt_section"></section>
        </div>
        @include('home.todays_profit_modal')

        @if(!$pos_layout)
            @include('layouts.partials.footer')
        @else
            @include('layouts.partials.footer_pos')
        @endif

        <audio id="success-audio">
            <source src="{{ asset('/audio/success.ogg?v=' . $asset_v) }}" type="audio/ogg">
            <source src="{{ asset('/audio/success.mp3?v=' . $asset_v) }}" type="audio/mpeg">
        </audio>
        <audio id="error-audio">
            <source src="{{ asset('/audio/error.ogg?v=' . $asset_v) }}" type="audio/ogg">
            <source src="{{ asset('/audio/error.mp3?v=' . $asset_v) }}" type="audio/mpeg">
        </audio>
        <audio id="warning-audio">
            <source src="{{ asset('/audio/warning.ogg?v=' . $asset_v) }}" type="audio/ogg">
            <source src="{{ asset('/audio/warning.mp3?v=' . $asset_v) }}" type="audio/mpeg">
        </audio>

        <!-- Botones flotantes -->
        <div class="buttons-container">
            @if(Auth::user()->can('home.view'))
                <a href="{{ route('pos.create') }}" class="help-button pos-button">
                    <i class="fas fa-cash-register fa-lg"></i> POS
                </a>
                <a href="{{ route('home') }}" class="help-button inicio-button">
                    <i class="fas fa-home fa-lg"></i> Inicio
                </a>
                <a href="{{ url('/products') }}" class="help-button product-button">
                    <i class="fas fa-box fa-lg"></i> Producto
                </a>
                <a href="{{ url('/expenses') }}" class="help-button gasto-button">
                    <i class="fas fa-money-bill-wave fa-lg"></i> Gasto
                </a>
                <a href="{{ url('/sells') }}" class="help-button venta-button">
                    <i class="fas fa-shopping-cart fa-lg"></i> Venta
                </a>
                <a href="{{ url('/purchases') }}" class="help-button compra-button">
                    <i class="fas fa-truck fa-lg"></i> Compra
                </a>
            @endif
        </div>

        @if(!empty($__additional_html))
            {!! $__additional_html !!}
        @endif

        @include('layouts.partials.javascripts')

        <div class="modal fade view_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

        @if(!empty($__additional_views) && is_array($__additional_views))
            @foreach($__additional_views as $additional_view)
                @includeIf($additional_view)
            @endforeach
        @endif

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var helpButtons = document.querySelector('.buttons-container');
                var buttonThreshold = 20;
                var hideTimeout;

                document.addEventListener('mousemove', function(event) {
                    var xPos = event.clientX;
                    var distanceFromRight = window.innerWidth - xPos;

                    clearTimeout(hideTimeout);

                    if (distanceFromRight < buttonThreshold) {
                        helpButtons.style.right = '20px';
                    } else {
                        hideTimeout = setTimeout(function() {
                            helpButtons.style.right = '-120px';
                        }, 1000);
                    }
                });

                helpButtons.addEventListener('mouseenter', function() {
                    clearTimeout(hideTimeout);
                });

                helpButtons.addEventListener('mouseleave', function() {
                    hideTimeout = setTimeout(function() {
                        helpButtons.style.right = '-120px';
                    }, 1000);
                });
            });

            // Scroll to Top Functionality
            $(document).ready(function() {
                $(window).scroll(function() {
                    if ($(this).scrollTop() > 200) {
                        $('.scrolltop').addClass('visible');
                    } else {
                        $('.scrolltop').removeClass('visible');
                    }
                });

                $('.scrolltop .scroll').click(function() {
                    $('html, body').animate({ scrollTop: 0 }, 500, 'easeInOutExpo');
                    return false;
                });
            });
        </script>

        @yield('scripts')
    </body>
</html>