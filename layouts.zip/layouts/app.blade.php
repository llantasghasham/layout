@inject('request', 'Illuminate\Http\Request')
@php
$pos_layout = false;
@endphp
@if($request->segment(1) == 'pos' && ($request->segment(2) == 'create' || $request->segment(3) == 'edit'))
    @php
        $pos_layout = true;
    @endphp
@endif
@php
    $whitelist = ['127.0.0.1', '::1'];
@endphp

<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{in_array(session()->get('user.language', config('app.locale')), config('constants.langs_rtl')) ? 'rtl' : 'ltr'}}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- Estilos -->
    <style>
        .d-flex {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .welcome-message {
            font-family: Arial, sans-serif;
            font-size: 16px;
            font-weight: bold;
            text-shadow: 1px 1px 2px #000000;
            margin-right: 10px;
        }

        .version-container {
            background-color: #FFFF00;
            color: #000000;
            font-weight: bold;
        }

        .buttons-container {
            position: fixed;
            bottom: 20px;
            right: -150px; /* Oculto inicialmente */
            z-index: 9999;
            transition: right 0.3s ease;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .buttons-container a {
            padding: 10px 15px;
            border-radius: 5px;
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .buttons-container a:hover {
            opacity: 0.8; /* Efecto de hover */
        }

        .pos-button { background-color: #28a745; } /* Verde */
        .inicio-button { background-color: #007bff; } /* Azul */
        .product-button { background-color: #ffc107; color: #212529; } /* Amarillo */
        .gasto-button { background-color: #dc3545; } /* Rojo */
        .venta-button { background-color: #17a2b8; } /* Celeste */
        .compra-button { background-color: #6f42c1; } /* Púrpura */

        @media (max-width: 768px) {
            .version-container {
                display: none;
            }
            .buttons-container {
                display: none; /* Ocultar botones en dispositivos móviles */
            }
        }

        @media print {
            .welcome-message,
            .buttons-container {
                display: none;
            }
            .btn {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <!-- Contenido de tu página -->

    <div class="buttons-container">
        @if(Auth::user()->can('home.view'))
            <a href="{{ route('pos.create') }}" class="help-button pos-button">
                <i class="fas fa-cash-register fa-lg"></i> POS
            </a>
            <a href="{{ route('home') }}" class="help-button inicio-button">
                <i class="fas fa-home fa-lg"></i> Inicio
            </a>
            <a href="{{ url('/products') }}" class="help-button product-button">
                <i class="fas fa-box fa-lg"></i> Producto
            </a>
            <a href="{{ url('/expenses') }}" class="help-button gasto-button">
                <i class="fas fa-money-bill-wave fa-lg"></i> Gasto
            </a>
            <a href="{{ url('/sells') }}" class="help-button venta-button">
                <i class="fas fa-shopping-cart fa-lg"></i> Venta
            </a>
            <a href="{{ url('/purchases') }}" class="help-button compra-button">
                <i class="fas fa-truck fa-lg"></i> Compra
            </a>
        @endif
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var helpButtons = document.querySelector('.buttons-container');
            var buttonThreshold = 20; // Ajusta este valor según tus necesidades
            var hideTimeout;

            document.addEventListener('mousemove', function(event) {
                var xPos = event.clientX;
                var distanceFromRight = window.innerWidth - xPos;

                clearTimeout(hideTimeout); // Limpiar el temporizador de ocultar los botones

                if (distanceFromRight < buttonThreshold) {
                    helpButtons.style.right = '20px'; // Mostrar botones
                } else {
                    hideTimeout = setTimeout(function() {
                        helpButtons.style.right = '-150px'; // Ocultar botones
                    }, 1000); // Establecer un retraso de 1000ms (1 segundo) antes de ocultar los botones
                }
            });

            helpButtons.addEventListener('mouseenter', function() {
                clearTimeout(hideTimeout); // Limpiar el temporizador de ocultar los botones cuando el mouse entra en los botones
            });

            helpButtons.addEventListener('mouseleave', function() {
                hideTimeout = setTimeout(function() {
                    helpButtons.style.right = '-150px'; // Ocultar botones al salir del área de los botones
                }, 1000); // Establecer un retraso de 1000ms (1 segundo) antes de ocultar los botones
            });
        });
    </script>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - {{ Session::get('business.name') }}</title>
    
    @include('layouts.partials.css')
    @yield('css')
</head> 

<body class="@if($pos_layout) hold-transition lockscreen @else hold-transition skin-@if(!empty(session('business.theme_color'))){{session('business.theme_color')}}@else{{'blue-light'}}@endif sidebar-mini @endif">
    <div class="wrapper thetop">
        <script type="text/javascript">
            if(localStorage.getItem("upos_sidebar_collapse") == 'true'){
                var body = document.getElementsByTagName("body")[0];
                body.className += " sidebar-collapse";
            }
        </script>            
        @if(!$pos_layout)
            @include('layouts.partials.header')
            @include('layouts.partials.sidebar') 
        @else
            @include('layouts.partials.header-pos')
        @endif

        @if(in_array($_SERVER['REMOTE_ADDR'], $whitelist))
            <input type="hidden" id="__is_localhost" value="true">
        @endif

        <div class="@if(!$pos_layout) content-wrapper @endif">
            <div id="app">
                @yield('vue')
            </div>
            <input type="hidden" id="__code" value="{{session('currency')['code']}}">
            <input type="hidden" id="__symbol" value="{{session('currency')['symbol']}}">
            <input type="hidden" id="__thousand" value="{{session('currency')['thousand_separator']}}">
            <input type="hidden" id="__decimal" value="{{session('currency')['decimal_separator']}}">
            <input type="hidden" id="__symbol_placement" value="{{session('business.currency_symbol_placement')}}">
            <input type="hidden" id="__precision" value="{{config('constants.currency_precision', 2)}}">
            <input type="hidden" id="__quantity_precision" value="{{config('constants.quantity_precision', 2)}}">

            @if (session('status'))
                <input type="hidden" id="status_span" data-status="{{ session('status.success') }}" data-msg="{{ session('status.msg') }}">
            @endif
            @yield('content')

            <div class='scrolltop no-print'>
                <div class='scroll icon'><i class="fas fa-angle-up"></i></div>
            </div>

            @if(config('constants.iraqi_selling_price_adjustment'))
                <input type="hidden" id="iraqi_selling_price_adjustment">
            @endif

            <section class="invoice print_section" id="receipt_section"></section>
        </div>
        @include('home.todays_profit_modal')

        @if(!$pos_layout)
            @include('layouts.partials.footer')
        @else
            @include('layouts.partials.footer_pos')
        @endif

        <audio id="success-audio">
            <source src="{{ asset('/audio/success.ogg?v=' . $asset_v) }}" type="audio/ogg">
            <source src="{{ asset('/audio/success.mp3?v=' . $asset_v) }}" type="audio/mpeg">
        </audio>
        <audio id="error-audio">
            <source src="{{ asset('/audio/error.ogg?v=' . $asset_v) }}" type="audio/ogg">
            <source src="{{ asset('/audio/error.mp3?v=' . $asset_v) }}" type="audio/mpeg">
        </audio>
        <audio id="warning-audio">
            <source src="{{ asset('/audio/warning.ogg?v=' . $asset_v) }}" type="audio/ogg">
            <source src="{{ asset('/audio/warning.mp3?v=' . $asset_v) }}" type="audio/mpeg">
        </audio>
    </div>

    @if(!empty($__additional_html))
        {!! $__additional_html !!}
    @endif

    @include('layouts.partials.javascripts')

    <div class="modal fade view_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

    @if(!empty($__additional_views) && is_array($__additional_views))
        @foreach($__additional_views as $additional_view)
            @includeIf($additional_view)
        @endforeach
    @endif

</body>
</html>
