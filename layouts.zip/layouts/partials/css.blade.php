<link rel="stylesheet" href="{{ asset('css/vendor.css?v='.$asset_v) }}">

@if( in_array(session()->get('user.language', config('app.locale')), config('constants.langs_rtl')) )
	<link rel="stylesheet" href="{{ asset('css/rtl.css?v='.$asset_v) }}">
@endif

@yield('css')

<!-- app css -->
<link rel="stylesheet" href="{{ asset('css/app.css?v='.$asset_v) }}">

@if(isset($pos_layout) && $pos_layout)
	<style type="text/css">
		.content{
			padding-bottom: 0px !important;
		}
	</style>
@endif
<style type="text/css">
	/*
	* Pattern lock css
	* Pattern direction
	* http://ignitersworld.com/lab/patternLock.html
	*/
	.patt-wrap {
	  z-index: 10;
	}
	.patt-circ.hovered {
	  background-color: #cde2f2;
	  border: none;
	}
	.patt-circ.hovered .patt-dots {
	  display: none;
	}
	.patt-circ.dir {
	  background-image: url("{{asset('/img/pattern-directionicon-arrow.png')}}");
	  background-position: center;
	  background-repeat: no-repeat;
	}
	.patt-circ.e {
	  -webkit-transform: rotate(0);
	  transform: rotate(0);
	}
	.patt-circ.s-e {
	  -webkit-transform: rotate(45deg);
	  transform: rotate(45deg);
	}
	.patt-circ.s {
	  -webkit-transform: rotate(90deg);
	  transform: rotate(90deg);
	}
	.patt-circ.s-w {
	  -webkit-transform: rotate(135deg);
	  transform: rotate(135deg);
	}
	.patt-circ.w {
	  -webkit-transform: rotate(180deg);
	  transform: rotate(180deg);
	}
	.patt-circ.n-w {
	  -webkit-transform: rotate(225deg);
	   transform: rotate(225deg);
	}
	.patt-circ.n {
	  -webkit-transform: rotate(270deg);
	  transform: rotate(270deg);
	}
	.patt-circ.n-e {
	  -webkit-transform: rotate(315deg);
	  transform: rotate(315deg);
	}
	
/* Estilos generales para la franja de botones (versión web) */
.buttons-bar {
    background: linear-gradient(90deg, #e3f2fd, #bbdefb); /* Gradiente de color suave */
    padding: 10px;
    border-radius: 5px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Sombra ligera */
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: nowrap;
    width: 100%;
    position: relative;
    margin-bottom: 10px;
    max-width: 100%;
}

/* Estilo para los botones */
.buttons-bar .btn {
    border-radius: 5px;
    padding: 8px 12px;
    font-size: 14px;
    font-weight: bold;
    transition: transform 0.3s ease, background-color 0.3s ease;
    position: relative;
    overflow: hidden;
    margin: 5px; /* Margen pequeño entre botones */
}

/* Tooltip debajo del botón */
.buttons-bar .btn:hover::after {
    content: attr(title); /* El contenido será el valor del atributo title */
    position: absolute;
    bottom: -40px;
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 12px;
    white-space: nowrap;
    opacity: 0;
    animation: fadeIn 0.3s forwards; /* Aparecer suavemente */
}

/* Círculo de color encima del botón */
.buttons-bar .btn:hover::before {
    content: '';
    position: absolute;
    top: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 15px;
    height: 15px;
    background-color: #ff9800; /* Color del círculo */
    border-radius: 50%;
    opacity: 0;
    animation: fadeIn 0.3s forwards;
}

/* Movimiento suave del botón al pasar el mouse */
.buttons-bar .btn:hover {
    transform: translateY(-5px); /* El botón sube 5px */
    box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.15); /* Sombra más grande */
}

/* Animación de entrada suave */
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* Estilo para la "Versión de factura electrónica" */
.version-container {
    background-color: #ffeb3b;
    color: black;
    padding: 8px 15px;
    border-radius: 5px;
    font-weight: bold;
    position: relative;
}

.version-container:hover {
    transform: translateY(-5px); /* El texto de la versión se eleva al pasar el mouse */
    box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.15);
}

/* Ajustes específicos para el área de sucursal y fecha dentro de la franja */
.sucursal-fecha {
    display: flex;
    align-items: center;
    margin-left: auto; /* Mueve la sucursal y fecha al final de la franja */
}

.sucursal-container select {
    max-width: 200px; /* Ajusta el ancho del campo de sucursal */
}

.fecha-container {
    font-weight: bold;
    color: #333;
    margin-left: 15px; /* Espacio entre la sucursal y la fecha */
}

.fecha-container span {
    font-size: 14px;
    font-weight: bold;
    display: inline-block;
    white-space: nowrap; /* Asegura que todo el contenido quede en una sola línea */
}

/* Icono de atajos de teclado */
.keyboard-shortcut-icon i {
    color: #007bff;
    font-size: 16px; /* Tamaño consistente para los iconos */
    transition: transform 0.3s ease;
}

.keyboard-shortcut-icon i:hover {
    transform: translateY(-5px); /* Movimiento suave al pasar el mouse */
}

/* --------- Modo móvil (Celular) --------- */
@media (max-width: 768px) {
    /* Mostrar solo los botones Home, Cerrar Registro, Agregar Gasto y Sucursales */
    .buttons-bar .btn:not(.btn-home):not(.btn-close-register):not(.btn-add-expense) {
        display: none; /* Ocultar los demás botones en móvil */
    }

    .buttons-bar .btn {
        width: 100%; /* Que los botones ocupen todo el ancho en móvil */
        margin-bottom: 10px;
        font-size: 14px; /* Aumentar un poco el tamaño de fuente en móvil */
    }

    /* Estilo para la fecha y la sucursal en móviles */
    .sucursal-fecha {
        flex-direction: column; /* Colocar la fecha y la sucursal en una columna en lugar de en una fila */
        align-items: flex-start; /* Alinear el contenido a la izquierda */
        margin-left: 0;
        margin-top: 10px; /* Separar del resto de los botones */
    }

    .sucursal-container select {
        width: 100%; /* Hacer que el select ocupe todo el ancho en móvil */
    }

    .fecha-container {
        margin-left: 0; /* Eliminar el margen izquierdo en móvil */
        margin-top: 5px; /* Añadir un poco de espacio encima */
        font-size: 14px; /* Tamaño de fuente adecuado para móvil */
    }
}

</style>
@if(!empty($__system_settings['additional_css']))
    {!! $__system_settings['additional_css'] !!}
@endif