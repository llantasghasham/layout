@include('layouts.partials.css')



@php

    $go_back_url = action('SellPosController@index');

    $transaction_sub_type = '';

    $view_suspended_sell_url = action('SellController@index').'?suspended=1';

    $pos_redirect_url = action('SellPosController@create');

@endphp



@if(!empty($pos_module_data))

    @foreach($pos_module_data as $key => $value)

        @php

            if(!empty($value['go_back_url'])) {

                $go_back_url = $value['go_back_url'];

            }



            if(!empty($value['transaction_sub_type'])) {

                $transaction_sub_type = $value['transaction_sub_type'];

                $view_suspended_sell_url .= '&transaction_sub_type='.$transaction_sub_type;

                $pos_redirect_url .= '?sub_type='.$transaction_sub_type;

            }

        @endphp

    @endforeach

@endif



<input type="hidden" name="transaction_sub_type" id="transaction_sub_type" value="{{$transaction_sub_type}}">

@inject('request', 'Illuminate\Http\Request')



<div class="col-md-12"> <!-- Ajuste de contenedor para toda la faja -->

  <input type="hidden" id="pos_redirect_url" value="{{$pos_redirect_url}}">

  

  <!-- Contenedor con la franja de botones -->

  <div class="buttons-bar d-flex flex-wrap align-items-center justify-content-between p-2" style="background-color: #e3f2fd; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);">

      

      <!-- por hernan $default_location->id ?? null -->

<div style="width: 10%;hight:3px; margin: 3px; display:none">

    <div class="input-group">

        <span class="input-group-addon">

            <i class="fa fa-desktop"></i>

        </span>

        {!! Form::text('id_terminal', $user_id, ['class' => 'form-control', 'readonly']) !!}

    </div>

</div>



  <!-- Sucursal y Fecha -->

  <div class="sucursal-fecha d-flex align-items-center">

    <!-- Sucursal -->

    <div class="sucursal-container m-2">

        {!! Form::select('select_location_id', $business_locations, 

        $default_location->id ?? null , ['class' => 'form-control input-sm',

        'id' => 'select_location_id', 

        'required', 'autofocus'], $bl_attributes) !!}

    </div>



    <!-- Fecha y hora -->

    <div class="fecha-container m-2 d-flex align-items-center">

        <span>{{ @format_datetime('now') }}</span>

    </div>



    <!-- Icono de atajos de teclado -->

    <div class="keyboard-shortcut-icon m-2 d-flex align-items-center">

        <i class="fas fa-laptop-code text-muted" aria-hidden="true"

           data-container="body" data-toggle="popover" data-placement="bottom" 

           data-content="@include('sale_pos.partials.keyboard_shortcuts_details')" 

           data-html="true" data-trigger="hover" title="Atajos de Teclado"></i>

    </div>

</div>



<ul class="nav navbar-nav">

    <!-- Campana de Notificaciones -->

    @include('layouts.partials.header-notifications')

</ul>



  <!-- Contenedor de botones y elementos -->

<div class="button-container d-flex flex-wrap align-items-center">



  <!-- Botón Home -->

  <a href="{{ url('/home') }}" title="Ir a Home" class="btn btn-primary btn-flat m-2 btn-xs btn-home">

    <strong><i class="fa fa-home fa-lg"></i></strong>

  </a>



  <!-- Botón Go Back -->

  <a href="{{$go_back_url}}" title="Regresar" class="btn btn-info btn-flat m-2 btn-xs">

    <strong><i class="fa fa-backward fa-lg"></i></strong>

  </a>



  <!-- Botón para abrir el formulario en una ventana emergente -->

  <button type="button" class="btn btn-info btn-flat m-2 btn-xs" onclick="abrirVentanaEmergente()">

    <strong><i class="fas fa-tire"></i> Buscar Llantas</strong>

  </button>



  <!-- Botón WhatsApp -->

  <a href="https://chat.shakarbakar.com/tickets/" target="_blank" title="Abrir WhatsApp" class="btn btn-success btn-xs m-2">

    <strong><i class="fab fa-whatsapp"></i></strong>

  </a>



  <!-- Botón Borrar Caché -->

  <a href="{{ route('borrar-cache') }}" title="Borrar Caché" class="btn btn-danger btn-xs m-2">

    <strong><i class="fa fa-trash"></i></strong>

  </a>



  <!-- Botón de Ganancias del Día -->

  @can('profit_loss_report.view')

    <button type="button" id="view_todays_profit" title="Ganancias del Día" class="btn btn-success btn-xs m-2">

      <strong><i class="fas fa-money-bill-alt fa-lg"></i></strong>

    </button>

  @endcan



  <!-- Botón Cerrar Registro -->

  @can('close_cash_register')

    <button type="button" id="close_register" title="Cerrar Registro" class="btn btn-danger btn-xs m-2 btn-modal btn-close-register" data-container=".close_register_modal" 

        data-href="{{ action('CashRegisterController@getCloseRegister')}}">

      <strong><i class="fa fa-window-close fa-lg"></i></strong>

    </button>

  @endcan



  <!-- Botón Detalles de Registro -->

  @can('view_cash_register')

    <button type="button" id="register_details" title="Detalles de Registro" class="btn btn-success btn-xs m-2 btn-modal" data-container=".register_details_modal" 

        data-href="{{ action('CashRegisterController@getRegisterDetails')}}">

      <strong><i class="fa fa-briefcase fa-lg" aria-hidden="true"></i></strong>

    </button>

  @endcan



  <!-- Botón Calculadora -->

  <button title="Calculadora" id="btnCalculator" type="button" class="btn btn-success btn-xs m-2 popover-default" data-toggle="popover" data-trigger="click" data-content='@include("layouts.partials.calculator")' data-html="true" data-placement="bottom">

    <strong><i class="fa fa-calculator fa-lg" aria-hidden="true"></i></strong>

  </button>



  <!-- Botón Pantalla Completa -->

  <button type="button" title="Pantalla Completa" class="btn btn-primary btn-xs m-2 hidden-xs" id="full_screen">

    <strong><i class="fa fa-window-maximize fa-lg"></i></strong>

  </button>



  <!-- Botón Ver Ventas Suspendidas -->

  <button type="button" id="view_suspended_sales" title="Ventas Suspendidas" class="btn bg-yellow btn-xs m-2 btn-modal" data-container=".view_modal" 

    data-href="{{$view_suspended_sell_url}}">

    <strong><i class="fa fa-pause-circle fa-lg"></i></strong>

  </button>



  <!-- Botón Ver Productos (Solo móvil) -->

  @if(empty($pos_settings['hide_product_suggestion']))

    <button type="button" title="Ver Productos" class="btn btn-success btn-xs m-2 btn-modal mobile-only" data-toggle="modal" data-target="#mobile_product_suggestion_modal">

        <strong><i class="fa fa-cubes fa-lg"></i></strong>

    </button>

  @endif



  <!-- Botón Agregar Gasto -->

  @can('expense.add')

    <button type="button" title="Agregar Gasto" class="btn bg-purple btn-xs m-2 btn-add-expense" id="add_expense">

      <strong><i class="fa fas fa-minus-circle"></i> Agregar Gasto</strong>

    </button>

  @endcan



  <!-- Botón de Reparar -->

  @if(Module::has('Repair') && $transaction_sub_type != 'repair')

    @include('repair::layouts.partials.pos_header')

  @endif



  <!-- Versión de Factura Electrónica -->

  <div class="btn bg-teal btn-flat m-2 btn-xs text-white" style="font-weight: bold;">

    Factura v4.3

  </div>



  <!-- Mensaje de Bienvenida -->

  <div class="btn bg-purple btn-flat m-2 btn-xs text-white" style="font-weight: bold;">

    Hola: {{ Session::get('user.first_name') }}

  </div>





  </div>

</div>



<script>

    function abrirVentanaEmergente() {

        window.open(

            '{{ route("busqueda.index") }}',  // Usa la ruta de Laravel para el formulario

            'buscarLlantas',

            'width=800,height=600,scrollbars=yes,resizable=yes,toolbar=no,menubar=no,location=no,status=no,titlebar=no'

        );

    }

    

    document.addEventListener('DOMContentLoaded', function () {
      const responderChat = document.getElementById('responder-chat');
      const cerrarChat = document.getElementById('cerrar-chat');
      const chatContainer = document.getElementById('chat-container');
      const chatIframe = document.getElementById('chat-iframe');

      if (responderChat && cerrarChat && chatContainer && chatIframe) {
          responderChat.addEventListener('click', function () {
              // Mostrar el contenedor del chat
              chatContainer.style.display = 'block';

              // Configurar la URL del iframe al autologin del sistema de chat
              chatIframe.src = "https://chatweb.llantaselpana.com/lhc_web/index.php/esp/user/autologinuser/fd82314a380c579ce1dd7bbfc565af1c2cf02c976344498ec392c882c73562a8";
          });

          cerrarChat.addEventListener('click', function () {
              // Ocultar el contenedor del chat
              chatContainer.style.display = 'none';
          });
      } else {
          console.info('Uno o más elementos necesarios no existen en el DOM.');
      }
    });

</script>

