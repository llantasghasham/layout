
<div class="modal-dialog modal-lg" role="document">
  <div class="modal-content">
    {!! Form::open([
      'url' => action('BusinessLocationController@update' , 
      [$location->id] ), 
      'method' => 'PUT', 
      'id'    => 'business_location_add_form',
      'name'  => 'business_location_add_form',
      'class' => 'business_location_add_form', 
      'files' => true ]) 
    !!}
 
    {!! Form::hidden('hidden_id', $location->id, ['id' => 'hidden_id']); !!}
    {!! Form::hidden('ruta',$_ENV['APP_URL'], ['id' => 'ruta']); !!}
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title">@lang( 'business.edit_business_location' )</h4>
    </div>
     <div class="modal-body">
      <div class="row">
      
  
        <div class="col-sm-12">
          <div class="form-group">
            {!! Form::label('name', __( 'invoice.name' ) . ':*') !!}
            {!! Form::text('name', $location->name, ['class' => 'form-control', 'required', 'placeholder' => __( 'invoice.name' ) ]); !!}
          </div>
        </div>

        <!--- hecho por hernan -->
        <div class="clearfix"></div>
        <div class="col-sm-4">
            <div class="form-group">
                {!! Form::label('label_tipo_identificacion','Tipo de Identificación '. ':*') !!}
                {!! Form::select('tipo_ident',$tipoIdenLis,$location->tipo_ident, ['class' => 'form-control','required','id'=>'tipo_ident',
            'placeholder' => __('messages.please_select')]); !!}
            </div>
        </div>
        <div class="col-sm-4">
            <div class="form-group">
                {!! Form::label('label_cedula_juridica','Cédula'. ':*') !!}
                {!! Form::text('cedula_juridica', $location->cedula_juridica, ['class' => 'form-control','required',
                'placeholder' => 'Cédula']); !!}                
            </div>
        </div>
        <div class="col-sm-12">
          <div class="form-group">
              {!! Form::label('label_actividad_economica','Actividad económica'. ':*') !!}
              {!! Form::select('actividad_economica_id',$actividad_economica,$location->actividad_economica_id, ['class' => 'form-control','id'=>'id','placeholder' => __('messages.please_select'), 'required']); !!}           
          </div>
        </div>        
        <!---  fin hecho   --->

        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('location_id',__( 'lang_v1.location_id' ) . ':') !!}
              {!! Form::text('location_id', $location->location_id, ['class' => 'form-control', 'placeholder' => __( 'lang_v1.location_id' ) ]); !!}
          </div> 
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('landmark', __( 'business.landmark' ) . ':') !!}
              {!! Form::text('landmark', $location->landmark, ['class' => 'form-control', 'placeholder' => __( 'business.landmark' ) ]); !!}
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('city', __( 'business.city' ) . ':*') !!}
              {!! Form::text('city', $location->city, ['class' => 'form-control', 'placeholder' => __( 'business.city'), 'required' ]); !!}
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('zip_code', __( 'business.zip_code' ) . ':*') !!}
              {!! Form::text('zip_code', $location->zip_code, ['class' => 'form-control', 'placeholder' => __( 'business.zip_code'), 'required' ]); !!}
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('state', __( 'business.state' ) . ':*') !!}
              {!! Form::text('state', $location->state, ['class' => 'form-control', 'placeholder' => __( 'business.state'), 'required' ]); !!}
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('country', __( 'business.country' ) . ':*') !!}
            <!-- por Hernan --> 
            {!! Form::select('country',$countrys,$location->country, ['class' => 'form-control','country'=>'country',
            'placeholder' => __('messages.please_select')]); !!}           
            <!-- fin hernan-->
          </div>
          <!-- //!! Form::text('country', $location->country, ['class' => 'form-control', 'placeholder' => __( 'business.country'), 'required' ]); !!} -->
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-2">
          <div class="form-group">
            {!! Form::label('codpais1', 'Código país 1:') !!}
            {!! Form::text('codpais1', $location->codpais1, ['class' => 'form-control', 'placeholder' => "Código de país"]); !!}
          </div>
        </div>
        <div class="col-sm-4">
          <div class="form-group">
            {!! Form::label('mobile', __( 'business.mobile' ) . ':') !!}
            {!! Form::text('mobile', $location->mobile, ['class' => 'form-control', 'placeholder' => __( 'business.mobile')]); !!}
          </div>
        </div>
        <div class="col-sm-2">
          <div class="form-group">
            {!! Form::label('codpais2', 'Código país 2:') !!}
            {!! Form::text('codpais2', $location->codpais2, ['class' => 'form-control', 'placeholder' => "Código de país"]); !!}
          </div>
        </div>
        <div class="col-sm-4">
          <div class="form-group">
            {!! Form::label('alternate_number', __( 'business.alternate_number' ) . ':') !!}
            {!! Form::text('alternate_number', $location->alternate_number, ['class' => 'form-control', 'placeholder' => __( 'business.alternate_number')]); !!}
          </div>
        </div>        
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('email', __( 'business.email' ) . ':') !!}
            {!! Form::email('email', $location->email, ['class' => 'form-control', 'placeholder' => __( 'business.email')]); !!}
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('website', __( 'lang_v1.website' ) . ':') !!}
            {!! Form::text('website', $location->website, ['class' => 'form-control', 'placeholder' => __( 'lang_v1.website')]); !!}
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('invoice_scheme_id', __('invoice.invoice_scheme') . ':*') !!} @show_tooltip(__('tooltip.invoice_scheme'))
              {!! Form::select('invoice_scheme_id', $invoice_schemes, $location->invoice_scheme_id, ['class' => 'form-control', 'required',
              'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('invoice_layout_id', __('lang_v1.invoice_layout_for_pos') . ':*') !!} @show_tooltip(__('tooltip.invoice_layout'))
              {!! Form::select('invoice_layout_id', $invoice_layouts,  $location->invoice_layout_id, ['class' => 'form-control', 'required',
              'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('sale_invoice_layout_id', __('lang_v1.invoice_layout_for_sale') . ':*') !!} @show_tooltip(__('tooltip.invoice_layout'))
              {!! Form::select('sale_invoice_layout_id', $invoice_layouts,  $location->sale_invoice_layout_id, ['class' => 'form-control', 'required',
              'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group">
            {!! Form::label('selling_price_group_id', __('lang_v1.default_selling_price_group') . ':') !!} @show_tooltip(__('lang_v1.location_price_group_help'))
              {!! Form::select('selling_price_group_id', $price_groups, $location->selling_price_group_id, ['class' => 'form-control',
              'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>

        <!-- por hernan --> 
        <div class="col-sm-3">
          <div class="form-group">
            {!! Form::label('Provincia','Provincia'.':') !!} 
            {!! Form::select('provincia_id',$provincias,$location->provincia_id, ['class' => 'form-control','id'=>'provincia',
            'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>        
        <div class="col-sm-3">
          <div class="form-group">
            {!! Form::label('Canton','Cantón'.':') !!} 
            {!! Form::select('canton_id',$cantons,$location->canton_id, ['class' => 'form-control','id'=>'canton',
            'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
            {!! Form::label('Distrito','Distrito'.':') !!}
            {!! Form::select('distrito_id',$distritos,$location->distrito_id, ['class' => 'form-control','id'=>'distrito',
            'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group">
            {!! Form::label('Barrio','Barrio'.':') !!} 
            {!! Form::select('barrio_id',$barrios,$location->barrio_id, ['class' => 'form-control','id'=>'barrio',
            'placeholder' => __('messages.please_select')]); !!}
          </div>
        </div>
        <!-- fin hernan -->        

        <div class="clearfix"></div>
        @php
          $custom_labels = json_decode(session('business.custom_labels'), true);
          $location_custom_field1 = !empty($custom_labels['location']['custom_field_1']) ? $custom_labels['location']['custom_field_1'] : __('lang_v1.location_custom_field1');
          $location_custom_field2 = !empty($custom_labels['location']['custom_field_2']) ? $custom_labels['location']['custom_field_2'] : __('lang_v1.location_custom_field2');
          $location_custom_field3 = !empty($custom_labels['location']['custom_field_3']) ? $custom_labels['location']['custom_field_3'] : __('lang_v1.location_custom_field3');
          $location_custom_field4 = !empty($custom_labels['location']['custom_field_4']) ? $custom_labels['location']['custom_field_4'] : __('lang_v1.location_custom_field4');
        @endphp
        <div class="col-sm-3">
        <div class="form-group">
            {!! Form::label('custom_field1', $location_custom_field1 . ':') !!}
            {!! Form::text('custom_field1', $location->custom_field1, ['class' => 'form-control', 
                'placeholder' => $location_custom_field1]); !!}
        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            {!! Form::label('custom_field2', $location_custom_field2 . ':') !!}
            {!! Form::text('custom_field2', $location->custom_field2, ['class' => 'form-control', 
                'placeholder' => $location_custom_field2]); !!}
        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            {!! Form::label('custom_field3', $location_custom_field3 . ':') !!}
            {!! Form::text('custom_field3', $location->custom_field3, ['class' => 'form-control', 
                'placeholder' => $location_custom_field3]); !!}
        </div>
      </div>
      <div class="col-sm-3">
        <div class="form-group">
            {!! Form::label('custom_field4', $location_custom_field4 . ':') !!}
            {!! Form::text('custom_field4', $location->custom_field4, ['class' => 'form-control', 
                'placeholder' => $location_custom_field4]); !!}
        </div>
      </div>

      <!-- inicio por hernan  -->  
      <div class="col-sm-7"> 
        <div class="form-group">
          {!! Form::label('certificado', 'Archivo de certificación criptografica:') !!}
          <!-- { !! Form::file('certificado',['id'=>'certificado','accept'=>'application/x-pkcs12']); !!} -->
          {!! Form::text('certificado',$location->certificado, ['id'=>'certificado','required','class'=>'form-control']) !!}
          <small>
              <p class="help-block">
                  <!-- @ lang('purchase.max_file_size', ['size' => (config('constants.document_size_limit') / 1000000)]) .p12 -->
                  Debes copiar el archivo de llaveEncriptada en la carpeta \public\FileEncriptados 
              </p>
          </small>
        </div>
      </div>        
      <div class="col-sm-3"> 
        <div class="form-group">
            {!! Form::label('llavecripto','Llave criptografica:') !!}
            <input id="llavecripto" type="password" class="form-control" name="llavecripto" required value="<?php echo $location->llavecripto?>">
            <!-- { !! Form::password('llavecripto',$location->llavecripto, array('name'=>'llavecripto','id' => 'llavecripto','required', "class" => "form-control")) !!} -->
          </div>
      </div>
      <div class="col-sm-2"> 
        <div class="form-group">
          <input id="verificar" value="ver certificado" type="button" class="btn btn-primary" name="verificar" onclick="vercertificad()">
        </div>
      </div>

      <!--  ******************  --> 
      <div class="col-sm-8"> 
        <div class="form-group">
          {!! Form::label('username','Usuario de Hacienda:') !!}
          {!! Form::text('username',$location->username, ['id'=>'username','required','class' => 'form-control']) !!}
        </div>
      </div>
      <div class="col-sm-4"> 
        <div class="form-group">
            {!! Form::label('password','Clave usuario de Hacienda:') !!}
            <input id="password" type="password" class="form-control" name="password" required value="<?php echo $location->password?>">
            <!-- { !! Form::password('password','password',$location->password, array('name'=>'password','id' => 'password','required', "class" => "form-control")) !!} -->
          </div>
      </div>
      <!--  ******************  --> 
      <div class="col-sm-8"> 
        <div class="form-group">
          {!! Form::label('ruta_xml','Ruta del xml:') !!}
          {!! Form::text('ruta_xml',$location->ruta_xml, ['name'=>'ruta_xml','id'=>'ruta_xml','required','class' => 'form-control']) !!}
        </div>
      </div>
      <div class="col-sm-4"> 
        <div class="form-group">
            {!! Form::label('clave_mail','Clave del email:') !!}
            <input id="clave_mail" type="password" class="form-control" name="clave_mail" required value="<?php echo $location->clave_mail?>">
          <!--  { !! Form::password('password','clave_mail',$location->clave_mail, array('name'=>'clave_mail','id' => 'clave_mail','required', "class" => "form-control")) !!} -->
          </div> 
      </div>
      <div class="col-sm-4">  
        <div class="form-group">
          <label>
            {{ Form::radio('cliente_id','api-stag',($location->cliente_id=='api-stag')? true : false) }}<span> api-stag </span>
          </label>
          <label>
            {{ Form::radio('cliente_id','api-prod',($location->cliente_id=='api-prod')? true : false) }}<span> api-prod </span>
          </label>
        </div>
      </div>     
      <!-- fin por hernan -->

      <div class="clearfix"></div>
      <hr>
      <div class="col-sm-12">
        <div class="form-group">
          {!! Form::label('featured_products', __('lang_v1.pos_screen_featured_products') . ':') !!} @show_tooltip(__('lang_v1.featured_products_help'))
            {!! Form::select('featured_products[]', $featured_products, $location->featured_products, ['class' => 'form-control',
            'id' => 'featured_products', 'multiple']); !!}
        </div>
      </div>
      <div class="clearfix"></div>
      <hr>
          <div class="col-sm-12">
            <strong>@lang('lang_v1.payment_options'): @show_tooltip(__('lang_v1.payment_option_help'))</strong>
            <div class="form-group">
            <table class="table table-condensed table-striped">
              <thead>
                <tr>
                  <th class="text-center">@lang('lang_v1.payment_method')</th>
                  <th class="text-center">@lang('lang_v1.enable')</th>
                  <th class="text-center @if(empty($accounts)) hide @endif">@lang('lang_v1.default_accounts') @show_tooltip(__('lang_v1.default_account_help'))</th>
                </tr>
              </thead>
              <tbody>
                @php
                  $default_payment_accounts = !empty($location->default_payment_accounts) ?
                                      json_decode($location->default_payment_accounts, true) : [];
                @endphp
                @foreach($payment_types as $key => $value)
                  <tr>
                    <td class="text-center">{{$value}}</td>
                    <td class="text-center">{!! Form::checkbox('default_payment_accounts[' . $key . '][is_enabled]', 1, !empty($default_payment_accounts[$key]['is_enabled'])); !!}</td>
                    <td class="text-center @if(empty($accounts)) hide @endif">
                      {!! Form::select('default_payment_accounts[' . $key . '][account]', $accounts, !empty($default_payment_accounts[$key]['account']) ? $default_payment_accounts[$key]['account'] : null, ['class' => 'form-control input-sm']); !!}
                    </td>
                  </tr>
                @endforeach
            </table>
            </div>
          </div>
      </div>
    </div>

    <div class="modal-footer">
      <button type="submit" class="btn btn-primary">@lang( 'messages.save' )</button>
      <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
    </div>
    {!! Form::close() !!}
 
  </div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->  
<div id="ver_informacion" name="ver_informacion" 
style="position:absolute; z-index:1001; width:70%; border: 2px solid ; display: none; top:50%; 
left:15%; height:600px; background-color:#f0f1e9ec; padding: 10px 10px 10px ;" class="modal-dialog"> 

<div onclick="cerrar_ver('#ver_informacion')" onMouseover="this.style.color='#2e2423cc'" onMouseout="this.style.color='#f72408cc'">x</div>

<div style="width:100%; height:95%; color :#22221fcc; overflow-y: scroll " id="informacion" name="informacion"><div>
</div>

@section('javascript')    
	<!-- <script>
    var p12_fileinput = {
      showUpload: false,
      showPreview: false,
      browseLabel: LANG.file_browse_label,
      removeLabel: LANG.remove,
      previewSettings: false
    };
    $('#certificado').fileinput(p12_fileinput);
  </script> -->
 @endsection 
