<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Buscar Llantas</title>

    <!-- Cargar Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Cargar el archivo CSS de búsqueda -->
    <link href="{{ asset('css/busqueda.css') }}" rel="stylesheet">
</head>

<body>

    <div class="container mt-5" id="custom-search-form-container">
        <center>
            <h2>Buscador de Llantas</h2>
        </center>

        <!-- Botones para cambiar entre formularios -->
        <div class="d-flex justify-content-center mb-4">
            <button type="button" class="btn btn-success" onclick="mostrarFormulario('wheelSize')">Buscar llantas Avanzado</button>
            <button type="button" class="btn btn-primary me-2" onclick="mostrarFormulario('modelo')">Buscar llantas por
                Modelo</button>
            <button type="button" class="btn btn-secondary me-2" onclick="mostrarFormulario('dimensiones')">Buscar
                llantas por Dimensiones</button>
        </div>

        <!-- Formulario para buscar llantas por modelo de carro -->
        <div id="formulario-modelo" class="formulario-busqueda">
            <h3>Buscar llantas por tu Modelo de Carro</h3>
            <form id="custom-search-form" action="" method="post">
                <label for="marca">Marca:</label>
                <select name="marca" id="marca" class="form-control mb-2"></select>

                <label for="modelo">Modelo:</label>
                <select name="modelo" id="modelo" class="form-control mb-2" disabled></select>

                <label for="submodelo">Submodelo:</label>
                <select name="submodelo" id="submodelo" class="form-control mb-2" disabled></select>

                <label for="version">Versión:</label>
                <select name="version" id="version" class="form-control mb-2" disabled></select>

                <label for="anio">Año:</label>
                <select name="anio" id="anio" class="form-control mb-3" disabled></select>

                <button type="submit" class="btn btn-primary">Buscar por Modelo de Carro</button>
            </form>
            <div id="search-results" class="mt-3"></div>
        </div>

        <!-- Formulario para buscar llantas por dimensiones -->
        <div id="formulario-dimensiones" class="formulario-busqueda" style="display: none;">
            <h3>Buscar llantas por Dimensiones</h3>
            <form id="custom-search-form-dimensiones">
                <div class="form-row">
                    <div class="form-column">
                        <label for="ancho">Ancho:</label>
                        <select id="ancho" name="ancho" required>
                            <!-- Opciones de ancho -->
                            <option value="105">105</option>
                            <option value="115">115</option>
                            <option value="125">125</option>
                            <option value="135">135</option>
                            <option value="145">145</option>
                            <option value="155">155</option>
                            <option value="165">165</option>
                            <option value="175">175</option>
                            <option value="185">185</option>
                            <option value="195">195</option>
                            <option value="205">205</option>
                            <option value="215">215</option>
                            <option value="225">225</option>
                            <option value="235">235</option>
                            <option value="245">245</option>
                            <option value="250">250</option>
                            <option value="255">255</option>
                            <option value="260">260</option>
                            <option value="265">265</option>
                            <option value="270">270</option>
                            <option value="275">275</option>
                            <option value="280">280</option>
                            <option value="285">285</option>
                            <option value="295">295</option>
                            <option value="305">305</option>
                            <option value="315">315</option>
                            <option value="325">325</option>
                            <option value="335">335</option>
                            <option value="345">345</option>
                            <option value="355">355</option>
                            <option value="365">365</option>
                            <option value="375">375</option>
                            <option value="385">385</option>
                            <option value="395">395</option>
                            <option value="24X">24X</option>
                            <option value="25X">25X</option>
                            <option value="26X">26X</option>
                            <option value="27X">27X</option>
                            <option value="28X">28X</option>
                            <option value="29X">29X</option>
                            <option value="30X">30X</option>
                            <option value="31X">31X</option>
                            <option value="32X">32X</option>
                            <option value="33X">33X</option>
                            <option value="34X">34X</option>
                            <option value="35X">35X</option>
                            <option value="36X">36X</option>
                            <option value="37X">37X</option>
                            <option value="38X">38X</option>
                            <option value="39X">39X</option>
                            <option value="40X">40X</option>
                            <option value="41X">41X</option>
                            <option value="42X">42X</option>
                        </select>
                    </div>
                    <div class="form-column">
                        <label for="alto">Alto (Perfil):</label>
                        <select id="alto" name="alto" required>
                            <option value="20">20</option>
                            <option value="25">25</option>
                            <option value="30">30</option>
                            <option value="35">35</option>
                            <option value="40">40</option>
                            <option value="45">45</option>
                            <option value="50">50</option>
                            <option value="55">55</option>
                            <option value="60">60</option>
                            <option value="65">65</option>
                            <option value="70">70</option>
                            <option value="75">75</option>
                            <option value="80">80</option>
                            <option value="85">85</option>
                            <option value="90">90</option>
                            <option value="95">95</option>
                            <option value="7.5">7.5</option>
                            <option value="8.5">8.5</option>
                            <option value="9.5">9.5</option>
                            <option value="10.5">10.5</option>
                            <option value="11.5">11.5</option>
                            <option value="12.5">12.5</option>
                            <option value="13.5">13.5</option>
                            <option value="14">14</option>
                            <option value="14.5">14.5</option>
                            <option value="15.5">15.5</option>
                            <option value="16.5">16.5</option>
                            <option value="17.5">17.5</option>
                            <option value="18.5">18.5</option>
                        </select>
                    </div>
                    <div class="form-column">
                        <label for="aro">Aro:</label>
                        <select id="aro" name="aro" required>
                            <option value="R10">R10</option>
                            <option value="R12">R12</option>
                            <option value="R13">R13</option>
                            <option value="R14">R14</option>
                            <option value="R15">R15</option>
                            <option value="R16">R16</option>
                            <option value="R16.5">R16.5</option>
                            <option value="R17">R17</option>
                            <option value="R17.5">R17.5</option>
                            <option value="R18">R18</option>
                            <option value="R19">R19</option>
                            <option value="R19.5">R19.5</option>
                            <option value="R20">R20</option>
                            <option value="R21">R21</option>
                            <option value="R22">R22</option>
                            <option value="R23">R23</option>
                            <option value="R24">R24</option>
                            <option value="R25">R25</option>
                            <option value="R26">R26</option>
                            <option value="R27">R27</option>
                            <option value="2R8">R28</option>
                            <option value="R30">R30</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Buscar por Dimensiones</button>
            </form>
            <div id="search-results-inverso" class="mt-3"></div>
        </div>

        <div id="formulario-wheelSize" class="formulario-busqueda hidden">
            <h3>Buscar llantas con API de Wheel-Size</h3>
            <div id="ws-widget-container"></div>
        </div>
    </div>


    <!-- Incluir Bootstrap JS y Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="//services.wheel-size.com/code/ws-widget.js"></script>

    <script>
        /**
         * Función para alternar entre formularios.
         * Muestra el formulario correspondiente en función del parámetro 'tipo'.
         */
        function mostrarFormulario(tipo) {
            document.getElementById('formulario-modelo').style.display = (tipo === 'modelo') ? 'block' : 'none';
            document.getElementById('formulario-dimensiones').style.display = (tipo === 'dimensiones') ? 'block' : 'none';
        }

        document.addEventListener('DOMContentLoaded', function () {
            // Referencias a los select de cada filtro en el formulario de "Modelo de Carro"
            var selectMarca = document.getElementById('marca');
            var selectModelo = document.getElementById('modelo');
            var selectSubmodelo = document.getElementById('submodelo');
            var selectVersion = document.getElementById('version');
            var selectAnio = document.getElementById('anio');

            // Cargar las opciones iniciales para la "Marca"
            cargarMarcas();

            // Función para cargar las marcas disponibles
            function cargarMarcas() {
                fetch('/buscar/marcas')
                    .then(response => response.json())
                    .then(data => {
                        selectMarca.innerHTML = '<option value="">Seleccione una marca</option>';
                        data.forEach(function (marca) {
                            selectMarca.options[selectMarca.options.length] = new Option(marca.MARCA, marca.MARCA);
                        });
                        selectMarca.disabled = false;
                    })
                    .catch(error => console.error('Error al cargar las marcas:', error));
            }

            // Funciones para cargar los select según las opciones seleccionadas en el anterior
            selectMarca.addEventListener('change', function () {
                cargarModelos(this.value);
            });

            selectModelo.addEventListener('change', function () {
                cargarSubmodelos(this.value);
            });

            selectSubmodelo.addEventListener('change', function () {
                cargarVersiones(this.value);
            });

            selectVersion.addEventListener('change', function () {
                cargarAnios(this.value);
            });

            // Función para cargar modelos según la marca seleccionada
            function cargarModelos(marca) {
                fetch(`/buscar/modelos?marca=${marca}`)
                    .then(response => response.json())
                    .then(data => {
                        selectModelo.innerHTML = '<option value="">Seleccione un modelo</option>';
                        data.forEach(function (modelo) {
                            selectModelo.options[selectModelo.options.length] = new Option(modelo.BF_GLOBAL_MODEL, modelo.BF_GLOBAL_MODEL);
                        });
                        selectModelo.disabled = false;
                    })
                    .catch(error => console.error('Error al cargar los modelos:', error));
            }

            // Inicializar el widget de Wheel-Size
            function mostrarFormulario(tipo) {
                document.querySelectorAll('.formulario-busqueda').forEach(form => form.style.display = 'none');
                const form = document.getElementById(`formulario-${tipo}`);
                if (form) form.style.display = 'block';

                if (tipo === 'wheelSize') {
                    if (!document.querySelector('#ws-widget-container .ws-widget')) {
                        WheelSizeWidgets.create('#ws-widget-container', {
                            uuid: 'ee5093930d6245609091fc97790af7cc',
                            type: 'finder',
                            width: '100%'
                        });
                    }
                }
            }

            // Mostrar por defecto el formulario del widget
            mostrarFormulario('wheelSize');


            // Función para cargar submodelos según el modelo seleccionado
            function cargarSubmodelos(modelo) {
                fetch(`/buscar/submodelos?modelo=${modelo}`)
                    .then(response => response.json())
                    .then(data => {
                        selectSubmodelo.innerHTML = '<option value="">Seleccione un submodelo</option>';
                        data.forEach(function (submodelo) {
                            selectSubmodelo.options[selectSubmodelo.options.length] = new Option(submodelo.MODELO, submodelo.MODELO);
                        });
                        selectSubmodelo.disabled = false;
                    })
                    .catch(error => console.error('Error al cargar los submodelos:', error));
            }

            // Función para cargar versiones según el submodelo seleccionado
            function cargarVersiones(submodelo) {
                fetch(`/buscar/versiones?submodelo=${submodelo}`)
                    .then(response => response.json())
                    .then(data => {
                        selectVersion.innerHTML = '<option value="">Seleccione una versión</option>';
                        data.forEach(function (version) {
                            selectVersion.options[selectVersion.options.length] = new Option(version.VERSION, version.VERSION);
                        });
                        selectVersion.disabled = false;
                    })
                    .catch(error => console.error('Error al cargar las versiones:', error));
            }

            // Función para cargar años según la versión seleccionada
            function cargarAnios(version) {
                fetch(`/buscar/anios?version=${version}`)
                    .then(response => response.json())
                    .then(data => {
                        selectAnio.innerHTML = '<option value="">Seleccione un año</option>';
                        data.forEach(function (anio) {
                            selectAnio.options[selectAnio.options.length] = new Option(anio.ANIO, anio.ANIO);
                        });
                        selectAnio.disabled = false;
                    })
                    .catch(error => console.error('Error al cargar los años:', error));
            }

            // Envío de formulario para buscar por "Modelo de Carro"
            document.getElementById('custom-search-form').addEventListener('submit', function (e) {
                e.preventDefault();
                var resultados = document.getElementById('search-results');
                resultados.innerHTML = "Cargando resultados...";

                fetch(`/buscar/resultados?marca=${selectMarca.value}&modelo=${selectModelo.value}&submodelo=${selectSubmodelo.value}&version=${selectVersion.value}&anio=${selectAnio.value}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log(data);  // Imprime la respuesta para verificar el formato

                        // Verifica si data es un array y contiene elementos
                        if (Array.isArray(data) && data.length > 0) {
                            resultados.innerHTML = `<div class="resultados-cabecera">Resultados Encontrados:</div>`;
                            data.forEach(function (item) {
                                resultados.innerHTML += `<div class="resultado-item">Marca: ${item.MARCA}, Modelo: ${item.MODELO}, Año: ${item.ANIO}</div>`;
                            });
                        }
                        // Verifica si data es un objeto con una propiedad IDENTIFICACION (formato del primer código)
                        else if (data && data.IDENTIFICACION) {
                            resultados.innerHTML = `Resultado encontrado: ${data.IDENTIFICACION}`;
                        } else {
                            resultados.innerHTML = "<p>No se encontraron resultados.</p>";
                        }
                    })
                    .catch(error => {
                        console.error('Error al buscar los resultados:', error);
                        resultados.innerHTML = "<p>Error al cargar los resultados.</p>";
                    });
            });


            // Envío de formulario para buscar por "Dimensiones"
            document.getElementById('custom-search-form-dimensiones').addEventListener('submit', function (e) {
                e.preventDefault();

                var ancho = document.getElementById('ancho').value;
                var alto = document.getElementById('alto').value;
                var aro = document.getElementById('aro').value;
                var resultados = document.getElementById('search-results-inverso');

                resultados.innerHTML = "<p>Cargando resultados...</p>";

                fetch(`/buscar/dimensiones`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ ancho, alto, aro })
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data && data.length > 0) {
                            resultados.innerHTML = `<div class="resultados-cabecera">Resultados Encontrados:</div>`;
                            data.forEach(function (item) {
                                resultados.innerHTML += `<div class="resultado-item">Marca: ${item.MARCA}, Modelo: ${item.MODELO}, Año: ${item.ANIO}</div>`;
                            });
                        } else {
                            resultados.innerHTML = "<p>No se encontraron resultados.</p>";
                        }
                    })
                    .catch(error => {
                        console.error('Error al buscar:', error);
                        resultados.innerHTML = "<p>Error al cargar los resultados.</p>";
                    });
            });
        });
    </script>

</body>

</html>