<!DOCTYPE html>
<html>
<head>
    <title>Chat</title>
</head>
<body>
    <h1>Chat {{ $chat->id }}</h1>
</body>
</html>

<form method="POST" action="{{ route('messages.store') }}">
    @csrf
    <input type="hidden" name="chat_id" value="{{ $chat->id }}">
    <textarea name="content"></textarea>
    <button type="submit">Send</button>
</form>

