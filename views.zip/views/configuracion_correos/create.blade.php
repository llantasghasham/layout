@extends('layouts.app-config')

@section('title', 'Agregar Configuración')

@section('content')
<div class="container py-5">
    <div class="card shadow-lg p-5 rounded-3" style="background-color: #F9FAFB; border: 1px solid #E0E7FF;">
        <h1 class="fw-bold text-dark display-5 mb-5" style="color: #4B1C71;">
            <i class="bi bi-envelope-fill me-3" style="color: #6D28D9;"></i>Agregar Configuración de Correo
        </h1>

        <!-- Selección de Tipo de Correo -->
        <div class="mb-5">
            <label class="form-label fw-semibold fs-5 mb-3" style="color: #4B1C71;">¿Qué tipo de correo deseas configurar?</label>
            <div class="d-flex gap-4">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="tipo_correo" id="preconfigurado" value="preconfigurado" checked onchange="toggleForm()">
                    <label class="form-check-label" for="preconfigurado" style="color: #4B1C71;">Correo Preconfigurado (Gmail, Yahoo, Outlook)</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="tipo_correo" id="personalizado" value="personalizado" onchange="toggleForm()">
                    <label class="form-check-label" for="personalizado" style="color: #4B1C71;">Correo Personalizado (ej. correo@llantaselpana.com)</label>
                </div>
            </div>
        </div>

        <!-- Formulario -->
        <form action="{{ route('configuracion-correos.store') }}" method="POST" id="form-configuracion" class="needs-validation" novalidate>
            @csrf

            <!-- Campos Comunes -->
            <div class="mb-4">
                <label for="correo" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Correo Electrónico</label>
                <input type="email" name="correo" id="correo" class="form-control" placeholder="ejemplo@dominio.com" value="{{ old('correo') }}" required>
                <small class="text-muted" id="correo-hint">Ejemplo: user@gmail.com o correo@llantaselpana.com</small>
                @error('correo')<div class="text-danger">{{ $message }}</div>@enderror
            </div>

            <div class="mb-4">
                <label for="clave" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Clave</label>
                <input type="password" name="clave" id="clave" class="form-control" placeholder="Contraseña o clave de aplicación" required>
                <small class="text-muted" id="clave-hint">Para Gmail/Outlook, usa una clave de aplicación si tienes 2FA activado.</small>
                @error('clave')<div class="text-danger">{{ $message }}</div>@enderror
            </div>

            <!-- Campos Preconfigurados -->
            <div id="preconfigurado-fields" class="mb-4">
                <label for="proveedor" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Proveedor de Correo</label>
                <select name="proveedor" id="proveedor" class="form-select" onchange="autofillConfig()">
                    <option value="">Selecciona un proveedor</option>
                    <option value="gmail">Gmail</option>
                    <option value="yahoo">Yahoo</option>
                    <option value="outlook">Outlook</option>
                </select>
                <small class="text-muted">Selecciona tu proveedor para autocompletar la configuración.</small>
                <div id="outlook-warning" class="alert alert-warning mt-3 d-none" style="background-color: #FFF3CD; border-color: #FFECB5;">
                    <strong style="color: #856404;">Nota:</strong> Outlook requiere una clave de aplicación o OAuth 2.0. Consulta <a href="https://support.microsoft.com/es-es/office/crear-una-clave-de-aplicacion" target="_blank" style="color: #6D28D9;">cómo generarla</a>.
                </div>
            </div>

            <!-- Campos Personalizados -->
            <div id="personalizado-fields" class="d-none">
                <div class="mb-4">
                    <label for="servidor_imap" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Servidor IMAP/SMTP</label>
                    <input type="text" name="servidor_imap" id="servidor_imap" class="form-control" placeholder="imap.dominio.com" value="{{ old('servidor_imap') }}">
                    <small class="text-muted">Ejemplo: imap.llantaselpana.com</small>
                    @error('servidor_imap')<div class="text-danger">{{ $message }}</div>@enderror
                </div>

                <div class="mb-4">
                    <label for="puerto" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Puerto</label>
                    <input type="number" name="puerto" id="puerto" class="form-control" placeholder="993" value="{{ old('puerto') }}">
                    <small class="text-muted">IMAP: 993 (SSL), SMTP: 587 (TLS)</small>
                    @error('puerto')<div class="text-danger">{{ $message }}</div>@enderror
                </div>

                <div class="mb-4">
                    <label for="mail_driver" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Controlador de Correo</label>
                    <select name="mail_driver" id="mail_driver" class="form-select">
                        <option value="imap" {{ old('mail_driver') == 'imap' ? 'selected' : '' }}>IMAP</option>
                        <option value="smtp" {{ old('mail_driver') == 'smtp' ? 'selected' : '' }}>SMTP</option>
                    </select>
                    <small class="text-muted">IMAP para recibir, SMTP para enviar.</small>
                    @error('mail_driver')<div class="text-danger">{{ $message }}</div>@enderror
                </div>

                <div class="mb-4">
                    <label for="encryption" class="form-label fw-semibold fs-5" style="color: #4B1C71;">Encriptación</label>
                    <select name="encryption" id="encryption" class="form-select">
                        <option value="ssl" {{ old('encryption') == 'ssl' ? 'selected' : '' }}>SSL</option>
                        <option value="tls" {{ old('encryption') == 'tls' ? 'selected' : '' }}>TLS</option>
                        <option value="none" {{ old('encryption') == 'none' ? 'selected' : '' }}>Sin Encriptación</option>
                    </select>
                    <small class="text-muted">SSL para puerto 993, TLS para 587.</small>
                    @error('encryption')<div class="text-danger">{{ $message }}</div>@enderror
                </div>
            </div>

            <!-- Campos Ocultos para Preconfigurados -->
            <input type="hidden" name="servidor_imap" id="hidden_servidor_imap" value="{{ old('servidor_imap') }}">
            <input type="hidden" name="puerto" id="hidden_puerto" value="{{ old('puerto') }}">
            <input type="hidden" name="mail_driver" id="hidden_mail_driver" value="{{ old('mail_driver') }}">
            <input type="hidden" name="encryption" id="hidden_encryption" value="{{ old('encryption') }}">

            <div class="mb-4">
                <label class="form-label fw-semibold fs-5" style="color: #4B1C71;">Estado</label>
                <div class="form-check form-switch">
                    <input type="checkbox" name="activo" id="activo" value="1" class="form-check-input" {{ old('activo', 1) ? 'checked' : '' }}>
                    <label class="form-check-label" for="activo" id="activoLabel" style="color: #4B1C71;">{{ old('activo', 1) ? 'Activo' : 'Inactivo' }}</label>
                </div>
                <small class="text-muted">Activa esta configuración para usarla inmediatamente.</small>
            </div>

            <!-- Botones Separados -->
            <div class="row justify-content-between mt-5">
                <div class="col-auto">
                    <a href="{{ route('configuracion-correos.index') }}" class="btn btn-secondary shadow-sm hover-scale" style="background-color: #E0E7FF; color: #4B1C71; border-color: #6D28D9;">
                        <i class="bi bi-arrow-left"></i>Regresar
                    </a>
                </div>
                <div class="col-auto">
                    <div class="d-flex gap-3">
                        <button type="submit" class="btn btn-primary shadow-sm hover-scale animate__animated animate__pulse animate__infinite" style="background-color: #6D28D9; border-color: #6D28D9;">
                            <i class="bi bi-save"></i>Guardar
                        </button>
                        <button type="button" class="btn btn-info shadow-sm hover-scale" id="btnProbarCorreo" style="background-color: #4B1C71; border-color: #4B1C71; color: #FFFFFF;">
                            <i class="bi bi-plug-fill"></i>Probar
                        </button>
                    </div>
                </div>
            </div>
            <div id="resultadoPrueba" class="mt-4"></div>
        </form>
    </div>
</div>
@endsection

@section('styles')
<style>
    /* Ajustes específicos para los campos de formulario en esta vista */
    .form-control, .form-select {
        padding: 10px 15px !important;
        font-size: 16px !important;
    }
    .form-check-input {
        width: 20px !important;
        height: 20px !important;
    }
    /* Ajustes para los botones */
    .btn {
        padding: 10px 25px !important;
        font-size: 16px !important;
    }
    .btn i {
        font-size: 16px !important;
    }
    .hover-scale {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .hover-scale:hover {
        transform: scale(1.05);
        box-shadow: 0 6px 15px rgba(109, 40, 217, 0.2) !important;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
@endsection

@section('styles')
<style>
    .table i {
        font-size: 16px !important; /* Tamaño original de los íconos en la tabla */
    }
    .nav-sidebar .nav-link i {
        font-size: 16px !important; /* Ajusta los íconos del sidebar si es necesario */
    }
</style>
@endsection

@section('styles')
<style>
    .navbar i, .main-sidebar i {
        font-size: 10px !important;
    }
</style>
@endsection

@section('scripts')
<script>
    // Alternar entre formularios
    function toggleForm() {
        const preconfigurado = document.getElementById('preconfigurado').checked;
        document.getElementById('preconfigurado-fields').classList.toggle('d-none', !preconfigurado);
        document.getElementById('personalizado-fields').classList.toggle('d-none', preconfigurado);

        document.getElementById('correo-hint').textContent = preconfigurado ? 
            'Ejemplo: user@gmail.com, user@yahoo.com, user@outlook.com' : 
            'Ejemplo: correo@llantaselpana.com';
        document.getElementById('clave-hint').textContent = preconfigurado ? 
            'Para Gmail/Outlook/Yahoo, usa una clave de aplicación si tienes 2FA activado.' : 
            'Ingresa la contraseña de tu correo personalizado.';
    }

    // Autocompletar configuraciones predefinidas
    function autofillConfig() {
        const proveedor = document.getElementById('proveedor').value;
        const configs = {
            'gmail': { servidor: 'imap.gmail.com', puerto: 993, driver: 'imap', encryption: 'ssl' },
            'yahoo': { servidor: 'imap.mail.yahoo.com', puerto: 993, driver: 'imap', encryption: 'ssl' },
            'outlook': { servidor: 'imap-mail.outlook.com', puerto: 993, driver: 'imap', encryption: 'ssl' }
        };

        const config = configs[proveedor] || {};
        document.getElementById('hidden_servidor_imap').value = config.servidor || '';
        document.getElementById('hidden_puerto').value = config.puerto || '';
        document.getElementById('hidden_mail_driver').value = config.driver || '';
        document.getElementById('hidden_encryption').value = config.encryption || '';

        document.getElementById('outlook-warning').classList.toggle('d-none', proveedor !== 'outlook');
    }

    // Inicializar formulario
    toggleForm();

    // Validación Bootstrap
    (function() {
        'use strict';
        const forms = document.querySelectorAll('.needs-validation');
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    })();

    // Probar conexión
    document.getElementById('btnProbarCorreo').addEventListener('click', async function() {
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<i class="bi bi-hourglass-split"></i>Verificando...';

        const data = {
            correo: document.getElementById('correo').value,
            clave: document.getElementById('clave').value,
            servidor_imap: document.getElementById('preconfigurado').checked ? 
                document.getElementById('hidden_servidor_imap').value : 
                document.getElementById('servidor_imap').value,
            puerto: document.getElementById('preconfigurado').checked ? 
                document.getElementById('hidden_puerto').value : 
                document.getElementById('puerto').value,
            encryption: document.getElementById('preconfigurado').checked ? 
                document.getElementById('hidden_encryption').value : 
                document.getElementById('encryption').value,
            mail_driver: document.getElementById('preconfigurado').checked ? 
                document.getElementById('hidden_mail_driver').value : 
                document.getElementById('mail_driver').value
        };

        try {
            const response = await fetch('{{ route('configuracion-correos.probar') }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            const resultDiv = document.getElementById('resultadoPrueba');

            if (result.success) {
                resultDiv.innerHTML = `<div class="alert alert-success rounded-3" style="background-color: #D1E7DD; border-color: #A3CFBB;"><strong style="color: #0F5132;">✅ Conexión Exitosa</strong><br>Servidor: ${result.servidor_imap}<br>Puerto: ${result.puerto}<br>Tiempo: ${result.tiempo}ms</div>`;
                toastr.success('Configuración verificada', '¡Éxito!', { progressBar: true, timeOut: 5000 });
            } else {
                resultDiv.innerHTML = `<div class="alert alert-danger rounded-3" style="background-color: #F8D7DA; border-color: #F1A8A8;"><strong style="color: #842029;">⚠️ Error</strong><br>${result.message}<br>Detalle: ${result.detail}</div>`;
                toastr.error(result.detail || 'Error desconocido', '¡Error!', { progressBar: true, timeOut: 5000 });
            }
        } catch (error) {
            document.getElementById('resultadoPrueba').innerHTML = `<div class="alert alert-danger rounded-3" style="background-color: #F8D7DA; border-color: #F1A8A8;"><strong style="color: #842029;">❌ Error Inesperado</strong><br>${error.message}</div>`;
            toastr.error('Error inesperado: ' + error.message, '¡Error!', { progressBar: true, timeOut: 5000 });
        } finally {
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-plug-fill"></i>Probar';
        }
    });

    // Actualizar label de estado
    document.getElementById('activo').addEventListener('change', function() {
        document.getElementById('activoLabel').textContent = this.checked ? 'Activo' : 'Inactivo';
    });
</script>
@endsection