@php
    $page_title = 'Configuraciones de Correos';
@endphp

@extends('layouts.app-config')

@section('title', $page_title)

@section('content')
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="fw-bold text-dark"><i class="fas fa-envelope me-2"></i> {{ $page_title }}</h1>
        <a href="{{ route('configuracion-correos.create') }}" class="btn btn-primary btn-lg shadow-sm">
            <i class="fas fa-plus me-2"></i> Crear Configuraci��n
        </a>
    </div>

    <!-- Buscador -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div class="input-group">
                <span class="input-group-text bg-white border-0"><i class="fas fa-search"></i></span>
                <input type="text" id="searchInput" class="form-control border-0 shadow-none" placeholder="Buscar por correo...">
            </div>
        </div>
    </div>

    <!-- Notificaciones -->
    @if(session('success'))
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                toastr.success(@json(session('success')), '�0�3�0�7xito!', { timeOut: 5000, progressBar: true });
            });
        </script>
    @endif
    @if(session('error'))
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                toastr.error(@json(session('error')), '�0�3Error!', { timeOut: 5000, progressBar: true });
            });
        </script>
    @endif

    <!-- Tabla -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="correosTable">
                    <thead>
                        <tr>
                            <th class="ps-4">ID</th>
                            <th>Correo Electr��nico</th>
                            <th>Servidor IMAP</th>
                            <th>Puerto</th>
                            <th>Estado</th>
                            <th class="pe-4">Editar</th>
                            <th class="pe-4">Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($correos as $correo)
                            <tr class="correo-row">
                                <td class="ps-4">{{ $correo->id }}</td>
                                <td>{{ $correo->correo }}</td>
                                <td>{{ $correo->servidor_imap }}</td>
                                <td>{{ $correo->puerto }}</td>
                                <td>
                                    <div class="form-check form-switch">
                                        <input class="form-check-input toggle-activo" type="checkbox" 
                                               data-id="{{ $correo->id }}" 
                                               {{ $correo->activo ? 'checked' : '' }} 
                                               onchange="toggleActivo(this)">
                                        <label class="form-check-label">
                                            {{ $correo->activo ? 'Activo' : 'Inactivo' }}
                                        </label>
                                    </div>
                                </td>
                                <td class="pe-4">
                                    <a href="{{ route('configuracion-correos.edit', $correo->id) }}" 
                                       class="btn btn-warning btn-sm shadow-sm">
                                        <i class="fas fa-edit me-1"></i> Editar
                                    </a>
                                </td>
                                <td class="pe-4">
                                    <form action="{{ route('configuracion-correos.destroy', $correo->id) }}" method="POST" class="d-inline delete-form">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm shadow-sm">
                                            <i class="fas fa-trash me-1"></i> Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">No hay configuraciones de correo disponibles.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    // Buscador en tiempo real
    document.getElementById('searchInput').addEventListener('keyup', function() {
        const searchValue = this.value.toLowerCase();
        document.querySelectorAll('.correo-row').forEach(row => {
            row.style.display = row.cells[1].textContent.toLowerCase().includes(searchValue) ? '' : 'none';
        });
    });

    // Toggle Activo/Inactivo
    function toggleActivo(element) {
        const id = element.dataset.id;
        const activo = element.checked ? 1 : 0;
        const label = element.nextElementSibling;

        fetch('{{ route('configuracion-correos.toggle') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ id, activo })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                label.textContent = activo ? 'Activo' : 'Inactivo';
                toastr.success('Estado actualizado correctamente', '�0�3�0�7xito!');
            } else {
                element.checked = !activo;
                toastr.error(data.message, '�0�3Error!');
            }
        })
        .catch(error => {
            element.checked = !activo;
            toastr.error('Error inesperado: ' + error.message, '�0�3Error!');
        });
    }

    // Confirmaci��n de eliminaci��n
    document.querySelectorAll('.delete-form').forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!confirm('�0�7Est��s seguro de eliminar esta configuraci��n?')) {
                event.preventDefault();
            }
        });
    });
</script>
@endsection