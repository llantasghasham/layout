@extends('layouts.app-config')

@section('title', 'Probar Conexi��n')

@section('content')
<div class="container py-4">
    <div class="card shadow-sm p-4">
        <h1 class="fw-bold text-dark mb-4"><i class="fas fa-plug me-2"></i>Probar Conexi��n</h1>
        <form method="POST" action="{{ route('configuracion-correos.probar') }}" id="form-probar">
            @csrf

            <div class="mb-4">
                <label for="correo" class="form-label fw-semibold">Correo Electr��nico</label>
                <input type="email" class="form-control" name="correo" id="correo" placeholder="ejemplo@dominio.com" required>
                <small class="text-muted">Ejemplo: user@gmail.com, user@outlook.com, user@yahoo.com</small>
            </div>

            <div class="mb-4">
                <label for="clave" class="form-label fw-semibold">Clave</label>
                <input type="password" class="form-control" name="clave" id="clave" placeholder="Contrase�0�9a o clave de aplicaci��n" required>
                <small class="text-muted">Para Gmail/Outlook, usa una clave de aplicaci��n si tienes 2FA activado.</small>
            </div>

            <div class="mb-4">
                <label for="servidor_imap" class="form-label fw-semibold">Servidor IMAP</label>
                <input type="text" class="form-control" name="servidor_imap" id="servidor_imap" placeholder="imap.dominio.com" required>
                <small class="text-muted">Ejemplo: imap.gmail.com (Gmail), imap-mail.outlook.com (Outlook), imap.mail.yahoo.com (Yahoo).</small>
            </div>

            <div class="mb-4">
                <label for="puerto" class="form-label fw-semibold">Puerto</label>
                <input type="number" class="form-control" name="puerto" id="puerto" placeholder="993" required>
                <small class="text-muted">IMAP: 993 (SSL), POP3: 995 (SSL), SMTP: 587 (TLS) o 465 (SSL). Ejemplo para Gmail: 993 (IMAP) o 587 (SMTP).</small>
            </div>

            <div class="mb-4">
                <label for="mail_driver" class="form-label fw-semibold">Controlador de Correo</label>
                <select name="mail_driver" id="mail_driver" class="form-select" required>
                    <option value="imap">IMAP</option>
                    <option value="pop3">POP3</option>
                    <option value="smtp">SMTP</option>
                </select>
                <small class="text-muted">
                    - IMAP: Para recibir correos, sincroniza con el servidor.<br>
                    - POP3: Descarga correos al dispositivo, elimina del servidor.<br>
                    - SMTP: Para enviar correos.
                </small>
            </div>

            <div class="mb-4">
                <label for="encryption" class="form-label fw-semibold">Encriptaci��n</label>
                <select class="form-select" name="encryption" id="encryption" required>
                    <option value="ssl">SSL</option>
                    <option value="tls">TLS</option>
                    <option value="starttls">STARTTLS</option>
                    <option value="none">Sin Encriptaci��n</option>
                </select>
                <small class="text-muted">
                    - SSL: Cifrado completo, puerto 465/993.<br>
                    - TLS: Cifrado despu��s de conexi��n, puerto 587.<br>
                    - STARTTLS: Actualiza a cifrado tras conexi��n inicial.<br>
                    - Sin Encriptaci��n: No recomendado, inseguro.
                </small>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <a href="{{ route('configuracion-correos.index') }}" class="btn btn-secondary shadow-sm">
                    <i class="fas fa-arrow-left me-2"></i>Regresar
                </a>
                <button type="submit" class="btn btn-primary shadow-sm" id="btnProbar">
                    <i class="fas fa-plug me-2"></i>Probar Conexi��n
                </button>
            </div>
            <div id="resultadoPrueba" class="mt-3"></div>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script>
    document.getElementById('form-probar').addEventListener('submit', function(e) {
        e.preventDefault();
        const btn = document.getElementById('btnProbar');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Probando...';

        const data = {
            correo: document.getElementById('correo').value,
            clave: document.getElementById('clave').value,
            servidor_imap: document.getElementById('servidor_imap').value,
            puerto: document.getElementById('puerto').value,
            encryption: document.getElementById('encryption').value,
            mail_driver: document.getElementById('mail_driver').value
        };

        fetch('{{ route('configuracion-correos.probar') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('La respuesta del servidor no es JSON. Posible error del servidor.');
            }
            return response.json();
        })
        .then(data => {
            const resultDiv = document.getElementById('resultadoPrueba');
            if (data.success) {
                resultDiv.innerHTML = `
                    <div class="alert alert-success">
                        <strong>�7�3 Conexi��n Exitosa</strong><br>
                        Servidor: ${data.servidor_imap}<br>
                        Puerto: ${data.puerto}<br>
                        Tiempo de respuesta: ${data.tiempo}ms
                    </div>`;
                toastr.success('Conexi��n verificada', '�0�3�0�7xito!');
            } else {
                resultDiv.innerHTML = `
                    <div class="alert alert-danger">
                        <strong>�7�2�1�5 Error</strong><br>
                        Mensaje: ${data.message}<br>
                        Detalle: ${data.detail || 'No disponible'}
                    </div>`;
                toastr.error('Fallo en la conexi��n: ' + (data.detail || 'Error desconocido'), '�0�3Error!');
            }
        })
        .catch(error => {
            const resultDiv = document.getElementById('resultadoPrueba');
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <strong>�7�4 Error Inesperado</strong><br>
                    ${error.message}
                </div>`;
            toastr.error('Error inesperado: ' + error.message, '�0�3Error!');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-plug me-2"></i>Probar Conexi��n';
        });
    });
</script>
@endsection