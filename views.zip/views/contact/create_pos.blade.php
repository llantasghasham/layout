<div class="modal-dialog" role="document">
  <div class="modal-content">
  @php
    $form_id = 'contact_add_form';
    
    $tipoIdenLis=isset($tipoIdenLis) ? $tipoIdenLis : [];
    include DIR_PRO.'/app/Http/Controllers/tablas.php';

    if(isset($quick_add)){
      $form_id = 'quick_add_contact';
    }
    
    if(isset($store_action)) {
      $url = $store_action;
      $type = 'lead';
      $customer_groups = [];
    } else {
      $url = action('ContactController@store');
      $type = isset($selected_type) ? $selected_type : '';
      $sources = [];
      $life_stages = [];
      $users = [];
    }  
  @endphp
  
  {!! Form::open(['url' => $url, 'method' => 'post', 'id' => $form_id ]) !!}

  <div class="modal-header bg-primary">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" class="text-white">&times;</span></button>
    <h4 class="modal-title text-white">@lang('contact.add_contact')</h4>
  </div>

  <div class="modal-body"> 
      <div class="row">      
          <div class="col-sm-12">
              <div class="form-group">
                  {!! Form::label('label_tipo_identificacion','Tipo de Identificación '. ':*') !!}
                  {!! Form::select('tipo_ident', $tipoIdenLis,null, ['class' => 'form-control', 'required', 'id'=>'tipo_ident', 'placeholder' => __('messages.please_select')]); !!}
              </div>
          </div> 
          <div class="col-sm-12">
              <div class="form-group">
                  {!! Form::label('label_cedula_juridica','Cédula'. ':*') !!}
                  {!! Form::text('cedula_juridica', null, ['class' => 'form-control','required']); !!}                
              </div>
          </div>
          <div class="col-md-12">
              <div class="form-group">
                  {!! Form::label('first_name', __( 'business.first_name' ) . ':*') !!}
                  {!! Form::text('first_name', null, ['class' => 'form-control', 'required', 'placeholder' => __( 'business.first_name' ) ]); !!}
              </div>
          </div>
          <div class="col-md-12">
              <div class="form-group">
                  {!! Form::label('mobile','Teléfono:*') !!}
                  <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                      {!! Form::text('mobile', null, ['class' => 'form-control', 'required', 'placeholder' => __('contact.mobile')]); !!}
                  </div>
              </div>
          </div>
          <div class="col-md-12">
              <div class="form-group">
                  {!! Form::label('email', __('business.email') . ':') !!}
                  <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                      {!! Form::text('email', null, ['class' => 'form-control', 'required', 'placeholder' => 'correo1, correo2']); !!}
                  </div>
              </div>
          </div>
      </div>
    </div>

    <div class="modal-footer">
      <input type="hidden" name="type" value="customer">
      <button type="submit" class="btn btn-primary">@lang('messages.save')</button>
      <button type="button" class="btn btn-default" data-dismiss="modal">@lang('messages.close')</button>
    </div>
      
    {!! Form::close() !!}
    @include('layouts.partials.module_form_part')
  </div>
</div>
    
  
