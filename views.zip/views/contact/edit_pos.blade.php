<div class="modal-dialog" role="document">
  <div class="modal-content">
    @php
      $tipoIdenLis=isset($tipoIdenLis) ? $tipoIdenLis : [];
      if(isset($update_action)) {
          $url = $update_action;
          $customer_groups = [];
          $opening_balance = 0;
          $lead_users = $contact->leadUsers->pluck('id');
      } else {
        $url = action('ContactController@update', [$contact->id]);
        $sources = [];
        $life_stages = [];
        $users = [];
        $lead_users = [];
      }
    @endphp

    {!! Form::open(['url' => $url, 'method' => 'PUT', 'id' => 'contact_edit_form']) !!}
    
    <div class="modal-header bg-primary">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title text-white">@lang('contact.edit_contact')</h4>
    </div>

    <div class="modal-body">
      <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                {!! Form::label('label_tipo_identificacion','Tipo de Identificación '. ':*') !!}
                {!! Form::select('tipo_ident', $tipoIdenLis, $contact->tipo_ident, ['class' => 'form-control','required', 'id'=>'tipo_ident', 'placeholder' => __('messages.please_select')]); !!}
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                {!! Form::label('label_cedula_juridica','Cédula'. ':*') !!}
                {!! Form::text('cedula_juridica',$contact->cedula_juridica, ['class' => 'form-control','required']); !!}                
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                {!! Form::label('first_name', __( 'business.first_name' ) . ':*') !!}
                {!! Form::text('first_name', $contact->first_name, ['class' => 'form-control', 'required', 'placeholder' => __( 'business.first_name' ) ]); !!}
            </div>
        </div>
        <div class="col-md-12">
          <div class="form-group">
              {!! Form::label('mobile', __('contact.mobile') . ':*') !!}
              <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                  {!! Form::text('mobile', $contact->mobile, ['class' => 'form-control', 'required', 'placeholder' => __('contact.mobile')]); !!}
              </div>
          </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                {!! Form::label('email', __('business.email') . ':') !!}
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                    {!! Form::text('email', $contact->email, ['class' => 'form-control','placeholder' => __('business.email')]); !!}
                </div>
            </div>
        </div>
      </div>
    </div>

    <div class="modal-footer">
      <input type="hidden" name="contact_id" value="{{$contact->id}}">
      <button type="button" class="btn btn-primary" id="contact_edit_form_update">@lang( 'messages.update' )</button>
      <button type="button" class="btn btn-default" data-dismiss="modal">@lang( 'messages.close' )</button>
    </div>
    
    {!! Form::close() !!}
    
    <script>
      $('#contact_edit_form_update').on('click', function(e) {
        var data = $('#contact_edit_form').serialize();
        $.ajax({
          method: 'POST',
          url: $('#contact_edit_form').attr('action'),
          dataType: 'json',
          data: data,
          success: function(result) {
            if (result.success == true) {
              $('select#customer_id').append($('<option>', { value: result.data.id, text: result.data.name }));
              $('select#customer_id').val(result.data.id).trigger('change');
              
              if (typeof(contact_table) != 'undefined') contact_table.ajax.reload();
              var lead_view = urlSearchParam('lead_view');
              if (lead_view == 'kanban') {
                initializeLeadKanbanBoard();
              } else if(lead_view == 'list_view' && typeof(leads_datatable) != 'undefined') {
                leads_datatable.ajax.reload();
              }
              
              $('.contact_edit_modal').modal('hide');
              $('#clienteModal').modal('hide');
              
              toastr.success(result.msg);
            } else {
              toastr.error(result.msg);
            }
          },
        });
      });
    </script>
    
  </div>
</div>