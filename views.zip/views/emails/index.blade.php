@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Lista de Contactos</h1>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <a href="{{ route('emails.create') }}" class="btn btn-primary mb-3">Agregar Nuevo Contacto</a>
    
    <!-- Botón para enviar correos -->
    <a href="{{ route('emails.sendForm') }}" class="btn btn-success mb-3">Enviar Correos</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Teléfono</th>
                <th>Predeterminado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach($emails as $email)
            <tr>
                <td>{{ $email->nombre }}</td>
                <td>{{ $email->correo }}</td>
                <td>{{ $email->telefono }}</td>
                <td>{{ $email->es_defecto ? 'Sí' : 'No' }}</td>
                <td>
                    <a href="{{ route('emails.edit', $email->id) }}" class="btn btn-warning btn-sm">Editar</a>
                    <form action="{{ route('emails.destroy', $email->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de que quieres eliminar este contacto?');">Eliminar</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection