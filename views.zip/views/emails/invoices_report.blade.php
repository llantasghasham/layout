<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #dddddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f8f8f8;
        }
        td.right {
            text-align: right;
        }
    </style>
</head>
<body>
    <h1>Recepción de Documentos de Facturas de Compra</h1>

    <p>Estimado/a,</p>
    <p>Adjunto encontrarás el reporte de las facturas de compra recibidas para su revisión y procesamiento contable. A continuación, se muestra un resumen de las facturas incluidas:</p>

    @isset($receipts)
        <table>
            <thead>
                <tr>
                    <th>Número de Factura</th>
                    <th>Nombre del Emisor</th>
                    <th>Fecha</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($receipts as $receipt)
                    <tr>
                        <td>{{ $receipt->numerofactura }}</td>
                        <td>{{ $receipt->emisornombre }}</td>
                        <td>{{ $receipt->fecha }}</td>
                        <td class="right">₡{{ number_format($receipt->total, 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p>No hay facturas electrónicas para mostrar en este momento.</p>
    @endisset

    <p>Gracias por tu atención.</p>
    <p>Saludos cordiales,</p>
    <p>{{ config('app.name') }}</p>
</body>
</html>
