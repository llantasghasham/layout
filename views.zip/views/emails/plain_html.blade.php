@if (isset($content))
 {!! $content !!}
@endif