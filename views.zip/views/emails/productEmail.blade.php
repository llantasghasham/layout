<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>

        body {

            font-family: 'Arial', sans-serif;

            margin: 0;

            padding: 0;

            background-color: #f4f4f4;

        }

        .container {

            max-width: 600px;

            margin: 20px auto;

            background-color: #ffffff;

            padding: 20px;

            border-radius: 8px;

            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

        }

        .header {

            background-color: #007bff;

            padding: 10px;

            text-align: center;

            border-radius: 8px 8px 0 0;

        }

        .header h1 {

            color: #ffffff;

            font-size: 24px;

            margin: 0;

        }

        .content {

            margin-top: 20px;

        }

        .content p {

            font-size: 16px;

            color: #333333;

            line-height: 1.5;

        }

        .footer {

            text-align: center;

            margin-top: 30px;

            color: #777777;

            font-size: 14px;

        }

    </style>

</head>

<body>
    <p>Hola Estimado/a.<br>
        Espero que se encuentre bien.<br>

        Nos complace enviarle el detalle de nuestro producto. Adjunto encontrará la información completa que necesita para conocer mejor 
        las características de lo que ofrecemos.<br>
        
        Quedamos a su disposición para cualquier consulta o aclaración que pueda necesitar. No dude en contactarnos si requiere más información o si 
        desea el producto.<br>
        
        Gracias por su interés y esperamos poder trabajar juntos.<br>
        
        Saludos cordiales.</p>
    <b>MULTILLANTAS GHASHAM</b><br>



<b>Direcciones de Sucursales:</b><br>

Sucursal Liberia: �9�6 2666-2727<br>

<a href="https://waze.com/ul/hd1ghrztvp" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/waze.png" alt="Waze" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Waze</a>

<a href="https://goo.gl/maps/YWAvtT69hq35uSwf8" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/google-maps.png" alt="Google Maps" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Google Maps</a><br><br>



Sucursal Santa Cruz: �9�6 2680-2727<br>

<a href="https://waze.com/ul/hd1ghrztvp" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/waze.png" alt="Waze" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Waze</a>

<a href="https://goo.gl/maps/XjbQuZe82yMFQ5CA6" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/google-maps.png" alt="Google Maps" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Google Maps</a><br><br>



Sucursal Nicoya: �9�6 2685-3053<br>

<a href="https://waze.com/ul/hd1ghrztvp" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/waze.png" alt="Waze" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Waze</a>

<a href="https://goo.gl/maps/mTevEC5fUUsJVXJt5" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/google-maps.png" alt="Google Maps" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Google Maps</a><br><br>



Sucursal Upala: �9�6 2666-2727<br>

<a href="https://waze.com/ul/hd1ghrztvp" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/waze.png" alt="Waze" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Waze</a>

<a href="https://goo.gl/maps/HaQaqoZ3ZSgUgMgS7" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/google-maps.png" alt="Google Maps" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Google Maps</a><br><br>



<table width="100%" style="background-color: #f0f0f0; padding: 10px;">

    <tr>

        <td align="center" style="width: 80%;">

            <b>Siguenos en:</b><br>

            <a href="https://www.instagram.com/llantasghasham/" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/instagram-new.png" alt="Instagram" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Instagram</a>

            <a href="https://www.facebook.com/llantasghasham" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/facebook.png" alt="Facebook" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Facebook</a>

            <a href="https://twitter.com/Llantasghasham" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/twitter.png" alt="Twitter" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Twitter</a>

            <a href="https://www.linkedin.com/in/multillantas-ghasham-37420b152/" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/linkedin.png" alt="LinkedIn" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> LinkedIn</a>

            <a href="https://www.youtube.com/channel/UCe1LcNPrlmNL5jR_8qvRMGg" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/youtube-play.png" alt="YouTube" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> YouTube</a>

            <a href="https://wa.me/50688164228" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/whatsapp.png" alt="WhatsApp" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> WhatsApp</a>

            <a href="https://app.box.com/s/cobpw0daw0hadpr9omknf74rxtq6y3bp" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/box.png" alt="Box" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Box</a>

            <a href="https://llantaselpana.com/" target="_blank" style="text-decoration: none;"><img src="https://img.icons8.com/color/48/000000/domain.png" alt="Pagina Web" style="border: none; width: 30px; height: 30px; vertical-align: middle;"> Pagina Web</a>

            <br><br>

            Todos los derechos reservados 2024 �0�8 Multillantas Ghasham

        </td>

    </tr>

</table>

</body>

</html>

