@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Enviar Correos</h1>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <form method="POST" action="{{ route('emails.send') }}">
        @csrf
        <div class="mb-3">
            <label for="destinatarios" class="form-label">Seleccionar Destinatarios</label>
            <select class="form-control" id="destinatarios" name="destinatarios[]" multiple required>
                @foreach($emails as $email)
                    <option value="{{ $email->correo }}">{{ $email->nombre }} - {{ $email->correo }}</option>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Enviar Correos</button>
    </form>
</div>
@endsection
