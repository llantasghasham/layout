<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archivos Comprimidos del Voucher</title>
</head>
<body>
    <p>Estimado Cliente,</p>
    <p>Adjunto encontrarás los archivos comprimidos correspondientes al voucher solicitado.</p>
    <p>Si tienes alguna pregunta, no dudes en ponerte en contacto con nosotros.</p>
    <p>Saludos cordiales,</p>
    <p><strong>{{ config('app.name') }}</strong></p>
</body>
</html>