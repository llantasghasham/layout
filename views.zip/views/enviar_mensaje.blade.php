<!-- resources/views/enviar_mensaje.blade.php -->
@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Enviar Mensaje de WhatsApp</div>

                    <div class="card-body">
                        <form action="/enviar-mensaje-whatsapp" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="numero">Número de teléfono:</label>
                                <input type="text" name="numero" id="numero" class="form-control" placeholder="Número de teléfono">
                            </div>
                            <div class="form-group">
                                <label for="mensaje">Mensaje:</label>
                                <textarea name="mensaje" id="mensaje" class="form-control" placeholder="Mensaje"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Enviar mensaje de WhatsApp</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
