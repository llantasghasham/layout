@extends('layouts.app-config')

@section('content')
<div class="container-fluid px-4 py-5">
    <!-- Título Principal y Controles -->
    <div class="d-flex flex-wrap align-items-center justify-content-between mb-4 gap-3">
        <div class="d-flex justify-content-center align-items-center w-100 w-md-auto">
            <h1 class="display-4 fw-bold text-primary m-0 text-center" style="background: linear-gradient(45deg, #4b6cb7, #182848); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-weight: 900;">
                Facturas Recibidas
            </h1>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-3">
            <div class="input-group" style="max-width: 300px;">
                <input type="text" class="form-control border-0 shadow-sm" id="searchInput" placeholder="Buscar facturas..." onkeyup="buscarEnTabla()">
            </div>
            <div class="d-flex align-items-center">
                <label class="me-2 text-muted fw-bold">Mostrar:</label>
                <select id="itemsPerPage" class="form-select shadow-sm border-0 bg-light" style="max-width: 300px;" onchange="updatePagination()">
                    <option value="25" selected>25</option>
                    <option value="50">50</option>
                    <option value="75">75</option>
                    <option value="100">100</option>
                    <option value="150">150</option>
                    <option value="all">Todo</option>
                </select>
            </div>
            <button id="importar-correos" class="btn btn-primary shadow-sm" style="max-width: 300px;">
                <i class="fas fa-download me-2"></i>Importar Correos
            </button>
        </div>
    </div>

    <!-- Mensajes Toastr -->
    @if(session('success'))
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                toastr.success(@json(session('success')));
            });
        </script>
    @endif
    @if(session('error'))
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                toastr.error(@json(session('error')));
            });
        </script>
    @endif

    <!-- Tabla Modernizada -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive" style="max-height: 75vh;">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark sticky-top" style="background: linear-gradient(45deg, #4b6cb7, #182848); top: 0; z-index: 10;">
                        <tr>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">ID</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Emisor</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Receptor</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Archivo PDF Nombre</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Archivo XML Nombre</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Fecha de Recepción</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Archivo PDF</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Archivo XML</th>
                            <th class="text-center fw-bold" style="font-size: 1.25rem;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="tablaDatos">
                        @forelse($facturas->reverse() as $factura)
                            <tr class="factura-row {{ $loop->even ? 'bg-soft-blue' : 'bg-soft-purple' }}">
                                <td>{{ $factura->id }}</td>
                                <td>{{ $factura->emisor }}</td>
                                <td>{{ $factura->receptor }}</td>
                                <td>{{ $factura->nombre_archivo_pdf }}</td>
                                <td>{{ $factura->nombre_archivo_xml }}</td>
                                <td>{{ $factura->recibido_en }}</td>
                                <td>
                                    @if($factura->nombre_archivo_pdf != "No")
                                        <a href="{{ route('facturas-recibidas.downloadPDF', $factura->id) }}" class="btn btn-sm btn-primary shadow-sm">
                                            <i style="font-size:16px" class="fa"></i>
                                        </a>
                                    @else
                                        No disponible
                                    @endif
                                </td>
                                <td>
                                    @if($factura->nombre_archivo_xml != "No" && $factura->nombre_archivo_xml != "Procesado")
                                        <a href="{{ route('facturas-recibidas.downloadXML', $factura->id) }}" class="btn btn-sm btn-primary shadow-sm">
                                            <i style="font-size:16px" class="fa"></i>
                                        </a>
                                    @else
                                        No disponible
                                    @endif
                                </td>
                                @if($factura->nombre_archivo_xml != "No" && $factura->nombre_archivo_xml != "Procesado")
                                    <td style="display: flex; justify-content: space-between; align-items: center;">
                                        <form action="{{ route('facturas-recibidas.process', $factura->id) }}" method="POST" class="process-form">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-success shadow-sm"><i style="font-size:16px" class="fa"></i></button>
                                        </form>
                                @else
                                    <td style="display: flex; justify-content: center; align-items: center;">
                                @endif
                                    <form action="{{ route('facturas-recibidas.destroy', $factura->id) }}" method="POST" class="delete-form">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-danger shadow-sm"><i style="font-size:16px" class="fa"></i></button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="12" class="text-center">No se han recibido facturas.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer py-2" id="pagination-container"></div>
    </div>
</div>

<!-- Modal para importar correos (CÓDIGO ORIGINAL) -->
<div class="modal fade" id="modal-importar-correos" tabindex="-1" aria-labelledby="modal-importar-correos-label">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-importar-correos-label">Seleccionar Correo para Importar Facturas</h5>
            </div>
            <div class="modal-body">
                <div id="lista-correos" class="text-center">
                    <i class="fas fa-spinner fa-spin"></i> Cargando correos configurados...
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary">Cerrar</button>
                <button id="confirmar-importacion" type="button" class="btn btn-primary">Importar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal de Confirmación Personalizado -->
<div class="modal fade" id="confirmationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg border-0 rounded-3">
            <div class="modal-body text-center p-4">
                <p id="confirmationMessage" class="mb-4 fs-5"></p>
                <div class="d-flex justify-content-center gap-3">
                    <button id="confirmButton" class="btn btn-primary px-4 py-2 rounded-pill">Aceptar</button>
                    <button id="cancelButton" class="btn btn-outline-secondary px-4 py-2 rounded-pill" data-bs-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    :root {
        --primary-gradient: linear-gradient(45deg, #4b6cb7, #182848);
        --soft-blue: #e8f0fe;
        --soft-purple: #f3e8ff;
        --text-primary: #182848;
        --text-muted: #6c757d;
        --border-radius: 0.5rem;
    }

    #main-container {
        max-width: 1400px;
        margin: 0 auto;
    }

    .title-gradient {
        background: var(--primary-gradient);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 900;
    }

    .controls-group {
        gap: 1rem;
    }

    .card {
        border: none;
        border-radius: var(--border-radius);
        overflow: hidden;
    }

    .table {
        margin-bottom: 0;
    }

    .table-hover tbody tr:hover {
        background-color: #f0f2f5;
        transition: background-color 0.3s ease;
    }

    .table-dark th {
        color: #fff;
        font-weight: 700;
        background: var(--primary-gradient);
    }

    .bg-soft-blue {
        background-color: var(--soft-blue);
    }

    .bg-soft-purple {
        background-color: var(--soft-purple);
    }

    .btn {
        transition: all 0.3s ease;
    }

    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .btn-primary {
        background: var(--primary-gradient);
        border: none;
    }

    .btn-primary:hover {
        background: linear-gradient(45deg, #182848, #4b6cb7);
    }

    .btn-success, .btn-danger {
        padding: 0.25rem 0.5rem;
    }

    .pagination {
        margin: 0;
    }

    .pagination .page-item.active .page-link {
        background-color: #4b6cb7;
        border-color: #4b6cb7;
        color: #fff;
    }

    .pagination .page-link {
        color: #4b6cb7;
        border: none;
        transition: all 0.3s ease;
    }

    .pagination .page-link:hover {
        background-color: var(--soft-blue);
        color: var(--text-primary);
    }

    #pagination-container {
        padding: 0.5rem 0;
        background: #fff;
    }

    .modal-content {
        border-radius: var(--border-radius);
    }

    .import-spinner {
        margin-right: 0.5rem;
    }

    @media (max-width: 768px) {
        .controls-group {
            flex-direction: column;
            align-items: stretch;
            width: 100%;
        }
        .input-group, #itemsPerPage, #importar-correos {
            max-width: 100% !important;
            margin-bottom: 1rem;
        }
        .title-gradient {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
        }
        .table-responsive {
            max-height: 60vh;
        }
    }

    @media (max-width: 576px) {
        .title-gradient {
            font-size: 2rem;
        }
        .table th, .table td {
            font-size: 0.875rem;
        }
        .btn {
            font-size: 0.875rem;
        }
    }

    @media (min-width: 1200px) {
        #main-container {
            padding-left: 2rem;
            padding-right: 2rem;
        }
    }
</style>

<script>
let currentPage = 1;
let allRows = document.querySelectorAll('.factura-row');
let filteredRows = Array.from(allRows);

// Modal de Confirmación
let confirmationModal;
try {
    confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));
} catch (e) {
    console.warn("Bootstrap Modal no está disponible. Usando confirmación nativa.");
}

const confirmationMessage = document.getElementById('confirmationMessage');
const confirmButton = document.getElementById('confirmButton');
const cancelButton = document.getElementById('cancelButton');

function showConfirmationModal(message, callback) {
    if (confirmationModal) {
        confirmationMessage.textContent = message;
        confirmButton.onclick = () => {
            callback();
            confirmationModal.hide();
        };
        confirmationModal.show();
    } else {
        if (confirm(message)) {
            callback();
        }
    }
}

// Manejo de formularios con confirmación
document.querySelectorAll('.process-form').forEach(form => {
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        showConfirmationModal('¿Estás seguro de querer procesar esta factura?', () => {
            form.submit();
        });
    });
});

document.querySelectorAll('.delete-form').forEach(form => {
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        showConfirmationModal('¿Estás seguro de eliminar esta factura?', () => {
            form.submit();
        });
    });
});

function updatePagination() {
    const itemsPerPage = document.getElementById('itemsPerPage').value || 25;
    const rows = filteredRows;
    const totalItems = rows.length;
    const totalPages = itemsPerPage === 'all' ? 1 : Math.ceil(totalItems / itemsPerPage);

    if (currentPage > totalPages) {
        currentPage = totalPages || 1;
    }

    rows.forEach((row, index) => {
        if (itemsPerPage === 'all') {
            row.style.display = '';
        } else {
            const start = (currentPage - 1) * itemsPerPage;
            const end = start + parseInt(itemsPerPage);
            row.style.display = (index >= start && index < end) ? '' : 'none';
        }
    });

    let paginationHTML = '<nav aria-label="Page navigation"><ul class="pagination justify-content-end mb-0">';
    if (totalPages > 1) {
        paginationHTML += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changePage(${currentPage - 1}); return false;">Anterior</a></li>`;
        
        for (let i = 1; i <= totalPages; i++) {
            paginationHTML += `<li class="page-item ${currentPage === i ? 'active' : ''}">
                <a class="page-link" href="#" onclick="changePage(${i}); return false;">${i}</a></li>`;
        }
        
        paginationHTML += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changePage(${currentPage + 1}); return false;">Siguiente</a></li>`;
    }
    paginationHTML += '</ul></nav>';
    document.getElementById('pagination-container').innerHTML = paginationHTML;
}

function changePage(page) {
    const totalPages = Math.ceil(filteredRows.length / (document.getElementById('itemsPerPage').value === 'all' ? filteredRows.length : document.getElementById('itemsPerPage').value));
    if (page >= 1 && page <= totalPages) {
        currentPage = page;
        updatePagination();
    }
}

function buscarEnTabla() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let table = document.getElementById("tablaDatos");
    let rows = table.getElementsByTagName("tr");
    
    filteredRows = [];
    for (let i = 0; i < rows.length; i++) {
        let cells = rows[i].getElementsByTagName("td");
        let found = false;
        
        for (let j = 0; j < cells.length; j++) {
            if (cells[j].innerText.toLowerCase().includes(input)) {
                found = true;
                break;
            }
        }
        
        if (found) {
            filteredRows.push(rows[i]);
            rows[i].style.display = '';
        } else {
            rows[i].style.display = 'none';
        }
    }
    currentPage = 1;
    updatePagination();
}

// Código original para el manejo del modal de importar correos
document.getElementById('importar-correos').addEventListener('click', function () {
    const modal = document.getElementById('modal-importar-correos');
    modal.classList.add('in');
    modal.style.display = 'block';
    document.body.classList.add('modal-open');

    fetch('{{ route('facturas-recibidas.importarCorreos') }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
    })
    .then(response => response.json())
    .then(data => {
        console.log('Respuesta de importarCorreos:', data); // Depuración
        if (data.success) {
            let lista = '<ul class="list-group">';
            data.data.forEach((correo, index) => {
                lista += `
                    <li class="list-group-item">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="correoSeleccionado" id="correo${index}" value="${correo.correo}">
                            <label class="form-check-label" for="correo${index}">
                                ${correo.correo}
                            </label>
                        </div>
                    </li>`;
            });
            lista += '</ul>';
            document.getElementById('lista-correos').innerHTML = lista;
        } else {
            document.getElementById('lista-correos').innerHTML = `<p class="text-danger">${data.message}</p>`;
        }
    })
    .catch(error => {
        console.error('Error al cargar correos:', error);
        document.getElementById('lista-correos').innerHTML = `<p class="text-danger">Error al cargar los correos configurados.</p>`;
    });
});

// Evento para cerrar el modal
document.querySelectorAll('#modal-importar-correos .btn-close, #modal-importar-correos .btn-secondary').forEach(btn => {
    btn.addEventListener('click', function () {
        const modal = document.getElementById('modal-importar-correos');
        modal.classList.remove('show');
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
    });
});

// Cerrar el modal al hacer clic fuera de él
window.addEventListener('click', function (event) {
    const modal = document.getElementById('modal-importar-correos');
    if (event.target === modal) {
        modal.classList.remove('show');
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
    }
});

// Evento para confirmar la importación
document.getElementById('confirmar-importacion').addEventListener('click', function () {
    const correoSeleccionado = document.querySelector('input[name="correoSeleccionado"]:checked');

    if (correoSeleccionado) {
        const correo = correoSeleccionado.value;
        
        fetch('{{ route('facturas-recibidas.importarFacturas') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ correoSeleccionado: correo })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Respuesta de importarFacturas:', data); // Depuración
            if (data.success) {
                if (data.facturas && Array.isArray(data.facturas)) {
                    actualizarTabla(data.facturas); // Actualizar tabla dinámicamente
                }
                sessionStorage.setItem('importacionExitosa', `Facturas importadas correctamente desde: ${correo}`);
                setTimeout(() => {
                    location.reload(true); // Forzar recarga completa
                }, 500);
            } else {
                toastr.error(`Error: ${data.message || 'No se pudieron importar las facturas.'}`);
            }
        })
        .catch(error => {
            console.error('Error al importar las facturas:', error);
            toastr.error("Ocurrió un error al importar las facturas.");
        });

        const modal = document.getElementById('modal-importar-correos');
        modal.classList.remove('show');
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
    } else {
        toastr.warning("Por favor, selecciona un correo para importar.");
    }
});

// Función para actualizar la tabla dinámicamente
function actualizarTabla(nuevasFacturas) {
    const tablaDatos = document.getElementById('tablaDatos');
    nuevasFacturas.forEach(factura => {
        const fila = document.createElement('tr');
        fila.className = 'factura-row ' + (allRows.length % 2 === 0 ? 'bg-soft-blue' : 'bg-soft-purple');
        fila.innerHTML = `
            <td>${factura.id || allRows.length + 1}</td>
            <td>${factura.emisor || ''}</td>
            <td>${factura.receptor || ''}</td>
            <td>${factura.nombre_archivo_pdf || 'No'}</td>
            <td>${factura.nombre_archivo_xml || 'No'}</td>
            <td>${factura.recibido_en || new Date().toLocaleString()}</td>
            <td>${factura.nombre_archivo_pdf !== 'No' ? '<a href="#" class="btn btn-sm btn-primary"><i style="font-size:16px" class="fa"></i></a>' : 'No disponible'}</td>
            <td>${factura.nombre_archivo_xml !== 'No' ? '<a href="#" class="btn btn-sm btn-primary"><i style="font-size:16px" class="fa"></i></a>' : 'No disponible'}</td>
            <td style="display: flex; justify-content: center; align-items: center;">
                <form action="{{ route('facturas-recibidas.destroy', ':id') }}" method="POST" class="delete-form" onsubmit="event.preventDefault(); showConfirmationModal('¿Estás seguro de eliminar esta factura?', () => this.submit());">
                    @csrf
                    <button type="submit" class="btn btn-sm btn-danger"><i style="font-size:16px" class="fa"></i></button>
                </form>
            </td>
        `;
        tablaDatos.appendChild(fila);
    });
    allRows = document.querySelectorAll('.factura-row');
    filteredRows = Array.from(allRows);
    updatePagination();
}

// Al cargar la página, mostrar el mensaje si existe en sessionStorage
window.addEventListener('DOMContentLoaded', () => {
    updatePagination();

    const mensaje = sessionStorage.getItem('importacionExitosa');
    if (mensaje) {
        toastr.success(mensaje);
        sessionStorage.removeItem('importacionExitosa');
    }
});
</script>
@endsection