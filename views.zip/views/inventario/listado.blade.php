@extends('layouts.app')
@section('title', __('sale.products'))
@section('content')

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>@lang('sale.products')
        <small>@lang('lang_v1.manage_products')</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            @component('components.filters', ['title' => __('report.filters')])
                <!-- Filters -->
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('type', __('product.product_type') . ':') !!}
                        {!! Form::select('type', ['single' => __('lang_v1.single'), 'variable' => __('lang_v1.variable'), 'combo' => __('lang_v1.combo')], null, ['class' => 'form-control select2', 'id' => 'product_list_filter_type', 'placeholder' => __('lang_v1.all')]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('unit_id', __('product.unit') . ':') !!}
                        {!! Form::select('unit_id', $units, null, ['class' => 'form-control select2', 'id' => 'product_list_filter_unit_id', 'placeholder' => __('lang_v1.all')]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('tax_id', __('product.tax') . ':') !!}
                        {!! Form::select('tax_id', $taxes, null, ['class' => 'form-control select2', 'id' => 'product_list_filter_tax_id', 'placeholder' => __('lang_v1.all')]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('brand_id', __('product.brand') . ':') !!}
                        {!! Form::select('brand_id', $brands, null, ['class' => 'form-control select2', 'id' => 'product_list_filter_brand_id', 'placeholder' => __('lang_v1.all')]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('location_id', __('purchase.business_location') . ':') !!}
                        {!! Form::select('location_id', $business_locations, null, ['class' => 'form-control select2', 'id' => 'product_list_filter_location_id', 'placeholder' => __('lang_v1.all')]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::select('active_state', ['active' => __('business.is_active'), 'inactive' => __('lang_v1.inactive')], null, ['class' => 'form-control select2', 'id' => 'active_state', 'placeholder' => __('lang_v1.all')]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>
                            {!! Form::checkbox('not_for_selling', 1, false, ['class' => 'input-icheck', 'id' => 'not_for_selling']) !!} <strong>@lang('lang_v1.not_for_selling')</strong>
                        </label>
                    </div>
                </div>
            @endcomponent
        </div>
    </div>
    @can('product.view')
        <div class="row">
            <div class="col-md-12">
                <!-- Custom Tabs -->
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="#product_list_tab" data-toggle="tab" aria-expanded="true">
                                <i class="fa fa-cubes" aria-hidden="true"></i> @lang('lang_v1.all_products')
                            </a>
                        </li>
                        <li>
                            <a href="#product_stock_detail" data-toggle="tab" aria-expanded="true">
                                <i class="fa fa-list" aria-hidden="true"></i> Detalles de Stock
                            </a>
                        </li>
                        @can('stock_report.view')
                        <li>
                            <a href="#product_list_suc_tab" data-toggle="tab" aria-expanded="true">
                                <i class="fa fa-cubes" aria-hidden="true"></i> @lang('report.stock_report_sucursales')
                            </a>
                        </li>
                        <li> 
                            <a href="#product_stock_report" data-toggle="tab" aria-expanded="true">
                                <i class="fa fa-hourglass-half" aria-hidden="true"></i> @lang('report.stock_report')
                            </a>
                        </li>
                        @endcan
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="product_list_tab">
                            @can('product.create')
                                <a class="btn btn-primary pull-right" href="{{action('ProductController@create')}}">
                                    <i class="fa fa-plus"></i> @lang('messages.add')
                                </a>
                                <br><br>
                            @endcan
                            @include('product.partials.product_list')
                        </div>

                        <div class="tab-pane" id="product_stock_detail">
                            <table id="product_stock_detail_table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>@lang('product.sku')</th>
                                        <th>@lang('product.description')</th>
                                        <th>@lang('product.selling_price')</th>
                                        <th>Liberia</th>
                                        <th>Santa Cruz</th>
                                        <th>Nicoya</th>
                                        <th>Upala</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>

                        @can('stock_report.view')
                        <div class="tab-pane" id="product_list_suc_tab">
                            @can('product.create')
                                <a class="btn btn-primary pull-right" href="{{action('ProductController@create')}}">
                                    <i class="fa fa-plus"></i> @lang('messages.add')
                                </a>
                                <br><br>
                            @endcan
                            @include('product.partials.product_list_sucursales')
                        </div> 
                        <div class="tab-pane" id="product_stock_report">
                            @include('report.partials.stock_report_table')
                        </div>
                        @endcan
                    </div>
                </div>
            </div>
        </div>
    @endcan
    <input type="hidden" id="is_rack_enabled" value="{{$rack_enabled ?? ''}}">

    <div class="modal fade product_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>
    <div class="modal fade" id="view_product_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>
    <div class="modal fade" id="opening_stock_modal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel"></div>

</section>
<!-- /.content -->

@endsection

@section('javascript')
    <script src="{{ asset('js/product.js?v=' . $asset_v) }}"></script>
    <script src="{{ asset('js/opening_stock.js?v=' . $asset_v) }}"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            // Configuración de la tabla de productos
            product_table = $('#product_table').DataTable({
                processing: true,
                serverSide: true,
                aaSorting: [[3, 'asc']],
                scrollY: "75vh",
                scrollX: true,
                scrollCollapse: true,
                "ajax": {
                    "url": "/products",
                    "data": function ( d ) {
                        d.location_id = $('#product_list_filter_location_id').val() || '';
                        d.type = $('#product_list_filter_type').val();
                        d.brand_id = $('#product_list_filter_brand_id').val();
                        d.unit_id = $('#product_list_filter_unit_id').val();
                        d.tax_id = $('#product_list_filter_tax_id').val();
                        d.active_state = $('#active_state').val();
                        d.not_for_selling = $('#not_for_selling').is(':checked');
                        if ($('#repair_model_id').length == 1) d.repair_model_id = $('#repair_model_id').val();
                        d = __datatable_ajax_callback(d);
                    }
                },
                columnDefs: [ {
                    "targets": [0, 1, 2],
                    "orderable": false
                }],
                columns: [
                    { data: 'mass_delete'  },
                    { data: 'image', name: 'products.image'  },
                    { data: 'action', name: 'action'},
                    { data: 'product', name: 'products.name'  },
                    { data: 'product_locations', name: 'product_locations'  },
                    @can('view_purchase_price')
                        { data: 'purchase_price', name: 'max_purchase_price', searchable: false},
                    @endcan
                    @can('access_default_selling_price')
                        { data: 'selling_price', name: 'max_price', searchable: false},
                    @endcan
                    { data: 'current_stock', searchable: false},
                    { data: 'type', name: 'products.type'},
                    { data: 'category', name: 'c1.name'},
                    { data: 'brand', name: 'brands.name'},
                    { data: 'tax', name: 'tax_rates.name', searchable: false},
                    { data: 'sku', name: 'products.sku'},
                    { data: 'product_custom_field1', name: 'products.product_custom_field1'  },
                    { data: 'product_custom_field2', name: 'products.product_custom_field2'  },
                    { data: 'product_custom_field3', name: 'products.product_custom_field3'  },
                    { data: 'product_custom_field4', name: 'products.product_custom_field4'  }
                ],
                createdRow: function( row, data, dataIndex ) {
                    if($('#is_rack_enabled').val() == 1){
                        var target_col = 0;
                        @can('product.delete')
                            target_col = 1;
                        @endcan
                        $( row ).find('td:eq('+target_col+') div').prepend('<i style="margin:auto;" class="fa fa-plus-circle text-success cursor-pointer no-print rack-details" title="' + LANG.details + '"></i>&nbsp;&nbsp;');
                    }
                    $( row ).find('td:eq(0)').attr('class', 'selectable_td');
                },
                fnDrawCallback: function(oSettings) {
                    __currency_convert_recursively($('#product_table'));
                },
            });

            // Configuración de la tabla de detalles de stock
            var product_stock_detail_table = $('#product_stock_detail_table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route("products.stock_with_details") }}',
                    data: function(d) {
                        d.location_id = $('#product_list_filter_location_id').val();
                        d.type = $('#product_list_filter_type').val();
                        d.brand_id = $('#product_list_filter_brand_id').val();
                        d.unit_id = $('#product_list_filter_unit_id').val();
                        d.tax_id = $('#product_list_filter_tax_id').val();
                        d.active_state = $('#active_state').val();
                        d.not_for_selling = $('#not_for_selling').is(':checked');
                    }
                },
                columns: [
                    { data: 'sku', name: 'products.sku' },
                    { data: 'description', name: 'products.description' },
                    { data: 'selling_price', name: 'products.selling_price' },
                    { data: 'liberia_stock', name: 'liberia_stock' },
                    { data: 'santa_cruz_stock', name: 'santa_cruz_stock' },
                    { data: 'nicoya_stock', name: 'nicoya_stock' },
                    { data: 'upala_stock', name: 'upala_stock' }
                ],
                searchDelay: 500,
                dom: 'Bfrtip',
                buttons: ['excel', 'pdf', 'print'],
                order: [[1, 'asc']],
                pageLength: 25,
                drawCallback: function(settings) {
                    __currency_convert_recursively($('#product_stock_detail_table'));
                }
            });

            // Configuración para la pestaña de sucursales
            product_table_suc = $('#product_table_suc').DataTable({
                processing: true,
                serverSide: true,
                aaSorting: [[3, 'asc']],
                scrollY: "75vh",
                scrollX: true,
                scrollCollapse: true,
                "ajax": {
                    "url": "/products/sucursales",
                    "data": function ( d ) {
                        d.location_id = $('#product_list_filter_location_id').val() || ''; 
                        d.type = $('#product_list_filter_type').val();
                        d.brand_id = $('#product_list_filter_brand_id').val();
                        d.unit_id = $('#product_list_filter_unit_id').val();
                        d.tax_id = $('#product_list_filter_tax_id').val();
                        d.active_state = $('#active_state').val();
                        d.not_for_selling = $('#not_for_selling').is(':checked');
                        if ($('#repair_model_id').length == 1) d.repair_model_id = $('#repair_model_id').val();
                        d = __datatable_ajax_callback(d);
                    }
                },
                columnDefs: [ {
                    "targets": [0, 1, 2],
                    "orderable": false
                } ],
                columns: [
                    { data: 'action', name: 'action' }, 
                    { data: 'sku', name: 'products.sku' }, 
                    { data: 'name', name: 'products.name' }, 
                    { data: 'purchase_price', name: 'max_purchase_price', searchable: false }, 
                    { data: 'selling_price', name: 'max_price', searchable: false }, 
                    { data: 'current_stock', searchable: false }, 
                    { data: 'liberia', name: 'liberia', searchable: false }, 
                    { data: 'santa_cruz', name: 'santa_cruz', searchable: false }, 
                    { data: 'nicoya', name: 'nicoya', searchable: false }, 
                    { data: 'upala', name: 'upala', searchable: false } 
                ],
                createdRow: function( row, data, dataIndex ) {
                    if($('#is_rack_enabled').val() == 1){
                        var target_col = 0;
                        @can('product.delete')
                            target_col = 1;
                        @endcan
                        $( row ).find('td:eq('+target_col+') div').prepend('<i style="margin:auto;" class="fa fa-plus-circle text-success cursor-pointer no-print rack-details" title="' + LANG.details + '"></i>&nbsp;&nbsp;');
                    }
                    $( row ).find('td:eq(0)').attr('class', 'selectable_td');
                },
                fnDrawCallback: function(oSettings) {
                    __currency_convert_recursively($('#product_table_suc'));
                },
            });

            // Configuración para la pestaña de informe de stock
            var stock_report_table_suc = $('#stock_report_table_suc').DataTable({
                processing: true,
                serverSide: true,
                aaSorting: [[3, 'asc']],
                scrollY: "75vh",
                scrollX: true,
                scrollCollapse: true,
                "ajax": {
                    "url": "/stock-reports",
                    "data": function ( d ) {
                        d.location_id = $('#product_list_filter_location_id').val() || ''; 
                        d.type = $('#product_list_filter_type').val();
                        d.brand_id = $('#product_list_filter_brand_id').val();
                        d.unit_id = $('#product_list_filter_unit_id').val();
                        d.tax_id = $('#product_list_filter_tax_id').val();
                        d.active_state = $('#active_state').val();
                        d.not_for_selling = $('#not_for_selling').is(':checked');
                        if ($('#repair_model_id').length == 1) d.repair_model_id = $('#repair_model_id').val();
                        d = __datatable_ajax_callback(d);
                    }
                },
                columnDefs: [ {
                    "targets": [0, 1, 2],
                    "orderable": false
                } ],
            });

            // Handlers de eventos para actualizar tablas en tiempo real
            $('#product_list_filter_location_id').change(function() {
                product_stock_detail_table.ajax.reload();
            });

            $('#product_list_filter_type, #product_list_filter_brand_id, #product_list_filter_unit_id, #product_list_filter_tax_id, #active_state, #not_for_selling').change(function() {
                product_stock_detail_table.ajax.reload();
            });

            // Gestión de filas de detalle en tablas
            var detailRows = [];

            $('#product_table tbody').on('click', 'tr i.rack-details', function () {
                var i = $(this);
                var tr = $(this).closest('tr');
                var row = product_table.row(tr);
                var idx = $.inArray(tr.attr('id'), detailRows);

                if ( row.child.isShown() ) {
                    i.addClass('fa-plus-circle text-success');
                    i.removeClass('fa-minus-circle text-danger');
                    row.child.hide();
                    detailRows.splice(idx, 1);
                } else {
                    i.removeClass('fa-plus-circle text-success');
                    i.addClass('fa-minus-circle text-danger');
                    row.child(get_product_details(row.data())).show();
                    if (idx === -1) {
                        detailRows.push(tr.attr('id'));
                    }
                }
            });

            // Eventos para eliminación masiva y activación/desactivación
            $(document).on('click', '#delete-selected', function(e){
                e.preventDefault();
                var selected_rows = getSelectedRows();
                if(selected_rows.length > 0){
                    $('input#selected_rows').val(selected_rows);
                    swal({
                        title: LANG.sure,
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    }).then((willDelete) => {
                        if (willDelete) {
                            $('form#mass_delete_form').submit();
                        }
                    });
                } else{
                    $('input#selected_rows').val('');
                    swal('@lang("lang_v1.no_row_selected")');
                }    
            });

            $(document).on('click', '#deactivate-selected', function(e){
                e.preventDefault();
                var selected_rows = getSelectedRows();
                if(selected_rows.length > 0){
                    $('input#selected_products').val(selected_rows);
                    swal({
                        title: LANG.sure,
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    }).then((willDelete) => {
                        if (willDelete) {
                            var form = $('form#mass_deactivate_form');
                            var data = form.serialize();
                            $.ajax({
                                method: form.attr('method'),
                                url: form.attr('action'),
                                dataType: 'json',
                                data: data,
                                success: function(result) {
                                    if (result.success == true) {
                                        toastr.success(result.msg);
                                        product_table.ajax.reload();
                                        form.find('#selected_products').val('');
                                    } else {
                                        toastr.error(result.msg);
                                    }
                                },
                            });
                        }
                    });
                } else{
                    $('input#selected_products').val('');
                    swal('@lang("lang_v1.no_row_selected")');
                }    
            });

            $(document).on('click', '#edit-selected', function(e){
                e.preventDefault();
                var selected_rows = getSelectedRows();
                if(selected_rows.length > 0){
                    $('input#selected_products_for_edit').val(selected_rows);
                    $('form#bulk_edit_form').submit();
                } else{
                    $('input#selected_products').val('');
                    swal('@lang("lang_v1.no_row_selected")');
                }    
            });

            $('table#product_table tbody').on('click', 'a.activate-product', function(e){
                e.preventDefault();
                var href = $(this).attr('href');
                $.ajax({
                    method: "get",
                    url: href,
                    dataType: "json",
                    success: function(result){
                        if(result.success == true){
                            toastr.success(result.msg);
                            product_table.ajax.reload();
                        } else {
                            toastr.error(result.msg);
                        }
                    }
                });
            });

            $(document).on('ifChanged', '#not_for_selling', function(){
                if ($("#product_list_tab").hasClass('active')) product_table.ajax.reload();
                if ($("#product_list_suc_tab").hasClass('active')) product_table_suc.ajax.reload();
                if ($("#product_stock_report").hasClass('active')) stock_report_table_suc.ajax.reload();
            });

            $('#product_location').select2({dropdownParent: $('#product_location').closest('.modal')});
        });

        $(document).on('shown.bs.modal', 'div.view_product_modal, div.view_modal', function(){
            var div = $(this).find('#view_product_stock_details');
            if (div.length) {
                $.ajax({
                    url: "{{action('ReportController@getStockReport')}}"  + '?for=view_product&product_id=' + div.data('product_id'),
                    dataType: 'html',
                    success: function(result) {
                        div.html(result);
                        __currency_convert_recursively(div);
                    },
                });
            }
            __currency_convert_recursively($(this));
        });

    </script>
@endsection
