<table class="table table-bordered table-striped" id="product_table_suc">
    <thead>
        <tr>
            <th>@lang('messages.action')</th>
            <th>@lang('product.sku')</th>
            <th>@lang('product.product')</th>
            <th>@lang('product.purchase_price')</th>
            <th>@lang('product.selling_price')</th>
            <th>@lang('report.current_stock')</th>
            @foreach($business_locations as $location)
                <th>{{ $location }}</th>
            @endforeach
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>

<script type="text/javascript">
    $(document).ready(function() {
        var product_table_suc = $('#product_table_suc').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route("products.sucursales") }}',
                data: function(d) {
                    d.location_id = $('#product_list_filter_location_id').val() || ''; 
                    d.type = $('#product_list_filter_type').val();
                    d.brand_id = $('#product_list_filter_brand_id').val();
                    d.unit_id = $('#product_list_filter_unit_id').val();
                    d.tax_id = $('#product_list_filter_tax_id').val();
                    d.active_state = $('#active_state').val();
                    d.not_for_selling = $('#not_for_selling').is(':checked');
                    if ($('#repair_model_id').length == 1) d.repair_model_id = $('#repair_model_id').val();

                    d = __datatable_ajax_callback(d);
                }
            },
            columns: [
                { data: 'action', name: 'action' },
                { data: 'sku', name: 'products.sku' },
                { data: 'name', name: 'products.name' },
                { data: 'purchase_price', name: 'max_purchase_price', searchable: false },
                { data: 'selling_price', name: 'max_price', searchable: false },
                { data: 'current_stock', searchable: false },
                @foreach($business_locations as $location)
                    { data: '{{ strtolower($location) }}', searchable: false },
                @endforeach
            ],
            createdRow: function(row, data, dataIndex) {
                if ($('#is_rack_enabled').val() == 1) {
                    var target_col = 0;
                    @can('product.delete')
                        target_col = 1;
                    @endcan
                    $(row).find('td:eq(' + target_col + ') div').prepend('<i style="margin:auto;" class="fa fa-plus-circle text-success cursor-pointer no-print rack-details" title="' + LANG.details + '"></i>&nbsp;&nbsp;');
                }
                $(row).find('td:eq(0)').attr('class', 'selectable_td');
            },
            fnDrawCallback: function(oSettings) {
                __currency_convert_recursively($('#product_table_suc'));
            },
        });

        $('#product_list_filter_location_id').change(function() {
            product_table_suc.ajax.reload();
        });
    });
</script>
