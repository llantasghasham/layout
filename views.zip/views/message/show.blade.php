<!DOCTYPE html>
<html>
<head>
    <title>Message</title>
</head>
<body>
    <h1>Message {{ $message->id }}</h1>
</body>
</html>
@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Message Details</h1>
        <p>Message ID: {{ $message->id }}</p>
        <p>Content: {{ $message->content }}</p>
        <p>User: {{ $message->user->name }}</p>
        <p>Chat: {{ $message->chat->name }}</p>
    </div>
@endsection
