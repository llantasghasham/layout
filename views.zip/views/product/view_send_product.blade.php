<div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
		<div class="modal-header">
		    <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		    <h4 class="modal-title" id="modalTitle">ENVIAR PRODUCTO POR CORREO Y WHATSAPP</h4>
	    </div>
        <div class="modal-body">
            <!-- FORMULARIOS -->
            <div class="card mb-4 shadow-sm">
                <!-- ENVIO POR CORREO-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="emailForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="emails">{{ __('Correo(s) del Cliente') }}:</label>
                                <input type="text" id="emails" name="emails" class="form-control" placeholder="correo1@example.com, correo2@example.com">
                            </div>
                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-primary w-100" onclick="enviarPDFEmail()">{{ __('Enviar Correo') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- ENVIO POR WHATSAPP-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="whatsappForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="phone">{{ __('Numero de Telefono') }}:</label>
                                <input type="text" id="phone" name="phone" class="form-control" placeholder="51 999999999">
                            </div>

                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-success w-100" onclick="enviarPDFWhatsApp()">{{ __('Enviar WhatsApp') }}</button>
                            </div>
                        </div>
                    </form>
                </div> 
                <!-- EDITAR ENVIO-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    @foreach($product->variations as $variation)
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 35%; padding-right: 15px;">
                                <label for="editprecioNormal">Precio Normal</label>
                                <input type="text" id="editprecioNormal" class="form-control" name="editprecioNormal" placeholder="{{ $variation->sell_price_inc_tax }}"
                                    value="{{ $variation->sell_price_inc_tax }}">
                            </div>
                            <div style="width: 35%;">
                                <label for="editprecioMayoreo">Precio Mayoreo</label>
                                @if(!empty($allowed_group_prices))
                                    @foreach($allowed_group_prices as $key => $value)
                                    <input type="text" id="editprecioMayoreo" class="form-control" name="editprecioMayoreo" 
                                    value="{{ $group_price_details[$variation->id][$key] ?? '00.00' }}" placeholder="{{ $group_price_details[$variation->id][$key] ?? '00.00' }}">
                                    @endforeach
                                @endif
                            </div>
                        </div>
                    @endforeach
                    <div style="display: flex; justify-content: center; width: 100%; padding-top: 20px;">
                        <div style="width: 35%; padding-right: 15px;">
                            <label for="editdescripcionProducto">Descripcion</label>
                            <input type="text" id="editdescripcionProducto" name="editdescripcionProducto" class="form-control" 
                            value="{{$product->product_description ?? 'No tiene descripcion' }}" placeholder="{{$product->product_description ?? 'No tiene descripcion' }}">
                        </div>
                        <div style="width: 35%;">
                            <div style="display: none;" id="addTextoExtra">
                                <label for="editextraText">Texto Extra</label>
                                <input type="text" id="editextraText" name="editextraText" class="form-control" 
                                value="Agrega tu Texto" placeholder="Agrega tu Texto">
                            </div>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: center; width: 50%; padding-top: 20px;">
                        <div style="width: 40%;">
                            <input class="form-check-input" type="checkbox" value="true" id="toggleCheckbox"
                                name="addextraText">
                            <label class="form-check-label" for="toggleCheckbox">
                                Agregar Texto Extra
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
	    <div id="sendProduct" style="padding: 15px; position: relative; text-align: center; font-family: DejaVu Sans;">
            <div style="width: 100%; display: block; margin: auto;">
                <img src="{{$product->image_url}}" alt="Product image" style="display: block; max-width: 40%; padding-bottom: 20px; margin: auto; ">
                <div style="font-size: x-large; font-weight: bold; padding: 3px;">
                {{$product->name}}
                </div>
                <div style="width: 70%; word-wrap: break-word; overflow-wrap: break-word; display: inline-block; font-size: larger; padding: 3px">
                    <span id="descripcionProducto">
                        {{$product->product_description ?? 'No tiene descripcion' }}
                    </span>
                </div>
                <div style="display: none; font-size: medium; padding: 3px" id="divTextoExtra">
                    <div style="width: 70%; word-wrap: break-word; overflow-wrap: break-word; display: inline-block;">
                        <b>Texto Extra:</b>&nbsp;
                        <span id="extraText" style="word-wrap: break-word; overflow-wrap: break-word;">
                            Agrega tu Texto
                        </span>
                    </div>
                </div>
                @foreach($product->variations as $variation)
                    <div style="width: 70%; word-wrap: break-word; overflow-wrap: break-word; display: inline-block; font-size: medium; padding: 3px;">
                        @can('access_default_selling_price')
                            <b> Precio de venta:</b>&nbsp;₡&nbsp;
                            <span id="precioNormal">
                                {{ $variation->sell_price_inc_tax }}
                            </span>
                        @endcan
                    </div>
                    <div style="width: 70%; word-wrap: break-word; overflow-wrap: break-word; display: inline-block; font-size: medium; padding: 3px;">
                        @if(!empty($allowed_group_prices))
                            @foreach($allowed_group_prices as $key => $value)
                            <b>Precio por Mayoreo:</b> &nbsp;₡&nbsp;
                            <span id="precioMayoreo">
                                @if(!empty($group_price_details[$variation->id][$key]))
                                    {{ $group_price_details[$variation->id][$key] }}
                                @else
                                    00.00
                                @endif
                            </span>
                            @endforeach
                        @endif
                    </div>
                @endforeach
            </div>
      	</div>
      	<div class="modal-footer">
	      	<button type="button" class="btn btn-default no-print" data-dismiss="modal">@lang( 'messages.close' )</button>
	    </div>
	</div>
</div>
<script>
    function enviarPDFEmail() {
        const div = document.getElementById('sendProduct');
        const htmlContent = div.outerHTML; // Obtiene el HTML del div

        fetch("{{ route('products.send-product-email') }}", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                emails: document.getElementById('emails').value,
                htmlContent: htmlContent
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error); // Mostrar en consola
            alert(data.message || data.error); // Mostrar en alerta
        }) // Muestra la respuesta en la consola
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }
    function enviarPDFWhatsApp() {
        const div = document.getElementById('sendProduct');
        const htmlContent = div.outerHTML; // Obtiene el HTML del div
    
        fetch("{{ route('products.send-product-wsp') }}", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                phone: document.getElementById('phone').value,
                htmlContent: htmlContent
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error); // Mostrar en consola
            alert(data.message || data.error); // Mostrar en alerta
        }) // Muestra la respuesta en la consola
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }

    // Guardar el valor original al cargar la página
    $(document).ready(function () {
        //PRECIO MAYOREO
        let spanPrecioMayoreo = $('#precioMayoreo');
        if (spanPrecioMayoreo.length > 0) {
            spanPrecioMayoreo.data('original', spanPrecioMayoreo.text().trim());
            console.log("Se guardo como original: "+spanPrecioMayoreo.text().trim());
        } else {
            console.error("No se encontró el span con id='precioMayoreo'. Verifica tu HTML.");
        }
        //PRECIO NORMAL
        let spanPrecioNormal = $('#precioNormal');
        if (spanPrecioNormal.length > 0) {
            spanPrecioNormal.data('original', spanPrecioNormal.text().trim());
            console.log("Se guardo como original: "+spanPrecioNormal.text().trim());
        } else {
            console.error("No se encontró el span con id='precioNormal'. Verifica tu HTML.");
        }
        //DESCRIPCION DEL PRODUCTO
        let spanDescripcionProducto = $('#descripcionProducto');
        if (spanDescripcionProducto.length > 0) {
            spanDescripcionProducto.data('original', spanDescripcionProducto.text().trim());
            console.log("Se guardo como original: "+spanDescripcionProducto.text().trim());
        } else {
            console.error("No se encontró el span con id='descripcionProducto'. Verifica tu HTML.");
        }
        //TEXTO EXTRA
        let spanExtraText = $('#extraText');
        if (spanExtraText.length > 0) {
            spanExtraText.data('original', spanExtraText.text().trim());
            console.log("Se guardo como original: "+spanExtraText.text().trim());
        } else {
            console.error("No se encontró el span con id='extraText'. Verifica tu HTML.");
        }
        $("#toggleCheckbox").change(function(){
            $("#addTextoExtra").toggle(this.checked); // Si está marcado, muestra; si no, oculta
            $("#divTextoExtra").toggle(this.checked);
        });
    });
    $(document).on('input', '#editprecioMayoreo', function () {
        let inputValor = $(this).val().trim();
        let spanPrecioMayoreo = $('#precioMayoreo');

        if (spanPrecioMayoreo.length === 0) {
            console.error("No se encontró el span con id='precioMayoreo'. Verifica tu HTML.");
            return;
        }
        console.log(spanPrecioMayoreo.data('original'));
        if (inputValor === "") {
            spanPrecioMayoreo.text(spanPrecioMayoreo.data('original')); // Restaurar el valor original
        } else {
            spanPrecioMayoreo.text(inputValor); // Mostrar el nuevo valor
        }
    });
    $(document).on('input', '#editprecioNormal', function () {
        let inputValor = $(this).val().trim();
        let spanPrecioNormal = $('#precioNormal');

        if (spanPrecioNormal.length === 0) {
            console.error("No se encontró el span con id='precioNormal'. Verifica tu HTML.");
            return;
        }
        if (inputValor === "") {
            spanPrecioNormal.text(spanPrecioNormal.data('original')); // Restaurar el valor original
        } else {
            spanPrecioNormal.text(inputValor); // Mostrar el nuevo valor
        }
    });
    $(document).on('input', '#editdescripcionProducto', function () {
        let inputValor = $(this).val().trim();
        let spanDescripcionProducto = $('#descripcionProducto');

        if (spanDescripcionProducto.length === 0) {
            console.error("No se encontró el span con id='descripcionProducto'. Verifica tu HTML.");
            return;
        }
        if (inputValor === "") {
            spanDescripcionProducto.text(spanDescripcionProducto.data('original')); // Restaurar el valor original
        } else {
            spanDescripcionProducto.text(inputValor); // Mostrar el nuevo valor
        }
    });
    $(document).on('input', '#editextraText', function () {
        let inputValor = $(this).val().trim();
        let spanExtraText = $('#extraText');

        if (spanExtraText.length === 0) {
            console.error("No se encontró el span con id='descripcionProducto'. Verifica tu HTML.");
            return;
        }
        if (inputValor === "") {
            spanExtraText.text(spanExtraText.data('original')); // Restaurar el valor original
        } else {
            spanExtraText.text(inputValor); // Mostrar el nuevo valor
        }
    });
</script>
