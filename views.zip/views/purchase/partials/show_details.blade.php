<div style="border-bottom: 1px solid #ddd; padding: 15px;">
  @php
    if(!$isCompra || $isCompra.ob_get_length() == 0){
      $isCompra2 = false;
    }else $isCompra2 = true;
    
  @endphp
  @if (!$isCompra2)
    <button type="button" style="border: none; background: none; float: right; float: right; font-size: 21px; font-weight: 700; line-height: 1;
    color: #000; text-shadow: 0 1px 0 #fff; opacity: .2; overflow: hidden;" class="no-print" data-dismiss="modal" aria-label="Close">
      <span aria-hidden="true">&times;</span>
  </button>
  @endif
  @php
      $title = $purchase->type == 'purchase_order' ? __('lang_v1.purchase_order_details') : __('purchase.purchase_details');
      $custom_labels = json_decode(session('business.custom_labels'), true);
  @endphp

  <h4 style="margin: 0; line-height: 1.42857143; font-size: 14px;"> 
      {{$title}} (<b>@lang('purchase.ref_no'):</b> #{{ $purchase->ref_no }})
  </h4>
</div>

<div style="position: relative; padding: 15px;">
  <div style="width: 100%; text-align: right; margin-bottom: 10px;">
    <p><b>@lang('messages.date'):</b> {{ @format_date($purchase->transaction_date) }}</p>
  </div>

  <table style="width: 100%; border-collapse: collapse;">
      <tr>
          <td style="width: 33.33%; vertical-align: top; text-align: left;">
              <strong>@lang('purchase.supplier'):</strong>
              <address>
                  {!! $purchase->contact->contact_address !!}
                  @if(!empty($purchase->contact->tax_number))
                      <br>@lang('contact.tax_no'): {{$purchase->contact->tax_number}}
                  @endif
                  @if(!empty($purchase->contact->mobile))
                      <br>@lang('contact.mobile'): {{$purchase->contact->mobile}}
                  @endif
                  @if(!empty($purchase->contact->email))
                      <br>@lang('business.email'): {{$purchase->contact->email}}
                  @endif
              </address>
              @if (!$isCompra2)
                @if($purchase->document_path)
                    <a href="{{$purchase->document_path}}" 
                        download="{{$purchase->document_name}}" 
                        style="background: #28a745; color: #fff; padding: 5px 10px; text-decoration: none; font-size: 14px; 
                        margin-top: 5px; border-radius: 3px; border: none; cursor: pointer;" 
                        class="no-print">
                        <i class="fa fa-download"></i> &nbsp;{{ __('purchase.download_document') }}
                    </a>
                @endif
              @endif
          </td>

          <td style="width: 33.33%; vertical-align: top; text-align: left;">
              <strong>@lang('business.business'):</strong>
              <address>
                  <strong>{{ $purchase->business->name }}</strong>
                  {{ $purchase->location->name }}
                  @if(!empty($purchase->location->landmark))
                      <br>{{$purchase->location->landmark}}
                  @endif
                  @if(!empty($purchase->location->city) || !empty($purchase->location->state) || !empty($purchase->location->country))
                      <br>{{implode(',', array_filter([$purchase->location->city, $purchase->location->state, $purchase->location->country]))}}
                  @endif
                  
                  @if(!empty($purchase->business->tax_number_1))
                      <br>{{$purchase->business->tax_label_1}}: {{$purchase->business->tax_number_1}}
                  @endif

                  @if(!empty($purchase->business->tax_number_2))
                      <br>{{$purchase->business->tax_label_2}}: {{$purchase->business->tax_number_2}}
                  @endif

                  @if(!empty($purchase->location->mobile))
                      <br>@lang('contact.mobile'): {{$purchase->location->mobile}}
                  @endif
                  @if(!empty($purchase->location->email))
                      <br>@lang('business.email'): {{$purchase->location->email}}
                  @endif
              </address>
          </td>

          <td style="width: 33.33%; vertical-align: top; text-align: left;">
              <b>@lang('purchase.ref_no'):</b> #{{ $purchase->ref_no }}<br/>
              <b>@lang('messages.date'):</b> {{ @format_date($purchase->transaction_date) }}<br/>
              @if(!empty($purchase->status))
                  <b>@lang('purchase.purchase_status'):</b> 
                  @if($purchase->type == 'purchase_order') 
                      {{$po_statuses[$purchase->status]['label'] ?? ''}} 
                  @else 
                      {{ __('lang_v1.' . $purchase->status) }} 
                  @endif
                  <br>
              @endif
              @if(!empty($purchase->payment_status))
                  <b>@lang('purchase.payment_status'):</b> {{ __('lang_v1.' . $purchase->payment_status) }}
              @endif
              @if(!empty($custom_labels['purchase']['custom_field_1']))
                <br><strong>{{$custom_labels['purchase']['custom_field_1'] ?? ''}}: </strong> {{$purchase->custom_field_1}}
              @endif
              @if(!empty($custom_labels['purchase']['custom_field_2']))
                <br><strong>{{$custom_labels['purchase']['custom_field_2'] ?? ''}}: </strong> {{$purchase->custom_field_2}}
              @endif
              @if(!empty($custom_labels['purchase']['custom_field_3']))
                <br><strong>{{$custom_labels['purchase']['custom_field_3'] ?? ''}}: </strong> {{$purchase->custom_field_3}}
              @endif
              @if(!empty($custom_labels['purchase']['custom_field_4']))
                <br><strong>{{$custom_labels['purchase']['custom_field_4'] ?? ''}}: </strong> {{$purchase->custom_field_4}}
              @endif
              @if(!empty($purchase_order_nos))
                    <strong>@lang('restaurant.order_no'):</strong>
                    {{$purchase_order_nos}}
                @endif

                @if(!empty($purchase_order_dates))
                    <br>
                    <strong>@lang('lang_v1.order_dates'):</strong>
                    {{$purchase_order_dates}}
                @endif
              @if($purchase->type == 'purchase_order')
                @php
                  $custom_labels = json_decode(session('business.custom_labels'), true);
                @endphp
                <strong>@lang('sale.shipping'):</strong>
                <span class="label @if(!empty($shipping_status_colors[$purchase->shipping_status])) {{$shipping_status_colors[$purchase->shipping_status]}} @else {{'bg-gray'}} @endif">{{$shipping_statuses[$purchase->shipping_status] ?? '' }}</span><br>
                @if(!empty($purchase->shipping_address()))
                  {{$purchase->shipping_address()}}
                @else
                  {{$purchase->shipping_address ?? '--'}}
                @endif
                @if(!empty($purchase->delivered_to))
                  <br><strong>@lang('lang_v1.delivered_to'): </strong> {{$purchase->delivered_to}}
                @endif
                @if(!empty($purchase->shipping_custom_field_1))
                  <br><strong>{{$custom_labels['shipping']['custom_field_1'] ?? ''}}: </strong> {{$purchase->shipping_custom_field_1}}
                @endif
                @if(!empty($purchase->shipping_custom_field_2))
                  <br><strong>{{$custom_labels['shipping']['custom_field_2'] ?? ''}}: </strong> {{$purchase->shipping_custom_field_2}}
                @endif
                @if(!empty($purchase->shipping_custom_field_3))
                  <br><strong>{{$custom_labels['shipping']['custom_field_3'] ?? ''}}: </strong> {{$purchase->shipping_custom_field_3}}
                @endif
                @if(!empty($purchase->shipping_custom_field_4))
                  <br><strong>{{$custom_labels['shipping']['custom_field_4'] ?? ''}}: </strong> {{$purchase->shipping_custom_field_4}}
                @endif
                @if(!empty($purchase->shipping_custom_field_5))
                  <br><strong>{{$custom_labels['shipping']['custom_field_5'] ?? ''}}: </strong> {{$purchase->shipping_custom_field_5}}
                @endif
                @php
                  $medias = $purchase->media->where('model_media_type', 'shipping_document')->all();
                @endphp
                @if(count($medias))
                  @include('sell.partials.media_table', ['medias' => $medias])
                @endif
              @endif
          </td>
      </tr>
  </table>

  <br>
  <div style="margin-right: -15px;
    margin-left: -15px;">
    <div style="width: 100%;">
      <div style="min-height: .01%;
    overflow-x: auto;">
        <table class="table" style="background-color: #d2d6de !important; font-size: 10px;">
          <thead>
            <tr style="background-color: #2dce89 !important;">
              <th>#</th>
              <th>@lang('product.product_name')</th>
              <th>@lang('product.sku')</th>
              @if($purchase->type == 'purchase_order')
                <th style="text-align: right;">@lang( 'lang_v1.quantity_remaining' )</th>
              @endif
              <th style="text-align: right;">@if($purchase->type == 'purchase_order') @lang('lang_v1.order_quantity') @else @lang('purchase.purchase_quantity') @endif</th>
              <th style="text-align: right;">@lang( 'lang_v1.unit_cost_before_discount' )</th>
              <th style="text-align: right;">@lang( 'lang_v1.discount_percent' )</th>
              <th class="no-print text-right">@lang('purchase.unit_cost_before_tax')</th>
              <th class="no-print text-right">@lang('purchase.subtotal_before_tax')</th>
              <th style="text-align: right;">@lang('sale.tax')</th>
              <th style="text-align: right;">@lang('purchase.unit_cost_after_tax')</th>
              @if($purchase->type != 'purchase_order')
              <th style="text-align: right;">@lang('purchase.unit_selling_price')</th>
              @if(session('business.enable_lot_number'))
                <th>@lang('lang_v1.lot_number')</th>
              @endif
              @if(session('business.enable_product_expiry'))
                <th>@lang('product.mfg_date')</th>
                <th>@lang('product.exp_date')</th>
              @endif
              @endif
              <th style="text-align: right;">@lang('sale.subtotal')</th>
            </tr>
          </thead>
          @php 
            $total_before_tax = 0.00;
          @endphp
          @foreach($purchase->purchase_lines as $purchase_line)
            <tr>
              <td>{{ $loop->iteration }}</td>
              <td>
                {{ $purchase_line->product->name }}
                 @if( $purchase_line->product->type == 'variable')
                  - {{ $purchase_line->variations->product_variation->name}}
                  - {{ $purchase_line->variations->name}}
                 @endif
              </td>
              <td>
                 @if( $purchase_line->product->type == 'variable')
                  {{ $purchase_line->variations->sub_sku}}
                  @else
                  {{ $purchase_line->product->sku }}
                 @endif
              </td>
              @if($purchase->type == 'purchase_order')
              <td>
                <span class="display_currency" data-is_quantity="true" data-currency_symbol="false">{{ $purchase_line->quantity - $purchase_line->po_quantity_purchased }}</span> @if(!empty($purchase_line->sub_unit)) {{$purchase_line->sub_unit->short_name}} @else {{$purchase_line->product->unit->short_name}} @endif
              </td>
              @endif
              <td><span class="display_currency" data-is_quantity="true" data-currency_symbol="false">{{ $purchase_line->quantity }}</span> @if(!empty($purchase_line->sub_unit)) {{$purchase_line->sub_unit->short_name}} @else {{$purchase_line->product->unit->short_name}} @endif</td>
              <td style="text-align: right;"><span class="display_currency" data-currency_symbol="true">{{ $purchase_line->pp_without_discount}}</span></td>
              <td style="text-align: right;"><span class="display_currency">{{ $purchase_line->discount_percent}}</span> %</td>
              <td style="text-align: right;" class="no-print"><span class="display_currency" data-currency_symbol="true">{{ $purchase_line->purchase_price }}</span></td>
              <td style="text-align: right;" class="no-print"><span class="display_currency" data-currency_symbol="true">{{ $purchase_line->quantity * $purchase_line->purchase_price }}</span></td>
              <td style="text-align: right;"><span class="display_currency" data-currency_symbol="true">{{ $purchase_line->item_tax }} </span> <br/><small>@if(!empty($taxes[$purchase_line->tax_id])) ( {{ $taxes[$purchase_line->tax_id]}} ) </small>@endif</td>
              <td style="text-align: right;"><span class="display_currency" data-currency_symbol="true">{{ $purchase_line->purchase_price_inc_tax }}</span></td>
              @if($purchase->type != 'purchase_order')
              @php
                $sp = $purchase_line->variations->default_sell_price;
                if(!empty($purchase_line->sub_unit->base_unit_multiplier)) {
                  $sp = $sp * $purchase_line->sub_unit->base_unit_multiplier;
                }
              @endphp
              <td style="text-align: right;"><span class="display_currency" data-currency_symbol="true">{{$sp}}</span></td>

              @if(session('business.enable_lot_number'))
                <td>{{$purchase_line->lot_number}}</td>
              @endif

              @if(session('business.enable_product_expiry'))
              <td>
                @if(!empty($purchase_line->mfg_date))
                    {{ @format_date($purchase_line->mfg_date) }}
                @endif
              </td>
              <td>
                @if(!empty($purchase_line->exp_date))
                    {{ @format_date($purchase_line->exp_date) }}
                @endif
              </td>
              @endif
              @endif
              <td style="text-align: right;"><span class="display_currency" data-currency_symbol="true">{{ $purchase_line->purchase_price_inc_tax * $purchase_line->quantity }}</span></td>
            </tr>
            @php 
              $total_before_tax += ($purchase_line->quantity * $purchase_line->purchase_price);
            @endphp
          @endforeach
        </table>
      </div>
    </div>
  </div>

  <br>
  <div style="margin-right: -15px;
    margin-left: -15px;">
    @if(!empty($purchase->type == 'purchase'))
    <div style="width: 100%;">
      <h4>{{ __('sale.payment_info') }}:</h4>
    </div>
    <div class="col-md-6" style="width: 100%; margin-top: 5px;">
      <div style="min-height: .01%;
      overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; background-color: #ffffff; border: 1px solid #ddd;">
          <tr style="background-color: #2dce89 !important; color: white;">
              <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">#</th>
              <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">{{ __('messages.date') }}</th>
              <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">{{ __('purchase.ref_no') }}</th>
              <th style="padding: 10px; text-align: right; border: 1px solid #ddd;">{{ __('sale.amount') }}</th>
              <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">{{ __('sale.payment_mode') }}</th>
              <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">{{ __('sale.payment_note') }}</th>
          </tr>
          @php
              $total_paid = 0;
          @endphp
          @forelse($purchase->payment_lines as $payment_line)
            @php
                $total_paid += $payment_line->amount;
            @endphp
              <tr>
                  <td style="padding: 10px; border: 1px solid #ddd;">{{ $loop->iteration }}</td>
                  <td style="padding: 10px; border: 1px solid #ddd;">{{ @format_date($payment_line->paid_on) }}</td>
                  <td style="padding: 10px; border: 1px solid #ddd;">{{ $payment_line->payment_ref_no }}</td>
                  <td style="padding: 10px; text-align: right; border: 1px solid #ddd;">
                      <span>{{ $payment_line->amount }}</span>
                  </td>
                  <td style="padding: 10px; border: 1px solid #ddd;">{{ $payment_methods[$payment_line->method] ?? '' }}</td>
                  <td style="padding: 10px; border: 1px solid #ddd;">
                      @if($payment_line->note) 
                          {{ ucfirst($payment_line->note) }}
                      @else
                          --
                      @endif
                  </td>
              </tr>
            @empty
            <tr>
                <td colspan="6" style="text-align: center; padding: 10px; border: 1px solid #ddd;">
                    @lang('purchase.no_payments')
                </td>
            </tr>
          @endforelse
        </table>
      </div>
    </div>
    @endif

    <div class="col-md-6 @if($purchase->type == 'purchase_order') col-md-offset-6 @endif" style="width: 100%;">
      <div style="min-height: .01%;
      overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; text-align: right; background-color: #ffffff;">
          <tr>
              <th style="padding: 10px; border-bottom: 1px solid #ddd; text-align: left;">@lang('purchase.net_total_amount'):</th>
              <td style="padding: 10px; border-bottom: 1px solid #ddd;"></td>
              <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                  <span class="display_currency" data-currency_symbol="true">{{ $total_before_tax }}</span>
              </td>
          </tr>
          <tr>
              <th style="padding: 10px; border-bottom: 1px solid #ddd; text-align: left;">@lang('purchase.discount'):</th>
              <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                  <b>(-)</b>
                  @if($purchase->discount_type == 'percentage')
                      ({{$purchase->discount_amount}} %)
                  @endif
              </td>
              <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                  <span class="display_currency" data-currency_symbol="true">
                      @if($purchase->discount_type == 'percentage')
                          {{$purchase->discount_amount * $total_before_tax / 100}}
                      @else
                          {{$purchase->discount_amount}}
                      @endif                  
                  </span>
              </td>
          </tr>
          <tr>
              <th style="padding: 10px; border-bottom: 1px solid #ddd; text-align: left;">@lang('purchase.purchase_tax'):</th>
              <td style="padding: 10px; border-bottom: 1px solid #ddd;"><b>(+)</b></td>
              <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                  @if(!empty($purchase_taxes))
                      @foreach($purchase_taxes as $k => $v)
                          <strong><small>{{$k}}</small></strong> - <span class="display_currency" data-currency_symbol="true">{{ $v }}</span><br>
                      @endforeach
                  @else
                      0.00
                  @endif
              </td>
          </tr>
          @if( !empty( $purchase->shipping_charges ) )
              <tr>
                  <th style="padding: 10px; border-bottom: 1px solid #ddd; text-align: left;">@lang('purchase.additional_shipping_charges'):</th>
                  <td style="padding: 10px; border-bottom: 1px solid #ddd;"><b>(+)</b></td>
                  <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                      <span class="display_currency">{{ $purchase->shipping_charges }}</span>
                  </td>
              </tr>
          @endif
          @for ($i = 1; $i <= 4; $i++)
              @php
                  $key = "additional_expense_key_$i";
                  $value = "additional_expense_value_$i";
              @endphp
              @if( !empty($purchase->$value) && !empty($purchase->$key) )
                  <tr>
                      <th style="padding: 10px; border-bottom: 1px solid #ddd; text-align: left;">{{ $purchase->$key }}:</th>
                      <td style="padding: 10px; border-bottom: 1px solid #ddd;"><b>(+)</b></td>
                      <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                          <span class="display_currency">{{ $purchase->$value }}</span>
                      </td>
                  </tr>
              @endif
          @endfor
          <tr>
              <th style="padding: 10px; text-align: left;">@lang('purchase.purchase_total'):</th>
              <td style="padding: 10px;"></td>
              <td style="padding: 10px;">
                  <span class="display_currency" data-currency_symbol="true">{{ $purchase->final_total }}</span>
              </td>
          </tr>
        </table>
      </div>
    </div>
  </div>

  <div style="margin-bottom: 15px;">
    <div style="width: 50%; float: left; padding-right: 10px; margin-top: 5px;">
        <strong>@lang('purchase.shipping_details'):</strong><br>
        <p style="background-color: #f0f0f0; padding: 10px; border-radius: 4px; margin-top: 10px; font-size: 14px;">
            {{ $purchase->shipping_details ?? '' }}

            @if(!empty($purchase->shipping_custom_field_1))
                <br><strong>{{$custom_labels['purchase_shipping']['custom_field_1'] ?? ''}}:</strong> {{$purchase->shipping_custom_field_1}}
            @endif
            @if(!empty($purchase->shipping_custom_field_2))
                <br><strong>{{$custom_labels['purchase_shipping']['custom_field_2'] ?? ''}}:</strong> {{$purchase->shipping_custom_field_2}}
            @endif
            @if(!empty($purchase->shipping_custom_field_3))
                <br><strong>{{$custom_labels['purchase_shipping']['custom_field_3'] ?? ''}}:</strong> {{$purchase->shipping_custom_field_3}}
            @endif
            @if(!empty($purchase->shipping_custom_field_4))
                <br><strong>{{$custom_labels['purchase_shipping']['custom_field_4'] ?? ''}}:</strong> {{$purchase->shipping_custom_field_4}}
            @endif
            @if(!empty($purchase->shipping_custom_field_5))
                <br><strong>{{$custom_labels['purchase_shipping']['custom_field_5'] ?? ''}}:</strong> {{$purchase->shipping_custom_field_5}}
            @endif
        </p>
    </div>
    <div style="width: 50%; float: left; padding-left: 10px; margin-top: 5px;">
        <strong>@lang('purchase.additional_notes'):</strong><br>
        <p style="background-color: #f0f0f0; padding: 10px; border-radius: 4px; margin-top: 10px; font-size: 14px;">
            @if($purchase->additional_notes)
                {{ $purchase->additional_notes }}
            @else
                --
            @endif
        </p>
    </div>
    <div style="clear: both;"></div>
  </div>


  @if(!empty($activities))
  <div class="row">
    <div class="col-md-12">
          <strong>{{ __('lang_v1.activities') }}:</strong><br>
          @includeIf('activity_log.activities', ['activity_type' => 'purchase'])
      </div>
  </div>
  @endif

  {{-- Barcode --}}
  <div style="text-align: center; margin-top: 15px;" class="print_section">
    <img class="center-block" src="data:image/png;base64,{{DNS1D::getBarcodePNG($purchase->ref_no, 'C128', 2,30,array(39, 48, 54), true)}}" 
         style="margin: 0 auto;">
  </div>

</div>
