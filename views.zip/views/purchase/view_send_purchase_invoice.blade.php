<div class="modal-dialog modal-xl" role="document">
	<div class="modal-content">
		<div class="modal-header">
		    <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		    <h4 class="modal-title" id="modalTitle">ENVIAR FACTURA POR CORREO Y WHATSAPP</h4>
	    </div>
        <div class="modal-body">
            <!-- FORMULARIOS -->
            <div class="card mb-4 shadow-sm">
                <!-- ENVIO POR CORREO-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="emailForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="email">{{ __('Correo(s) del Cliente') }}:</label>
                                <input type="text" id="email" name="email" class="form-control" placeholder="correo1@example.com, correo2@example.com">
                            </div>
                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-primary w-100" onclick="enviarPDFEmail()">{{ __('Enviar Correo') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- ENVIO POR WHATSAPP-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="whatsappForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="cellphone">{{ __('Numero de Telefono') }}:</label>
                                <input type="text" id="cellphone" name="cellphone" class="form-control" placeholder="51 999999999">
                            </div>

                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-success w-100" onclick="enviarPDFWhatsApp()">{{ __('Enviar WhatsApp') }}</button>
                            </div>
                        </div>
                    </form>
                </div>  
            </div>
        </div>
        <hr>
	    <div id="sendPurchaseInvoice" style="font-family: DejaVu Sans; font-size: 10px;">
            <div class="row d-flex align-items-center" style="margin: auto;">
                <div class="col-sm-12">
                    @include('purchase.partials.show_details')
                </div>
            </div>
      	</div>
      	<div class="modal-footer">
	      	<button type="button" class="btn btn-default no-print" data-dismiss="modal">@lang( 'messages.close' )</button>
	    </div>
	</div>
</div>
<script>
    function enviarPDFEmail() {
        const div = document.getElementById('sendPurchaseInvoice');
        const htmlContent = div.outerHTML; // Obtiene el HTML del div

        fetch("{{ route('purchaseInvoice.send-purchase-email') }}", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                emails: document.getElementById('email').value,
                htmlContent: htmlContent
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error); // Mostrar en consola
            alert(data.message || data.error); // Mostrar en alerta
        }) // Muestra la respuesta en la consola
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }

    function enviarPDFWhatsApp() {    
        const div = document.getElementById('sendPurchaseInvoice');
        const htmlContent = div.outerHTML; // Obtiene el HTML del div

        fetch("{{ route('purchaseInvoice.send-purchase-wsp') }}", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                phone: document.getElementById('cellphone').value,
                htmlContent: htmlContent
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error); // Mostrar en consola
            alert(data.message || data.error); // Mostrar en alerta
        }) // Muestra la respuesta en la consola
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }
</script>
