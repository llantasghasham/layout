@extends('layouts.app-config')
@section('title', __('lang_v1.reception_title'))
@section('content')

<!-- Content Header (Page header) -->
<section class="content-header"><h1>@lang('lang_v1.reception')</h1></section>

<!-- Main content -->
<section class="content">
   <div class="box box-solid">
      <div class="box-body border">
         <div class="row">
            <div class="col-sm-6">
               {!! Form::open(['url' => action('RecElecController@process'), 'method' => 'post', 'id' => 'add_recepcion_form', 'files' => true, 'name' => 'add_recepcion_form' ]) !!}
                  <div class="form-group">
                     {!! Form::label('upload_document', __('lang_v1.document_xml') . ':') !!}
                     {!! Form::file('upload_document[]', ['id' => 'upload_document', 'multiple', 'accept' => implode(',', array_keys(config('constants.document_upload_mimes_xml')))]); !!}
                     <small><p class="help-block">@lang('purchase.max_file_size', ['size' => (config('constants.document_size_limit') / 1000000)])
                     @includeIf('lang_v1.document_help_text')</p></small>
                     {!! Form::text(null, action('RecElecController@load'), ['class' => 'hidden url_cargar']); !!}
                  </div>
               {!! Form::close() !!}
            </div>
            <div class="col-sm-6 text-left" style="padding-top: 25px;">
               <button type="button" class="btn btn-danger btn-sm load_xml" id="load_xml" style="height: 35px; width: 120px;">
                  <span class="glyphicon glyphicon-sunglasses mr-2" aria-hidden="true"></span>
                  @lang('lang_v1.load_xml')
               </button>
               <button type="button" class="btn btn-success btn-sm" id="process_xml" style="height: 35px; width: 120px;">
                  <span class="glyphicon glyphicon-cog mr-2" aria-hidden="true"></span>
                  @lang('lang_v1.save_next')
               </button>
            </div>
         </div>
      </div>
   </div>
   <div class="box box-solid">
      <div class="box-body">
         <div class="row">
            <div class="col-sm-12">@include('recepcion_electronica.partials.xml_table')</div>
         </div>
      </div>
   </div>
   <div class="box box-solid hidden">
      <div class="box-body">
         <div class="row">
            @if(count($business_locations) == 1)
               @php 
                  $default_location = current(array_keys($business_locations->toArray())) 
               @endphp
            @else
               @php $default_location = null; @endphp
            @endif
        <div class="clearfix"></div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('consecutive', __('lang_v1.consecutive').':') !!}
                  {!! Form::text('consecutive', null, ['class' => 'form-control']); !!}
               </div>
            </div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('date_of_issue', __('lang_v1.date_of_issue').':') !!}
                  {!! Form::text('date_of_issue', null, ['class' => 'form-control']); !!}
               </div>
            </div>
        <div class="clearfix"></div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('identification_number_issuer', __('lang_v1.identification_number_issuer').':') !!}
                  {!! Form::text('identification_number_issuer', null, ['class' => 'form-control']); !!}
               </div>
            </div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('issuer', __('lang_v1.issuer').':') !!}
                  {!! Form::text('issuer', null, ['class' => 'form-control']); !!}
               </div>
            </div>
        <div class="clearfix"></div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('identification_number_receiver', __('lang_v1.identification_number_receiver').':') !!}
                  {!! Form::text('identification_number_receiver', null, ['class' => 'form-control']); !!}
               </div>
            </div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('receiver', __('lang_v1.receiver').':') !!}
                  {!! Form::text('receiver', null, ['class' => 'form-control']); !!}
               </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('tax', __('lang_v1.tax').':') !!}
                  {!! Form::text('tax', null, ['class' => 'form-control']); !!}
               </div>
            </div>
            <div class="col-sm-6">
               <div class="form-group">
                  {!! Form::label('total', __('lang_v1.total').':') !!}
                  {!! Form::text('total', null, ['class' => 'form-control']); !!}
               </div>
            </div>
        <div class="clearfix"></div>
        <div class="col-sm-12"><hr style="border-top: 3px solid #337ab7!important;" size="10"></div>
        <div class="col-sm-6"></div>
         </div>
      </div>
   </div> <!--box end-->
</section>
@endsection
@section('javascript')
<script src="{{ asset('js/purchase.js?v=' . $asset_v) }}"></script>
@endsection