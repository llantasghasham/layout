@extends('layouts.app-config')
@section('title', __('lang_v1.reception_title'))
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header no-print">
        <h1>@lang('lang_v1.list_reception')<small></small></h1>
    </section>

    <form action="{{ route('recepciones.send_report') }}" method="POST">
        @csrf
    </form>

    <!-- Main content -->
    <section class="content no-print">
        @can('admin.view')
            @component('components.filters', ['title' => __('report.filters')])
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('reception_list_filter_location_id', __('purchase.business_location') . ':') !!}
                        {!! Form::select('reception_list_filter_location_id', $business_locations, null, [
                            'class' => 'form-control select2',
                            'style' => 'width:100%',
                            'placeholder' => __('lang_v1.all'),
                        ]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('reception_list_filter_date_range', __('report.date_range') . ':') !!}
                        {!! Form::text('reception_list_filter_date_range', null, [
                            'placeholder' => __('lang_v1.select_a_date_range'),
                            'class' => 'form-control',
                            'readonly',
                        ]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('reception_status_id', __('lang_v1.status') . ':') !!}
                        {!! Form::select('reception_status_id', $statuses, null, [
                            'class' => 'form-control select2',
                            'style' => 'width:100%',
                            'placeholder' => '',
                        ]) !!}
                    </div>
                </div>

                <!-- Campo de email -->
                <div class="col-md-3">
                    <div class="form-group">
                        {!! Form::label('emails', __('lang_v1.enter_emails') . ':') !!}
                        {!! Form::text('emails', null, [
                            'class' => 'form-control',
                            'placeholder' => 'email1@example.com, email2@example.com',
                        ]) !!}
                    </div>
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn btn-primary" id="send_report">@lang('lang_v1.send_report')</button>
                </div>
            @endcomponent
            @component('components.widget', ['class' => 'box-primary', 'title' => __('lang_v1.all_reception')])
                @include('recepcion_electronica.partials.reception_table')
            @endcomponent
        @endcan
    </section>

    <section id="receipt_section" class="print_section"></section>

    <!-- /.content -->
@stop

@section('javascript')
<link rel="stylesheet" href="{{ asset('css/custom.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<script src="{{ asset('js/jquery-3.6.0.min.js') }}"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="{{ asset('js/purchase.js?v=' . $asset_v) }}"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // Inicializar el selector de rango de fechas
        $('#reception_list_filter_date_range').daterangepicker(
            dateRangeSettings,
            function(start, end) {
                $('#reception_list_filter_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(
                    moment_date_format));
                reception_table.ajax.reload();
            }
        );

        $('#reception_list_filter_date_range').on('cancel.daterangepicker', function(ev, picker) {
            $('#reception_list_filter_date_range').val('');
            reception_table.ajax.reload();
        });

        // Enviar reporte por correo
        $('#send_report').click(function() {
            var emails = $('#emails').val();

            // Validar correos electrónicos
            if (!emails || emails.trim() === '') {
                alert('Por favor, ingrese al menos una dirección de correo electrónico.');
                return;
            }

            var emailArray = emails.split(',');
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            for (var i = 0; i < emailArray.length; i++) {
                var email = emailArray[i].trim();
                if (!emailPattern.test(email)) {
                    alert('Por favor, ingrese una dirección de correo electrónico válida.');
                    return;
                }
            }

            var start_date = $('#reception_list_filter_date_range').data('daterangepicker').startDate.format(
                'YYYY-MM-DD');
            var end_date = $('#reception_list_filter_date_range').data('daterangepicker').endDate.format(
                'YYYY-MM-DD');
            var location_id = $('#reception_list_filter_location_id').val();
            var statuses_id = $('#reception_status_id').val();

            $.ajax({
                url: '{{ route('recepciones.send_report') }}',
                method: 'POST',
                data: {
                    emails: emails,
                    start_date: start_date,
                    end_date: end_date,
                    location_id: location_id,
                    statuses_id: statuses_id,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    alert('Reporte enviado con éxito');
                },
                error: function(xhr, status, error) {
                    alert('Ocurrió un error al enviar el reporte');
                }
            });
        });


        // Inicialización de DataTables
        if (!$.fn.DataTable.isDataTable('#reception_table')) {
            var reception_table = $('#reception_table').DataTable({
                processing: true,
                serverSide: true,
                /* scrollY: "75vh",
                scrollX: true,
                scrollCollapse: true,
                pageLength: 25, */
                
                ajax: {
                    url: '/recepcion/listado',
                    data: function(d) {
                        var start = '';
                        var end = '';
                        var location_id = '';
                        var statuses_id = '';
                        if ($('#reception_list_filter_date_range').val()) {
                            start = $('input#reception_list_filter_date_range')
                                .data('daterangepicker')
                                .startDate.format('YYYY-MM-DD');
                            end = $('input#reception_list_filter_date_range')
                                .data('daterangepicker')
                                .endDate.format('YYYY-MM-DD');
                        }
                        if ($('select#reception_list_filter_location_id').val() != "") {
                            location_id = $('select#reception_list_filter_location_id').val();
                        }
                        if ($('select#reception_status_id').val() != "") {
                            statuses_id = $('select#reception_status_id').val();
                        }
                        d.start_date = start;
                        d.end_date = end;
                        d.location_id = location_id;
                        d.statuses_id = statuses_id;

                        d = __datatable_ajax_callback(d);
                    }
                },
                aaSorting: [
                    [1, 'desc']
                ],
                columns: [{
                        data: 'rutaxml',
                        name: 'rutaxml'
                    },
                    {
                        data: 'consecutivo',
                        name: 'consecutivo',
                        orderable: true,
                        searchable: true
                    },
                    {
                        data: 'tipodoc',
                        name: 'tipodoc',
                        render: function(data, type, row) {
                            switch (data) {
                                case '01':
                                    return '01 Factura Electrónica';
                                case '02':
                                    return '02 Tiquete Electrónico';
                                case '03':
                                    return '03 Nota de Crédito';
                                default:
                                    return data;
                            }
                        }
                    },
                    {
                        data: 'emisor',
                        name: 'emisor'
                    },
                    {
                        data: 'receptor',
                        name: 'receptor'
                    },
                    {
                        data: 'fecha',
                        name: 'fecha'
                    },
                    {
                        data: 'impuesto',
                        name: 'impuesto'
                    },
                    {
                        data: 'total',
                        name: 'total'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                ],
                rowCallback: function(row, data, index) {
                    // Aplicamos un fondo de color a las filas con tipo de documento "03 Nota de Crédito"
                    if (data.tipodoc === '03') {
                        $(row).css('background-color', '#FFDDC1'); // Color de fondo para "Nota de Crédito"
                    }
                },
                fnDrawCallback: function(oSettings) {
                    __currency_convert_recursively($('#reception_table'));
                },
                dom: 'Blrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'colvis'
                ]
            });
        }
    </script>
@endsection
