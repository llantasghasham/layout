<table class="table table-bordered table-striped ajax_view" id="reception_table" style="width: 100%; font-size: 12px;">
    <thead>
        <tr>
            <th>@lang('lang_v1.action')</th>
            <th>@lang('lang_v1.consecutive_number')</th> <!-- Cambiado para mostrar Consecutivo -->
            <th>@lang('lang_v1.document_type')</th> <!-- Nueva columna para Tipo de Documento -->
            <th>@lang('lang_v1.issue_name')</th>
            <th>@lang('lang_v1.receiver_name')</th>
            <th>@lang('lang_v1.reception_date')</th>
            <th>@lang('lang_v1.reception_tax')</th>
            <th>@lang('lang_v1.total')</th>
            <th>@lang('lang_v1.status')</th>
        </tr>
    </thead>
    <tbody>
        <!-- El cuerpo de la tabla se llenará con datos usando AJAX -->
    </tbody>
</table>
