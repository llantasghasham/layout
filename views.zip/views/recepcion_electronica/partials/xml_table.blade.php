<table class="table table-bordered" id="xml_table" style="width: 100%; font-size: 12px;">
   <thead class="bg-primary">
      <tr>
         <th class="w-16">@lang('lang_v1.consecutive')</th>
         <th class="w-16">@lang('lang_v1.date_of_issue')</th>
         <th>@lang('lang_v1.issuer')</th>
         <th>@lang('lang_v1.receiver')</th>
         <th>@lang('lang_v1.tax')</th>
         <th>@lang('lang_v1.load_xml')</th>
      </tr>
   </thead>
   <tbody></tbody>
</table>