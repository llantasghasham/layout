<!DOCTYPE html>

<html>

<head>

    <!-- Aquí puedes agregar tus etiquetas meta, enlaces a hojas de estilo CSS y otros encabezados -->

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Estilos CSS -->

<style>

/* Ajustes generales */

* {

    margin: 0;

    padding: 0;

    box-sizing: border-box;

}



body {

    font-family: Arial, sans-serif;

    color: #333;

}



.container {

    width: 100%;

    padding: 15px;

}



/* Tabla principal */

.table-bordered {

    width: 100%;

    border-collapse: collapse;

    margin-bottom: 0;

    background-color: #ffffff;

}



.table-bordered th, .table-bordered td {

    border: 1px solid #edbb99; /* Naranja claro para bordes */

    padding: 10px;

    text-align: center;

}



.table-bordered th {

    background-color: #007bff; /* Azul principal */

    color: white;

    font-size: 14px;

}



/* Colores alternados en filas */

.table-bordered tr:nth-child(odd) {

    background-color: #d9eaff; /* Azul claro */

}



.table-bordered tr:nth-child(even) {

    background-color: #ffffff; /* Blanco */

}



/* Efecto hover en filas */

.table-bordered tr:hover {

    background-color: #ffcc99; /* Naranja suave */

    cursor: pointer;

}



/* Contenedor del cuerpo de la tabla con scroll */

#product_list_body {

    max-height: 470px;

    overflow-y: auto;

    width: 100%;

    margin: 0;

    border: 1px solid #edbb99; /* Naranja claro */

}



/* Celdas del cuerpo */

#product_list_body td {

    color: #000; /* Negro puro para texto */

    padding: 10px;

    border: 1px solid #edbb99; /* Naranja claro para bordes */

    text-align: center;

}



/* Alineación específica de columnas */

#product_list_body td:first-child {

    text-align: left;

    width: 44%; /* Ajuste dinámico */

}



#product_list_body td:nth-child(2) {

    text-align: left;

    width: 15%;

}



/* Botones */

.btn {

    padding: 10px 15px;

    border-radius: 4px;

    text-align: center;

    cursor: pointer;

    transition: all 0.3s ease;

}



.btn-primary {

    background-color: #007bff;

    border-color: #007bff;

    color: white;

}



.btn-primary:hover {

    background-color: #0056b3;

    border-color: #0056b3;

}



.btn-orange {

    background-color: #ff8c00;

    border-color: #ff8c00;

    color: white;

}



.btn-orange:hover {

    background-color: #e07b00;

    border-color: #e07b00;

}



/* Barra de búsqueda */

.search-bar-container {

    display: flex;

    align-items: center;

    gap: 10px;

    margin-bottom: 15px;

}



.search-bar {

    flex: 1;

    padding: 10px;

    border: 1px solid #ddd;

    border-radius: 4px;

}



/* Media Queries para pantallas pequeñas */

@media (max-width: 768px) {

    .table-bordered th, .table-bordered td {

        font-size: 12px;

        padding: 8px;

    }



    #product_list_body {

        max-height: 300px;

    }



    .search-bar {

        font-size: 14px;

    }



    .btn {

        font-size: 14px;

        padding: 8px 10px;

    }

}

 /* Encapsular estilos dentro de un contenedor específico */

#product_list_body {

    width: 100%;

    margin: 0;

}



#product_list_body table {

    width: 100%;

    border-collapse: collapse;

}



/* Encabezados */

#product_list_body th {

    background-color: #007bff; /* Azul principal */

    color: white; /* Blanco para texto de encabezado */

    text-align: center;

    padding: 10px;

    border: 1px solid #ddd;

}



/* Celdas */

#product_list_body td {

    color: #000; /* Negro puro para el texto */

    text-align: center;

    padding: 8px;

    border: 1px solid #edbb99; /* Durazno Claro */



}



/* Alternar colores en filas */

#product_list_body tr:nth-child(odd) {

    background-color: #d9eaff; /* Azul claro */

}



#product_list_body tr:nth-child(even) {

    background-color: #ffffff; /* Blanco */

}



/* Efecto hover */

#product_list_body tr:hover {

    background-color: #edbb99; /* Anaranjado claro */

}

</style>

</head>

<body>



<!-- Buscador y Botones -->

<div class="row mb-4">

    <div class="col-md-12">

        <div class="search-bar-container">

            <input type="text" class="form-control search-bar" id="inpBuscarProducto" onkeyup="doSearchProductos()" placeholder="Buscar artículo por código o descripción...">

            <div class="btn-group">

                <button type="button" class="btn btn-danger" id="btnlistado">Listado</button>

                <button type="button" class="btn btn-success" id="btnimagenes">Imágenes</button>

                <button type="button" class="btn btn-orange" id="show_featured_products" onclick="showFeaturedProducts()">

                    <i class="fa fa-star"></i> Destacados

                </button>

            </div>

        </div>

    </div>

</div>



<!-- Header de la tabla de productos -->

<div class="row">

    <div class="col-md-12">

        <div style="overflow-y: auto; ">
            <div id="product_list_body" style="max-height: 635px; overflow-x: auto; ">

                <!-- Aquí se cargarán los productos dinámicamente -->

            </div>
        </div>

    </div>

</div>

    <div class="col-md-12 text-center" id="suggestion_page_loader" style="display: none;">

        <i class="fa fa-spinner fa-spin fa-2x"></i>

    </div>

</div>







<!-- JavaScript para alternar entre vistas, búsquedas, filtros y paginación -->

<script>

    let currentPage = 1;

    let isLoading = false;



    document.getElementById('btnlistado').addEventListener('click', function() {

        showListView();

    });


    /*
    document.getElementById('btnimagenes').addEventListener('click', function() {

        showImageView();

    });
    */


    document.getElementById('show_featured_products').addEventListener('click', function() {

        toggleFeaturedProducts();

        loadFeaturedProducts();

    });



    function showListView() {

        document.getElementById('product_category_div').style.display = 'none';

        document.getElementById('product_brand_div').style.display = 'none';

        document.getElementById('product_list_body').innerHTML = ''; // Limpiar productos

        let product_list_body = document.getElementById('product_list_body');
        let page = document.getElementById('suggestion_page').value;

        if (page == 1) {
            load_table_products();
        }
    }


    /*
    function showImageView() {

        document.getElementById('product_category_div').style.display = 'block';

        document.getElementById('product_brand_div').style.display = 'block';

        document.getElementById('product_list_body').innerHTML = ''; // Limpiar productos

        loadProducts(); // Cargar productos de imágenes

    }*/



    function toggleFeaturedProducts() {

        let featuredBox = document.getElementById('featured_products_box');

        if (featuredBox.style.display === 'none' || featuredBox.style.display === '') {

            featuredBox.style.display = 'block';

        } else {

            featuredBox.style.display = 'none';

        }

    }



    function loadFeaturedProducts() {

        let url = '/path/to/your/api/featured-products'; // Asegúrate de usar la URL correcta para obtener productos destacados



        fetch(url)

            .then(response => response.json())

            .then(data => {

                let featuredBox = document.getElementById('featured_products_box');

                featuredBox.innerHTML = ''; // Limpiar productos anteriores



                data.products.forEach(product => {

                    let productItem = document.createElement('div');

                    productItem.classList.add('product-item');

                    productItem.innerHTML = `

                        <a href="/pos/${product.id}">

                            <table class="w-100">

                                <tr>

                                    <td style="width:45%;">${product.name}</td>

                                    <td class="text-left" style="width:15%;">${product.price}</td>

                                    <td class="text-center" style="width:10%;">${product.liberia}</td>

                                    <td class="text-center" style="width:10%;">${product.santa}</td>

                                    <td class="text-center" style="width:10%;">${product.nicoya}</td>

                                    <td class="text-center" style="width:10%;">${product.upala}</td>

                                </tr>

                            </table>

                        </a>

                    `;

                    featuredBox.appendChild(productItem);

                });

            })

            .catch(error => {

                console.error('Error loading featured products:', error);

            });

    }

    /*
    function doSearchProductos() {

        document.getElementById('product_list_body').innerHTML = ''; // Limpiar productos

        document.getElementById('suggestion_page').value = 1; // Reiniciar paginación

        loadProducts(document.getElementById('inpBuscarProducto').value.toLowerCase());
    }*/

    /*
    function loadProducts(query = '') {

        if (isLoading) return;

        isLoading = true;

        let page = document.getElementById('suggestion_page').value;
        let url = `/path/to/your/api/products?page=${page}&query=${query}`;

        fetch(url)
            .then(response => response.json())
            .then(data => {

                let product_list_body = document.getElementById('product_list_body');

                if (page == 1) {
                    product_list_body.innerHTML = ''; // Limpiar si es la primera página
                }

                data.products.forEach(product => {

                    let productItem = document.createElement('div');

                    productItem.classList.add('product-item', (product_list_body.children.length % 2 === 0) ? 'odd' : 'even');

                    productItem.innerHTML = `

                        <a href="/pos/${product.id}">

                            <table class="w-100">

                                <tr>

                                    <td style="width:45%;">${product.name}</td>

                                    <td class="text-left" style="width:15%;">${product.price}</td>

                                    <td class="text-center" style="width:10%;">${product.liberia}</td>

                                    <td class="text-center" style="width:10%;">${product.santa}</td>

                                    <td class="text-center" style="width:10%;">${product.nicoya}</td>

                                    <td class="text-center" style="width:10%;">${product.upala}</td>

                                </tr>

                            </table>

                        </a>

                    `;

                    product_list_body.appendChild(productItem);

                });

                if (data.products.length < data.per_page) {

                    document.getElementById('load_more').style.display = 'none'; // Ocultar si no hay más productos

                }

                document.getElementById('suggestion_page').value = parseInt(page) + 1;

                isLoading = false;

            })

            .catch(error => {

                console.error('Error loading products:', error);

                isLoading = false;

            });

    }
    */

    function loadMoreProducts() {

        loadProducts(document.getElementById('inpBuscarProducto').value.toLowerCase());

    }

</script>



</body>

</html>

