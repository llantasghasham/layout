@if($gridIconos == 'true')
@forelse($products as $product)
    <div class="col-md-3 col-xs-4 product_list no-print" data-name="{{$product->name}}" data-sku="{{$product->sub_sku}}" data-variation="{{$product->variation ?? ''}}">
      <div class="product_box" data-variation_id="{{$product->id}}" title="{{$product->name}} @if($product->type == 'variable')- {{$product->variation}} @endif {{ '(' . $product->sub_sku . ')'}} @if(!empty($show_prices)) @lang('lang_v1.default') - @format_currency($product->selling_price) @foreach($product->group_prices as $group_price) @if(array_key_exists($group_price->price_group_id, $allowed_group_prices)) {{$allowed_group_prices[$group_price->price_group_id]}} - @format_currency($group_price->price_inc_tax) @endif @endforeach @endif">
        <div class="image-container" 
          style="background-image: url(
              @if(count($product->media) > 0)
                {{$product->media->first()->display_url}}
              @elseif(!empty($product->product_image))
                {{asset('/uploads/img/' . rawurlencode($product->product_image))}}
              @else
                {{asset('/img/default.png')}}
              @endif
            );
          background-repeat: no-repeat; background-position: center;
          background-size: contain;">
        </div>
        <div class="text_div">
          <small class="text text-muted">{{$product->name}} 
          @if($product->type == 'variable')
            - {{$product->variation}}
          @endif
          </small>
          <small class="text-muted code">
            ({{$product->sub_sku}})
          </small>
        </div>
      </div>
    </div>
  @empty
    <input type="hidden" id="no_products_found">
    <div class="col-md-12">
      <h4 class="text-center">@lang('lang_v1.no_products_to_display')</h4>
    </div>
  @endforelse
@else
  <div class="col-md-12 no-padding">
    <table id="tabProductos" style="font-size: 12px;">
      <thead style="background-color: #007bff; color: white; position: sticky; top: 0; z-index: 100;">
          <tr class="noSearch">
              <th style="width: 44%; font-weight: bold;">Producto</th>
              <th style="width: 15%; font-weight: bold;">Precio</th>

              <?php
              $sucursalNames = [];

              // 🔹 Extraer TODAS las sucursales de TODOS los productos
              if (!empty($products)) {
                  foreach ($products as $product) {
                      foreach (get_object_vars($product) as $attribute => $value) {
                          // Buscar columnas de stock
                          if (strpos($attribute, 'stock_') !== false) {
                              $sucursalId = str_replace('stock_', '', $attribute); // Extraer ID de la sucursal
                              $sucursalName = $product->{'sucursal_' . $sucursalId} ?? ''; // Obtener nombre

                              // Guardar solo la primera palabra del nombre
                              $shortName = explode(' ', trim($sucursalName))[0];

                              // Agregar a la lista si no está vacío y no es duplicado
                              if (!empty($shortName) && !isset($sucursalNames[$sucursalId])) {
                                  $sucursalNames[$sucursalId] = $shortName;
                              }
                          }
                      }
                  }
              }

              // 🔹 Imprimir encabezados de sucursales
              foreach ($sucursalNames as $shortName) {
                  echo "<th style='width: 10%; font-weight: bold;'>$shortName</th>";
              }
              ?>
          </tr>
      </thead>
      <tbody id="ordenado">
          <?php $i = 1; ?>
          @forelse($products as $product)
              <?php $bgcolor = (($i % 2) == 0) ? "aliceblue" : ""; ?>
              <tr 
                  style="background-color: <?php echo $bgcolor ?>; cursor: pointer;" 
                  class="product_box" 
                  data-variation_id="{{$product->id + 1}}" 
                  title="{{$product->pname}}">
                  
                  <td class="hidden"><?php echo $product->sku ?></td>
                  <td class="bg-light" style="width:45%;padding-top: 2px;padding-bottom: 1px;">
                      <?php echo substr($product->pname, 0, 30) ?>
                  </td>
                  <td class="bg-light text-right" style="width:15%;padding-top: 2px;padding-bottom: 1px;">
                      <?php echo number_format($product->default_sell_price, 0, ".", ",") ?>
                  </td>

                  <?php
                  // 🔹 Asegurar que las columnas de stock coincidan con los encabezados
                  foreach ($sucursalNames as $sucursalId => $sucursalName) {
                      $stockColumn = 'stock_' . $sucursalId;
                      $stockValue = $product->$stockColumn ?? 0;
                  ?>
                      <td class="bg-light text-center stock_<?php echo $sucursalId; ?>" style="width:10%;padding-top: 2px;padding-bottom: 1px;">
                        <?php echo number_format($stockValue, 0, ".", ",") ?>
                    </td>
                  <?php
                  }
                  ?>
              </tr>
          <?php $i++; ?>
          @empty
              <input type="hidden" id="no_products_found">
              <div class="col-md-12">
                  <h4 class="text-center">@lang('lang_v1.no_products_to_display')</h4>
              </div>
          @endforelse
      </tbody>
    </table>
    
    <script>
        $(document).ready(function () {
            function sortTableByStock() {
                var locationId = $('input#location_id').val(); // Obtener el ID de la ubicación
                if (!locationId) return; // Si no hay ID, salir

                var columnClass = 'stock_' + locationId; // Nombre de la columna de stock

                var tbody = $('tbody#ordenado');
                var rows = tbody.find('tr.product_box').toArray(); // Convertir a array para ordenar

                rows.sort(function (a, b) {
                    var stockA = parseFloat($(a).find('.' + columnClass).text().replace(/,/g, '')) || 0;
                    var stockB = parseFloat($(b).find('.' + columnClass).text().replace(/,/g, '')) || 0;
                    return stockB - stockA; // Orden descendente
                });

                tbody.empty().append(rows); // Insertar las filas ordenadas
            }

            sortTableByStock(); // Ejecutar la función al cargar la página

            $('input#location_id').on('change', function () {
                sortTableByStock(); // Reordenar si cambia location_id
            });
        });
    </script>
  </div>
@endif