<!-- business information here -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<?php
        if ($receipt_details->css) {
            echo '<link href="css/vendor.css" rel="stylesheet" type="text/css">';
            echo '<link href="css/app.css" rel="stylesheet" type="text/css">';
        }
		?>
        <!-- <link rel="stylesheet" href="style.css"> -->
		<style type="text/css">
			.f-8 {
				font-size: 10px !important;
			}
			@media print {
				* {
					font-size: 12px;
					font-family: 'Times New Roman';
					word-break: break-all;
				}
				.f-8 {
					font-size: 10px !important;
				}
				
			.headings{
				font-size: 16px;
				font-weight: 700;
				text-transform: uppercase;
				white-space: nowrap;
			}
			
			.sub-headings{
				font-size: 16px !important;
				font-weight: 700 !important;
			}
			
			.border-top{
				border-top: 1px solid #242424;
			}
			.border-bottom{
				border-bottom: 1px solid #242424;
			}
			
			.border-bottom-dotted{
				border-bottom: 1px dotted darkgray;
			}
			
			td.serial_number, th.serial_number{
				width: 5%;
				max-width: 5%;
			}
			
			td.description,
			th.description {
				width: 35%;
				max-width: 35%;
			}
			
			td.quantity,
			th.quantity {
				width: 15%;
				max-width: 15%;
				word-break: break-all;
			}
			td.unit_price, th.unit_price{
				width: 25%;
				max-width: 25%;
				word-break: break-all;
			}
			
			td.price,
			th.price {
				width: 20%;
				max-width: 20%;
				word-break: break-all;
			}
			
			.centered {
				text-align: center;
				align-content: center;
			}
			
			.ticket {
				width: 100%;
				max-width: 100%;
			}
			
			img {
				max-width: inherit;
				width: auto;
			}
			
				.hidden-print,
				.hidden-print * {
					display: none !important;
				}
			}
			.table-info {
				width: 100%;
			}
			.table-info tr:first-child td, .table-info tr:first-child th {
				padding-top: 8px;
			}
			.table-info th {
				text-align: left;
			}
			.table-info td {
				text-align: right;
			}
			.logo {
				float: left;
				width:35%;
				padding: 10px;
			}
			
			.text-with-image {
				float: left;
				width:65%;
			}
			.text-box {
				width: 100%;
				height: auto;
			}
			
			.textbox-info {
				clear: both;
			}
			.textbox-info p {
				margin-bottom: 0px
			}
			.flex-box {
				display: flex;
				width: 100%;
			}
			.flex-box p {
				width: 50%;
				margin-bottom: 0px;
				white-space: nowrap;
			}
			
			.table-f-12 th, .table-f-12 td {
				font-size: 12px;
				word-break: break-word;
			}
			
			.bw {
				word-break: break-word;
			}
			.divr {
				width: 49%; text-align: right
			}
			.divl {
				width: 50%; 				
				font-size: 12px !important;
				font-weight: 900 !important;
			}
			</style>

		<title>Receipt-{{$receipt_details->invoice_no}}</title>
    </head>
    <body>
        <div class="ticket">       	
        	@if(!empty($receipt_details->logo))
        		<div class="text-box centered">
        			<img style="max-height: 100px; width: auto;" src="{{$receipt_details->logo}}" alt="Logo">
        		</div>
        	@endif
        	<div class="text-box">
				<!-- Logo -->
				<p class="centered">
					<!-- Header text -->
					@if(!empty($receipt_details->header_text))
						<span class="headings">{!! $receipt_details->header_text !!}</span>
						<br/>
					@endif
					<!-- business information here -->
					@if(!empty($receipt_details->display_name))
						<span class="headings">
							{{$receipt_details->display_name}}
						</span>
						<br/>
					@endif				
					@if(!empty($receipt_details->address))
						{!! $receipt_details->address !!}
						<br/>
					@endif
					@if(!empty($receipt_details->contact))
						{!! $receipt_details->contact !!}
					@endif
					@if(!empty($receipt_details->contact) && !empty($receipt_details->website))
						, 
					@endif
					@if(!empty($receipt_details->website))
						{{ $receipt_details->website }}
					@endif
					@if(!empty($receipt_details->location_custom_fields))
						<br>{{ $receipt_details->location_custom_fields }}
					@endif

					@if(!empty($receipt_details->sub_heading_line1))
						{{ $receipt_details->sub_heading_line1 }}<br/>
					@endif
					@if(!empty($receipt_details->sub_heading_line2))
						{{ $receipt_details->sub_heading_line2 }}<br/>
					@endif
					@if(!empty($receipt_details->sub_heading_line3))
						{{ $receipt_details->sub_heading_line3 }}<br/>
					@endif
					@if(!empty($receipt_details->sub_heading_line4))
						{{ $receipt_details->sub_heading_line4 }}<br/>
					@endif		
					@if(!empty($receipt_details->sub_heading_line5))
						{{ $receipt_details->sub_heading_line5 }}<br/>
					@endif 
					@if(!empty($receipt_details->tax_info1))
						<br><b>{{ $receipt_details->tax_label1 }}</b> {{ $receipt_details->tax_info1 }}
					@endif
					@if(!empty($receipt_details->tax_info2))
						<b>{{ $receipt_details->tax_label2 }}</b> {{ $receipt_details->tax_info2 }}
					@endif
					<!-- Title of receipt -->
					@if(!empty($receipt_details->invoice_heading)) 
						<br/><span class="sub-headings">{!! $receipt_details->invoice_heading !!}</span>
					@endif
				</p>
			</div>
			<div style="border-top: 1px solid black; clear: both;">
				<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{!! $receipt_details->invoice_no_prefix !!}</strong></div>
				<div style="float: right; text-align: right;">{{$receipt_details->invoice_no}}</div>
			</div>
			<div style="clear: both;">
				<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{!! $receipt_details->date_label !!}</strong></div>
				<div style="float: right; text-align: right;">{{$receipt_details->invoice_date}}</div>
				<!-- </div>
				por Hernán
				<div style="clear: both;"> -->
				<?php
					if (!empty($receipt_details->value_numero)) {
						echo '<div style="width: 30%;text-align: left; font-size: 12px; font-weight:500" style="float: left;"><strong>'.$receipt_details->label_numero.':</strong></div>
							<div style="width: 70%;text-align: right" style="float: right;>'.$receipt_details->value_numero.'</div>';
					}
					if (!empty($receipt_details->value_clave)) {
						echo '<div style="width: 30%;text-align:left; font-size: 12px !important; font-weight:500 !important" style="float: left;"><strong>'.$receipt_details->label_clave.':</strong></div>
									<div style="width: 70%;text-align:right" style="float: right;>'.$receipt_details->value_clave.'</div>';
					}
				?>						
			</div>
			<!-- fin por Hernán-->
			
			@if(!empty($receipt_details->due_date_label))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->due_date_label}}</strong></div>
					<div style="float: right; text-align: right;">{{$receipt_details->due_date ?? ''}}</div>
				</div>
			@endif

			@if(!empty($receipt_details->sales_person_label))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->sales_person_label}}</strong></div>				
					<div style="float: right; text-align: right;">{{$receipt_details->sales_person}}</div>
				</div>
			@endif

			@if(!empty($receipt_details->commission_agent_label))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->commission_agent_label}}</strong></div>				
					<div style="float: right; text-align: right;">{{$receipt_details->commission_agent}}</div>
				</div>
			@endif

			@if(!empty($receipt_details->brand_label) || !empty($receipt_details->repair_brand))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->brand_label}}</strong></div>				
					<div style="float: right; text-align: right;">{{$receipt_details->repair_brand}}</div>
				</div>
			@endif

			@if(!empty($receipt_details->device_label) || !empty($receipt_details->repair_device))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->device_label}}</strong></div>				
					<div style="float: right; text-align: right;">{{$receipt_details->repair_device}}</div>
				</div>
			@endif
			
			@if(!empty($receipt_details->model_no_label) || !empty($receipt_details->repair_model_no))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->model_no_label}}</strong></div>				
					<div style="float: right; text-align: right;">{{$receipt_details->repair_model_no}}</div>
				</div>
			@endif
			
			@if(!empty($receipt_details->serial_no_label) || !empty($receipt_details->repair_serial_no))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>{{$receipt_details->serial_no_label}}</strong></div>				
					<div style="float: right; text-align: right;">{{$receipt_details->repair_serial_no}}</div>
				</div>
			@endif

			@if(!empty($receipt_details->repair_status_label) || !empty($receipt_details->repair_status))
				<div style="clear: both;">
					<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>
						{!! $receipt_details->repair_status_label !!}
					</strong></div>
					<div style="float: right; text-align: right;">
						{{$receipt_details->repair_status}}
					</div>
				</div>
        	@endif

        	@if(!empty($receipt_details->repair_warranty_label) || !empty($receipt_details->repair_warranty))
	        	<div style="clear: both;">
	        		<div style="float: left; font-size: 12px !important; font-weight: 900 !important;"><strong>
	        			{!! $receipt_details->repair_warranty_label !!}
	        		</strong></div>
	        		<div style="float: right; text-align: right;">
	        			{{$receipt_details->repair_warranty}}
					</div>
	        	</div>
        	@endif

        	<!-- Waiter info -->
			@if(!empty($receipt_details->service_staff_label) || !empty($receipt_details->service_staff))
	        	<div style="clear: both;">
	        		<div style="width: 49%; float: left;"><strong>
	        			{!! $receipt_details->service_staff_label !!}
	        		</strong></div>
	        		<div style="width: 49%; float: right;">
	        			{{$receipt_details->service_staff}}
					</div>
	        	</div>
	        @endif

	        @if(!empty($receipt_details->table_label) || !empty($receipt_details->table))
	        	<div style="clear: both;">
	        		<div style="width: 49%; float: left;"><strong>
	        			@if(!empty($receipt_details->table_label))
							<b>{!! $receipt_details->table_label !!}</b>
						@endif
	        		</strong></div>
	        		<div style="width: 49%; float: right;">
	        			{{$receipt_details->table}}
					</div>
	        	</div>
	        @endif

	        <!-- customer info -->
	        <div style="clear: both;">
				<div style="text-align: left; width: 100%; font-size: 12px !important; font-weight: 900 !important; margin-bottom: 3px;">
					<strong>{{$receipt_details->customer_label ?? ''}}</strong>
				</div>
			
				@if(!empty($receipt_details->customer_info))
					<div style="text-align: left; width: 100%; word-break: break-word;">
						{!! $receipt_details->customer_info !!}
					</div>
				@endif
			</div>
			
			
			@if(!empty($receipt_details->client_id_label))
				<div style="clear: both;">
					<div style="width: 49%; float: left;"><strong>
						{{ $receipt_details->client_id_label }}
					</strong></div>
					<div style="width: 49%; float: right;">
						{{ $receipt_details->client_id }}
					</div>
				</div>
			@endif
			
			@if(!empty($receipt_details->customer_tax_label))
				<div style="clear: both;">
					<div style="width: 49%; float: left;"><strong>
						{{ $receipt_details->customer_tax_label }}
						</strong>
					</div>
					<div style="width: 49%; float: right;">
						{{ $receipt_details->customer_tax_number }}
					</div>
				</div>
			@endif

			@if(!empty($receipt_details->customer_custom_fields))
				<div style="clear: both;">
					<p class="centered">
						{!! $receipt_details->customer_custom_fields !!}
					</p>
				</div>
			@endif
			
			@if(!empty($receipt_details->customer_rp_label))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						{{ $receipt_details->customer_rp_label }}
					</strong></p>
					<p style="float: right;">
						{{ $receipt_details->customer_total_rp }}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->shipping_custom_field_1_label))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						{!!$receipt_details->shipping_custom_field_1_label!!} 
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->shipping_custom_field_1_value ?? ''!!}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->shipping_custom_field_2_label))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						{!!$receipt_details->shipping_custom_field_2_label!!} 
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->shipping_custom_field_2_value ?? ''!!}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->shipping_custom_field_3_label))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						{!!$receipt_details->shipping_custom_field_3_label!!} 
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->shipping_custom_field_3_value ?? ''!!}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->shipping_custom_field_4_label))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						{!!$receipt_details->shipping_custom_field_4_label!!} 
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->shipping_custom_field_4_value ?? ''!!}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->shipping_custom_field_5_label))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						{!!$receipt_details->shipping_custom_field_5_label!!} 
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->shipping_custom_field_5_value ?? ''!!}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->sale_orders_invoice_no))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						@lang('restaurant.order_no')
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->sale_orders_invoice_no ?? ''!!}
					</p>
				</div>
			@endif

			@if(!empty($receipt_details->sale_orders_invoice_date))
				<div style="clear: both;">
					<p style="float: left;"><strong>
						@lang('lang_v1.order_dates')
					</strong></p>
					<p style="float: right;">
						{!!$receipt_details->sale_orders_invoice_date ?? ''!!}
					</p>
				</div>
			@endif

			<table style="margin-top: 25px; width: 100%; border-bottom: 1px solid black; font-size: 12px; margin-bottom: 10px;">
				<thead style="border-bottom: 1px dotted black;">
					<tr>
						<th class="serial_number" style="width: 2%;">#</th>
						<th class="description" style="width: 30%; text-align: center;">{{$receipt_details->table_product_label}}</th>
						<th class="quantity" style="width: 8%; text-align: right;">{{$receipt_details->table_qty_label}}</th>
						@if(empty($receipt_details->hide_price))
							<th class="unit_price" style="text-align: right;">{{$receipt_details->table_unit_price_label}}</th>
							@if(!empty($receipt_details->item_discount_label))
								<th style="width: 15%; text-align: right;">{{$receipt_details->item_discount_label}}</th>
							@endif
							<th class="price" style="text-align: right;">{{$receipt_details->table_subtotal_label}}</th>
						@endif
					</tr>
				</thead>
				<tbody>
					@forelse($receipt_details->lines as $line)
						<tr>
							<td class="serial_number" style="vertical-align: top;">{{$loop->iteration}}</td>
							<td class="description" style="text-align: center;">
								<?php
									$product_variation = "";
									if (isset($line['product_variation'])) {
										$product_variation = $line['product_variation'];
									}
								?>
								{{$line['name']}} {{$product_variation}} {{$line['variation']}}
								@if(!empty($line['sub_sku'])), {{$line['sub_sku']}} @endif
								@if(!empty($line['brand'])), {{$line['brand']}} @endif
								@if(!empty($line['cat_code'])), {{$line['cat_code']}} @endif
								@if(!empty($line['product_custom_fields'])), {{$line['product_custom_fields']}} @endif
								@if(!empty($line['sell_line_note']))
									<br>
									<span style="font-size: 8px;">{{$line['sell_line_note']}}</span>
								@endif
								@if(!empty($line['lot_number']))<br> {{$line['lot_number_label']}}: {{$line['lot_number']}} @endif
								@if(!empty($line['product_expiry'])), {{$line['product_expiry_label']}}: {{$line['product_expiry']}} @endif
								@if(!empty($line['warranty_name']))
									<br>
									<small>{{$line['warranty_name']}}</small>
								@endif
								@if(!empty($line['warranty_exp_date']))
									<small>- {{@format_date($line['warranty_exp_date'])}}</small>
								@endif
								@if(!empty($line['warranty_description']))
									<small>{{$line['warranty_description'] ?? ''}}</small>
								@endif
							</td>
							<td class="quantity" style="text-align: right;">{{$line['quantity']}} {{$line['units']}}</td>
							@if(empty($receipt_details->hide_price))
								<td class="unit_price" style="text-align: right;">{{$line['unit_price_before_discount']}}</td>
								@if(!empty($receipt_details->item_discount_label))
									<td style="text-align: right;">{{$line['line_discount'] ?? '0.00'}}</td>
								@endif
								<td class="price" style="text-align: right;">{{$line['line_total']}}</td>
							@endif
						</tr>
						@if(!empty($line['modifiers']))
							@foreach($line['modifiers'] as $modifier)
								<tr>
									<td>&nbsp;</td>
									<td>
										{{$modifier['name']}} {{$modifier['variation']}} 
										@if(!empty($modifier['sub_sku'])), {{$modifier['sub_sku']}} @endif
										@if(!empty($modifier['cat_code'])), {{$modifier['cat_code']}} @endif
										@if(!empty($modifier['sell_line_note']))({{$modifier['sell_line_note']}}) @endif
									</td>
									<td style="text-align: right;">{{$modifier['quantity']}} {{$modifier['units']}}</td>
									@if(empty($receipt_details->hide_price))
										<td style="text-align: right;">{{$modifier['unit_price_inc_tax']}}</td>
										@if(!empty($receipt_details->item_discount_label))
											<td style="text-align: right;">0.00</td>
										@endif
										<td style="text-align: right;">{{$modifier['line_total']}}</td>
									@endif
								</tr>
							@endforeach
						@endif
					@endforeach
					<tr>
						<td @if(!empty($receipt_details->item_discount_label)) colspan="6" @else colspan="5" @endif>&nbsp;</td>
					</tr>
				</tbody>
			</table>
			
			
			@if(!empty($receipt_details->total_quantity_label))
				<div style="width: 100%; overflow: hidden;">
					<div style="width: 49%; text-align: right; float: left;">
						{!! $receipt_details->total_quantity_label !!}
					</div>
					<div style="width: 49%; text-align: right; float: right;">
						{{$receipt_details->total_quantity}}
					</div>
				</div>
			@endif

			@if(empty($receipt_details->hide_price))
				<table style="width: 100%;">
					<tr>
						<td style="width: 49%; text-align: right;" class="sub-headings">{!! $receipt_details->subtotal_label !!}</td>
						<td style="width: 49%; text-align: right;" class="sub-headings">{{$receipt_details->subtotal}}</td>
					</tr>

					@if(!empty($receipt_details->shipping_charges))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->shipping_charges_label !!}</td>
							<td style="text-align: right;">{{$receipt_details->shipping_charges}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->packing_charge))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->packing_charge_label !!}</td>
							<td style="text-align: right;">{{$receipt_details->packing_charge}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->discount))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->discount_label !!}</td>
							<td style="text-align: right;">(-) {{$receipt_details->discount}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->total_line_discount))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->line_discount_label !!}</td>
							<td style="text-align: right;">(-) {{$receipt_details->total_line_discount}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->reward_point_label))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->reward_point_label !!}</td>
							<td style="text-align: right;">(-) {{$receipt_details->reward_point_amount}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->tax))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->tax_label !!}</td>
							<td style="text-align: right;">(+) {{$receipt_details->tax}}</td>
						</tr>
					@endif

					@if($receipt_details->round_off_amount > 0)
						<tr>
							<td style="text-align: right;">{!! $receipt_details->round_off_label !!}</td>
							<td style="text-align: right;">{{$receipt_details->round_off}}</td>
						</tr>
					@endif

					<tr>
						<td style="text-align: right;" class="sub-headings">{!! $receipt_details->total_label !!}</td>
						<td style="text-align: right;" class="sub-headings">{{$receipt_details->total}}</td>
					</tr>

					@if(!empty($receipt_details->total_in_words))
						<tr>
							<td colspan="2" style="text-align: right;"><small>({{$receipt_details->total_in_words}})</small></td>
						</tr>
					@endif

					@if(!empty($receipt_details->payments))
						@foreach($receipt_details->payments as $payment)
							<tr>
								<td style="text-align: right;">{{$payment['method']}} ({{$payment['date']}})</td>
								<td style="text-align: right;">{{$payment['amount']}}</td>
							</tr>
						@endforeach
					@endif

					@if(!empty($receipt_details->total_paid))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->total_paid_label !!}</td>
							<td style="text-align: right;">{{$receipt_details->total_paid}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->total_due))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->total_due_label !!}</td>
							<td style="text-align: right;">{{$receipt_details->total_due}}</td>
						</tr>
					@endif

					@if(!empty($receipt_details->all_due))
						<tr>
							<td style="text-align: right;">{!! $receipt_details->all_bal_label !!}</td>
							<td style="text-align: right;">{{$receipt_details->all_due}}</td>
						</tr>
					@endif
				</table>
			@endif


            <div style="border-bottom: 1px solid #000; width: 100%;">&nbsp;</div>
			@if(empty($receipt_details->hide_price))
				<!-- Tax -->
				@if(!empty($receipt_details->taxes))
					<table style="border-bottom: 1px solid #000; width: 100%; font-size: 12px;">
						@foreach($receipt_details->taxes as $key => $val)
							<tr>
								<td style="text-align: left;">{{$key}}</td>
								<td style="text-align: right;">{{$val}}</td>
							</tr>
						@endforeach
					</table>
				@endif
			@endif



            @if(!empty($receipt_details->additional_notes))
				<p style="text-align: center;">
					{!! nl2br($receipt_details->additional_notes) !!}
				</p>
			@endif

			<div style="width: 100%; text-align: center;"> 
				{{-- Barcode --}}
				@if($receipt_details->show_barcode)
					<br/>
					<img style="display: block; margin: 0 auto;" src="data:image/png;base64,{{DNS1D::getBarcodePNG($receipt_details->invoice_no, 'C128', 2,30,array(39, 48, 54), true)}}">
				@endif

				@if($receipt_details->show_qr_code && !empty($receipt_details->qr_code_details))
					@php
						$qr_code_text = implode(', ', $receipt_details->qr_code_details);
					@endphp
					<img style="display: block; margin: 5px auto;" src="data:image/png;base64,{{DNS2D::getBarcodePNG($qr_code_text, 'QRCODE')}}">
				@endif
			</div>

			@if(!empty($receipt_details->footer_text))
				<p style="text-align: center;">
					{!! $receipt_details->footer_text !!}
				</p>
			@endif
        </div>
        <!-- <button id="btnPrint" class="hidden-print">Print</button>
        <script src="script.js"></script> -->
    </body>
</html>