<div style="font-size: 9px " class="modal-dialog modal-xl no-print" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <h4 class="modal-title" id="modalTitle"> XML de venta </h4>
    </div>
<div class="modal-body"> 
    <div class="row">
      <?php
          $xmls = new SimpleXMLElement($sell->xml);
      // https://www.php.net/manual/es/simplexml.examples-basic.php
      ?>
          <table class="table table-bordered">
            <tr>
              <td colspan="14">
                <?php echo "<strong>Clave:</strong> ".$xmls[0]->Clave?>
              </td>
            </tr>
            <tr>
              <td colspan="14">
                <?php echo "<strong>Número Consecutivo:</strong> ".$xmls[0]->NumeroConsecutivo?>
              </td>
            </tr>
            <tr>
              <td colspan="14">
                <?php echo "<strong>Fecha Emision:</strong> ".$xmls[0]->FechaEmision?>
              </td>
            </tr>
            <tr>
              <td colspan="6">
                <?php
              echo "<strong>Emisor</strong>"."<br>";
      echo "<strong>Nombre:</strong> ".$xmls[0]->Emisor->Nombre."<br>";
      echo "<strong>Identificacion</strong>"."<br>";
      echo "<strong>Tipo:</strong> ".$xmls[0]->Emisor->Identificacion->Tipo."<br>";
      echo "<strong>Número:</strong> ".$xmls[0]->Emisor->Identificacion->Numero."<br>";
      echo "<strong>Ubicacion</strong>"."<br>";
      echo "<strong>Provincia:</strong> ".$xmls[0]->Emisor->Ubicacion->Provincia."<br>";
      echo "<strong>Canton:</strong> ".$xmls[0]->Emisor->Ubicacion->Canton."<br>";
      echo "<strong>Distrito:</strong> ".$xmls[0]->Emisor->Ubicacion->Distrito."<br>";
      echo "<strong>Barrio:</strong> ".$xmls[0]->Emisor->Ubicacion->Barrio."<br>";
      echo "<strong>Otras Señas:</strong> ".$xmls[0]->Emisor->Ubicacion->OtrasSenas."<br>";
      echo "<strong>Telefono</strong>"."<br>";
      echo "<strong>Código Pais:</strong> ".$xmls[0]->Emisor->Telefono->CodigoPais."<br>";
      echo "<strong>Número Telefono:</strong> ".$xmls[0]->Emisor->Telefono->NumTelefono."<br>";
      echo "<strong>Correo Eléctronico:</strong> ".$xmls[0]->Emisor->CorreoElectronico;
      ?>
              </td>
              <td colspan="5">
                <?php
          echo "<strong>Receptor</strong>"."<br>";
      echo "<strong>Nombre:</strong> ".$xmls[0]->Receptor->Nombre."<br>";
      echo "<strong>Identificacion</strong>"."<br>";
      echo "<strong>Tipo:</strong> ".$xmls[0]->Receptor->Identificacion->Tipo."<br>";
      echo "<strong>Numero:</strong> ".$xmls[0]->Receptor->Identificacion->Numero."<br>";
      echo "<strong>Correo Eléctronico:</strong> ".$xmls[0]->Receptor->CorreoElectronico;
      ?>
              </td>
              <td colspan="4">
                <?php
        echo "<strong>Condición Venta:</strong> ".$xmls[0]->CondicionVenta."<br>";
      echo "<strong>Plazo Credito:</strong> ".$xmls[0]->PlazoCredito."<br>";
      echo "<strong>Medio Pago:</strong> ".$xmls[0]->MedioPago;
      ?>
              </td>
            </tr>
          <tr>
            <th colspan="14">
                Detalles de productos
            </th>
        </tr>
        <tr>
          <th style="size: 8px">Linea</th><th style="size: 8px">Código</th>
          <th style="size: 8px">Cantidad</th><th style="size: 8px">Unidad<br>de Medida</th>
          <th >Nombre de Producto</th><th style="size: 8px">Precio<br>Unitario</th>
          <th style="size: 8px">Total</th><th style="size: 8px">Descuento</th>
          <th >Naturaleza del descuento</th><th style="size: 8px">SubTotal</th>
          <th colspan="3">Impusto<br>Código | Tarifa | Monto</th><th style="size: 8px">Total linea</th>
        </tr>
        <?php
            foreach ($xmls[0]->DetalleServicio->LineaDetalle as $LineaDetalle) {
                echo "<tr border='1'>";
                echo "<td border='1'>".trim($LineaDetalle->NumeroLinea)."</td> ";
                echo "<td border='1'>".trim($LineaDetalle->Codigo->Tipo)."-".trim($LineaDetalle->Codigo->Codigo)."</td> ";
                echo "<td>".trim($LineaDetalle->Cantidad)."</td>";
                echo "<td>".trim($LineaDetalle->UnidadMedida)."</td>";
                echo "<td>".trim($LineaDetalle->Detalle)."</td>";
                echo "<td>".trim($LineaDetalle->PrecioUnitario)."</td>";
                echo "<td>".trim($LineaDetalle->MontoTotal)."</td>";
                echo "<td>".trim($LineaDetalle->MontoDescuento)."</td>";
                echo "<td>".trim($LineaDetalle->NaturalezaDescuento)."</td>";
                echo "<td>".trim($LineaDetalle->SubTotal)."</td>";

                echo "<td>".trim($LineaDetalle->Impuesto->Codigo)."</td>";
                echo "<td>".trim($LineaDetalle->Impuesto->Tarifa)."</td>";
                echo "<td>".trim($LineaDetalle->Impuesto->Monto)."</td>";

                echo "<td>".trim($LineaDetalle->MontoTotalLinea)."</td>";

                echo "<tr>";
            }
      ?>
          <tr>
            <?php echo "<td colspan='3'><strong>Código de Moneda:</strong> ".trim($xmls[0]->ResumenFactura->CodigoMoneda)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Cambio:</strong> ".trim($xmls[0]->ResumenFactura->TipoCambio)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Servicio Gravados:</strong> ".trim($xmls[0]->ResumenFactura->TotalServGravados)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Servicio Exentos:</strong> ".trim($xmls[0]->ResumenFactura->TotalServExentos)."</td>"; ?>
          </tr>
          <tr>
            <?php echo "<td colspan='3'><strong>Total de Mercancias Gravadas:</strong> ".trim($xmls[0]->ResumenFactura->TotalMercanciasGravadas)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Mercancias Exentas:</strong> ".trim($xmls[0]->ResumenFactura->TotalMercanciasExentas)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total Gravado:</strong> ".trim($xmls[0]->ResumenFactura->TotalGravado)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total Exento:</strong> ".trim($xmls[0]->ResumenFactura->TotalExento)."</td>"; ?>
          </tr>
          <tr>
            <?php echo "<td colspan='3'><strong>Total de Venta:</strong> ".trim($xmls[0]->ResumenFactura->TotalVenta)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Descuentos:</strong> ".trim($xmls[0]->ResumenFactura->TotalDescuentos)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Venta Neta:</strong> ".trim($xmls[0]->ResumenFactura->TotalVentaNeta)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Impuesto:</strong> ".trim($xmls[0]->ResumenFactura->TotalImpuesto)."</td>"; ?>
          </tr>
          <tr>
            <?php echo "<td colspan='3'><strong>Total de Comprobante:</strong> ".trim($xmls[0]->ResumenFactura->TotalComprobante)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Total de Descuentos:</strong> ".trim($xmls[0]->Normativa->NumeroResolucion)."</td>"; ?>
            <?php echo "<td colspan='3'><strong>Fecha de Resolucion:</strong> ".trim($xmls[0]->Normativa->FechaResolucion)."</td>"; ?>
          </tr>
        </table>
    </div>
  </div>
</div>
