<div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
		<div class="modal-header">
		    <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		    <h4 class="modal-title" id="modalTitle">ENVIAR FACTURA POR CORREO Y WHATSAPP</h4>
	    </div>
        <div class="modal-body">
            <!-- FORMULARIOS -->
            <div class="card mb-4 shadow-sm">
                <!-- ENVIO POR CORREO-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="emailForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="email">{{ __('Correo(s) del Cliente') }}:</label>
                                <input type="text" id="email" name="email" class="form-control" placeholder="correo1@example.com, correo2@example.com">
                            </div>
                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-primary w-100" onclick="enviarPDFEmail()">{{ __('Enviar Correo') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- ENVIO POR WHATSAPP-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="whatsappForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="cellphone">{{ __('Numero de Telefono') }}:</label>
                                <input type="text" id="cellphone" name="cellphone" class="form-control" placeholder="51 999999999">
                            </div>

                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-success w-100" onclick="enviarPDFWhatsApp()">{{ __('Enviar WhatsApp') }}</button>
                            </div>
                        </div>
                    </form>
                </div>  
            </div>
        </div>
        <hr>
	    <div id="sendInvoice" style="font-family: DejaVu Sans; font-size: 10px;">
            <div class="row d-flex align-items-center" style="text-align: center; margin: auto;">
                <div class="col-sm-12">
                    {!! $receipt['html_content'] !!}
                </div>
            </div>
      	</div>
      	<div class="modal-footer">
	      	<button type="button" class="btn btn-default no-print" data-dismiss="modal">@lang( 'messages.close' )</button>
	    </div>
	</div>
</div>
<script>
    var voucher = @json($voucher);
    function enviarPDFEmail() {
        const div = document.getElementById('sendInvoice');
        const htmlContent = div.outerHTML;

        let url = !voucher || Object.keys(voucher).length === 0
            ? "{{ route('sellsInvoice.send-invoice-email') }}" // Ruta normal
            : "{{ route('vouchers.send-voucher-email') }}"; // Ruta alternativa si hay voucher

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                emails: document.getElementById('email').value,
                htmlContent: htmlContent,
                voucher: voucher
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error);
            alert(data.message || data.error);
        })
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }

    function enviarPDFWhatsApp() {    
        const div = document.getElementById('sendInvoice');
        const htmlContent = div.outerHTML;

        // Definir la ruta según si el voucher está vacío o no
        let url = !voucher || Object.keys(voucher).length === 0
            ? "{{ route('sellsInvoice.send-voucher-wsp') }}" // Ruta normal si no hay voucher
            : "{{ route('vouchers.send-voucher-wsp') }}"; // Ruta alternativa si hay voucher

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                phone: document.getElementById('cellphone').value,
                htmlContent: htmlContent,
                voucher: voucher
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error);
            alert(data.message || data.error);
        })
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }

</script>
