@extends('layouts.app') 
@section('title','Voucher Electrónicos')
  
@section('content') 
    <!-- Content Header (Page header) --> 
    <section class="content-header">
        <h1> Voucher Electrónicos </h1>
    </section>
    @component('components.filters', ['title' => __('report.filters')])
        @include('voucher_electronic.partials.voucher_list_filters')
    @endcomponent 
    <!-- Main content -->
    <section class="content">
        @can('admin.view') <!-- Verificar si el usuario tiene el permiso de administrador -->
        @component('components.widget', ['class' => 'box-primary', 'title' => "Todos los Comprobantes"])
            <div id="contenido" name="contenido">
            @php    
                //echo $text_pagina;
            @endphp
            </div>
        @endcomponent
        @endcan
        <!-- /.content -->
        <div class="modal fade payment_modal" tabindex="-1" role="dialog" 
            aria-labelledby="gridSystemModalLabel">
        </div>

        <div class="modal fade edit_payment_modal" tabindex="-1" role="dialog" 
            aria-labelledby="gridSystemModalLabel">            
        </div>
        <!-- This will be printed -->
        <!-- <section class="invoice print_section" id="receipt_section"> -->
    </section> 
    <!-- /.content -->
@endsection

@section('javascript')
    <script src="{{ asset('js/main.js?v=' . $asset_v) }}"></script> 
    <script src="{{ asset('js/voucher_electronic.js?v=' . $asset_v) }}"></script> <!-- . $asset_v -->
                                                
    <script type="text/javascript">
        $(document).ready( function(){
            //Date range as a button
            $('#voucher_date_range').daterangepicker(
                dateRangeSettings,
                function (start, end) {
                    $('#voucher_date_range').val(start.format(moment_date_format) + ' ~ ' + end.format(moment_date_format));
                }
            );
            $('#voucher_date_range').on('cancel.daterangepicker', function(ev, picker) {
                $('#voucher_date_range').val('');
            });
        }); 
    </script>
@endsection
