<div class="col-md-3">
    <div class="form-group">
        {!! Form::label('voucher_location_id',  __('purchase.business_location') . ':') !!}
        {!! Form::select('voucher_location_id', $business_locations, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all') ]); !!}
    </div>
</div>
<div class="col-md-3">
    <div class="form-group">
        {!! Form::label('voucher_customer_id',  __('contact.customer') . ':') !!}
        {!! Form::select('voucher_customer_id', $customers, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); !!}
    </div>
</div>
<div class="col-md-3">
    <div class="form-group">
        {!! Form::label('voucher_date_range', __('report.date_range') . ':') !!}
        {!! Form::text('voucher_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']); !!}
    </div>
</div>
<div class="col-md-3">
    <div class="form-group">
        {!! Form::label('voucher_statuses_id', 'Estatus del comprobante:') !!}
        {!! Form::select('voucher_statuses_id', $estadoCompro, null, ['class' => 'form-control select2', 'style' => 'width:100%', 'placeholder' => __('lang_v1.all')]); !!}
    </div>
</div>





