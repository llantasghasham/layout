@extends('layouts.app')

@section('title', 'Detalle del Comprobante')

@section('content')
<section class="content-header">
    <h1>Detalle del Comprobante</h1>
</section>

<section class="content">
    <div class="box box-primary">
        <div class="box-body">
            <!-- Muestra los detalles del comprobante aquí -->
            <p>Transacción: {{ $voucher->transaction_id }}</p>
            <p>Comprobante: {{ $voucher->NumeroConsecutivo }}</p>
            <p>Monto Total: {{ $voucher->TotalFactura }}</p>
            <!-- Agrega más detalles según sea necesario -->
        </div>
    </div>
</section>
@endsection
