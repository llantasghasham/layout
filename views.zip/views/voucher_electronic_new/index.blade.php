@extends('layouts.app')
@section('title', __('lang_v1.vouchers_electronicos_nuevo'))
@section('content')

    <section class="content">
        <div class="container">
            <h1 class="mb-4 text-center">Vouchers Electrónicos</h1>
            <!-- Filtros de búsqueda -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white text-center">

                    <h5 class="mb-0">Filtros de Búsqueda</h5>

                </div>

                <div class="card-body bg-light">

                    <form id="filter_form">

                        <div class="row">

                            <div class="col-md-2 mb-3">

                                <label for="filter_location">{{ __('Sucursal') }}:</label>

                                <select id="filter_location" class="form-control select2">

                                    <option value="">{{ __('Todos') }}</option>

                                    @foreach($locations as $location)

                                        <option value="{{ $location->city }}">{{ $location->city }}</option>

                                    @endforeach

                                </select>

                            </div>

                            <div class="col-md-2 mb-3">

                                <label for="filter_company">{{ __('Empresa') }}:</label>

                                <select id="filter_company" class="form-control select2">

                                    <option value="">{{ __('Todas') }}</option>

                                    @foreach($locations as $company)

                                        <option value="{{ $company->name }}">{{ $company->name }}</option>

                                    @endforeach

                                </select>

                            </div>



                            <div class="col-md-2 mb-3">

                                <label for="filter_document_type">{{ __('Tipo de Documento') }}:</label>

                                <select id="filter_document_type" class="form-control select2">

                                    <option value="">{{ __('Todos') }}</option>

                                    @foreach($document_types as $key => $type)

                                        <option value="{{ $key }}">{{ $type }}</option>

                                    @endforeach

                                </select>

                            </div>



                            <div class="col-md-2 mb-3">

                                <label for="filter_status">{{ __('Comprobante') }}:</label>

                                <select id="filter_status" class="form-control select2">

                                    <option value="">{{ __('Todos') }}</option>

                                    <option value="1">{{ __('Aceptado') }}</option>

                                    <option value="2">{{ __('Rechazado') }}</option>

                                    <option value="3">{{ __('Pendiente') }}</option>

                                </select>

                            </div>

                            <div class="col-md-2 mb-3">

                                <label for="filter_date_range">{{ __('Rango de fechas') }}:</label>

                                <div class="input-group">

                                    <button type="button" class="btn btn-outline-secondary dropdown-toggle w-100"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                        <i class="fa fa-calendar"></i> Filtrar por fecha

                                    </button>

                                    <div class="dropdown-menu p-3" style="min-width: 300px;">

                                        <div class="dropdown-item" id="today">Hoy</div>

                                        <div class="dropdown-item" id="yesterday">Ayer</div>

                                        <div class="dropdown-item" id="last_7_days">Últimos 7 días</div>

                                        <div class="dropdown-item" id="last_30_days">Últimos 30 días</div>

                                        <div class="dropdown-item" id="this_month">Este mes</div>

                                        <div class="dropdown-item" id="last_month">El mes pasado</div>

                                        <div class="dropdown-item" id="custom_range">Rango personalizado</div>

                                    </div>

                                    <input type="hidden" id="filter_date_range" class="form-control"
                                        placeholder="Seleccione un rango de fechas">

                                </div>

                            </div>

                            <div class="col-md-2 mb-3">

                                <label>&nbsp;</label>
                                <!-- Esto agrega espacio vacío para alinear el botón con los otros campos -->

                                <button type="button" id="reset_filters" class="btn btn-secondary w-100">

                                    {{ __('Restablecer Filtros') }}

                                </button>

                            </div>

                        </div>

                    </form>

                </div>

            </div>

        </div>

        <!-- Envío de Listado -->

        <div class="card mb-4 shadow-sm">

            <div class="card-header bg-primary text-white">

                <h5 class="mb-0"><i class="fa fa-envelope"></i> {{ __('Envío de Listado') }}</h5>

            </div>

            <div class="card-body" style="padding: 10px">

                <form action="{{ route('vouchers.send-list') }}" method="POST">

                    @csrf

                    <div class="row">

                        <div class="col-md-3">

                            <label for="emails">{{ __('Correos del Contador') }}:</label>

                            <input type="text" id="emails" name="emails" class="form-control"
                                placeholder="correo1@example.com, correo2@example.com">

                            <div class="form-check" style="margin-top: 5px">
                                <input class="form-check-input" type="checkbox" value="true" id="flexCheckDefault"
                                    name="miemail">
                                <label class="form-check-label" for="flexCheckDefault">
                                    Enviar a mi correo
                                </label>
                            </div>

                        </div>

                        <div class="col-md-3">

                            <label for="month">{{ __('Mes') }}:</label>

                            <select id="month" name="month" class="form-control">

                                <option value="">{{ __('Selecciona un Mes') }}</option>

                                @foreach(range(1, 12) as $m)

                                    <option value="{{ $m }}">{{ \Carbon\Carbon::create()->month($m)->translatedFormat('F') }}
                                    </option>

                                @endforeach

                            </select>

                        </div>

                        <div class="col-md-3">
                            <label for="year">{{ __('Año') }}:</label>

                            <select id="year" name="year" class="form-control">

                                <option value="">{{ __('Selecciona un Año') }}</option>

                                @foreach(range(2000, 2050) as $y)

                                    <option value="{{ $y }}">{{ $y }}</option>

                                @endforeach

                            </select>
                        </div>

                        <div class="col-md-3" style="margin-top: 22px">

                            <button type="submit" class="btn btn-primary w-100">{{ __('Enviar Listado') }}</button>

                        </div>

                    </div>
                </form>

                <div class="card-body" style="padding: 10px">
                    <form action="{{ route('vouchers.send-list-wsp') }}" method="POST">
                        @csrf

                        <div class="row">
                            <div class="col-md-3">
                                <label for="phone">{{ __('Numero de Telefono') }}:</label>
                                <input type="text" id="phone" name="phone" class="form-control" placeholder="51 999999999">
                            </div>

                            <div class="col-md-3">
                                <label for="month">{{ __('Mes') }}:</label>

                                <select id="month" name="month" class="form-control">

                                    <option value="">{{ __('Selecciona un Mes') }}</option>

                                    @foreach(range(1, 12) as $m)

                                        <option value="{{ $m }}">{{ \Carbon\Carbon::create()->month($m)->translatedFormat('F') }}
                                        </option>

                                    @endforeach

                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="year">{{ __('Año') }}:</label>

                                <select id="year" name="year" class="form-control">

                                    <option value="">{{ __('Selecciona un Año') }}</option>

                                    @foreach(range(2000, 2050) as $y)

                                        <option value="{{ $y }}">{{ $y }}</option>

                                    @endforeach

                                </select>
                            </div>

                            <div class="col-md-3" style="margin-top: 22px">

                                <button type="submit" class="btn btn-success w-100">{{ __('Enviar WhatsApp') }}</button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabla -->
            <table id="voucher_table" class="table table-striped">

                <thead>

                    <tr>

                        <th>{{ __('Acciones') }}</th>

                        <th>{{ __('Sucursal') }}</th>

                        <th>{{ __('Empresa') }}</th>

                        <th>Número Consecutivo</th>

                        <th>{{ __('Total Factura') }}</th>

                        <th>{{ __('Impuesto Total') }}</th>

                        <th>{{ __('Fecha') }}</th>

                        <th>{{ __('Tipo de Documento') }}</th>

                        <th>{{ __('Estado') }}</th>

                    </tr>

                </thead>

                <tbody>

                    <!-- Datos de la tabla -->

                </tbody>

            </table>
            
        </div>

        <div class="modal fade" id="view_voucher_modal" tabindex="-1" role="dialog" 
            aria-labelledby="gridSystemModalLabel">
        </div>
    </section>

@endsection



@section('javascript')
<link rel="stylesheet" href="{{ asset('css/custom.css') }}">

<script type="text/javascript">

    $(document).ready(function () {

        $(document).on('click', 'a.view-voucher', function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('href'),
            dataType: 'html',
            success: function(result) {
                $('#view_voucher_modal')
                    .html(result)
                    .modal('show');
                __currency_convert_recursively($('#view_voucher_modal'));
            },
        });
    });


        // Configuración de Ajax para incluir el token CSRF

        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });



        // Inicializa el date range picker

        $('#filter_date_range').daterangepicker({

            locale: { format: 'YYYY-MM-DD' },

            autoUpdateInput: false,

            ranges: {

                'Hoy': [moment(), moment()],

                'Ayer': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],

                'Últimos 7 días': [moment().subtract(6, 'days'), moment()],

                'Últimos 30 días': [moment().subtract(29, 'days'), moment()],

                'Este mes': [moment().startOf('month'), moment().endOf('month')],

                'El mes pasado': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]

            }

        });



        $('#filter_date_range').on('apply.daterangepicker', function (ev, picker) {

            $(this).val(picker.startDate.format('YYYY-MM-DD') + ' ~ ' + picker.endDate.format('YYYY-MM-DD'));

            voucher_table.ajax.reload();

        });



        $('#filter_date_range').on('cancel.daterangepicker', function () {

            $(this).val('');

            voucher_table.ajax.reload();

        });



        // Inicializa DataTables

        var voucher_table = $('#voucher_table').DataTable({

            processing: true,

            serverSide: true,

            ajax: {

                url: '{{ route("vouchers.new.data") }}',

                data: function (d) {

                    d.location_id = $('#filter_location').val();

                    d.company_id = $('#filter_company').val();

                    d.client_id = $('#filter_client').val();

                    d.status = $('#filter_status').val();

                    d.date_range = $('#filter_date_range').val();

                    d.document_type = $('#filter_document_type').val(); // Agregar el filtro de tipo de documento

                }

            },

            columns: [

                { data: 'action', name: 'action', orderable: false, searchable: false },

                { data: 'location_city', name: 'location_city' },

                { data: 'company_name', name: 'company_name' },

                { data: 'NumeroConsecutivo', name: 'NumeroConsecutivo' },

                { data: 'TotalFactura', name: 'TotalFactura' },

                { data: 'MontoTotalImpuesto', name: 'MontoTotalImpuesto' },

                { data: 'fechaEmision', name: 'fechaEmision' },

                { data: 'voucher_type', name: 'voucher_type' },

                { data: 'voucher_status', name: 'voucher_status' }

            ]

        });



        // Recarga la tabla cuando cambien los filtros

        $('#filter_location, #filter_company, #filter_client, #filter_status, #filter_document_type').change(function () {

            voucher_table.ajax.reload();

        });



        // Inicializa select2

        $('.select2').select2();



        // Evento para restablecer filtros

        $('#reset_filters').click(function () {

            $('#filter_location').val('').trigger('change');

            $('#filter_company').val('').trigger('change');

            $('#filter_client').val('').trigger('change');

            $('#filter_status').val('').trigger('change');

            $('#filter_date_range').val('');

            $('#filter_document_type').val('').trigger('change');

            voucher_table.ajax.reload();

        });



        // Manejo de submenús en acciones

        $('.dropdown-submenu a.dropdown-toggle').on("click", function (e) {

            e.preventDefault();

            e.stopPropagation();

            $('.dropdown-submenu .dropdown-menu').removeClass('show');

            var $subMenu = $(this).next('.dropdown-menu');

            $subMenu.toggleClass('show');

            $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function (e) {

                $('.dropdown-submenu .dropdown-menu').removeClass('show');

            });

        });



        // Cierra submenús cuando se hace clic fuera

        $(document).on('click', function () {

            $('.dropdown-submenu .dropdown-menu').removeClass('show');

        });



        $('#sendEmailModal').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget) // Button that triggered the modal

            var voucherId = button.data('voucher-id') // Extract info from data-* attributes

            var modal = $(this)

            modal.find('.modal-body input#voucherId').val(voucherId)

        })



        $('#sendEmailForm').on('submit', function (event) {

            event.preventDefault();

            var voucherId = $('#voucherId').val();

            var emails = $('#emails').val();

            // Perform AJAX request to send the email

        });



    });

</script>

@endsection