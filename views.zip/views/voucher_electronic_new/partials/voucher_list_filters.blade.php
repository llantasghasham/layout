<select id="voucher_location_id" name="location_id" class="form-control select2">
    <option value="">Todas las sucursales</option>
    @foreach ($locations as $id => $location)
        <option value="{{ $id }}">{{ $location }}</option>
    @endforeach
</select>

<select id="voucher_customer_id" name="customer_id" class="form-control select2">
    <option value="">Todos los clientes</option>
    @foreach ($customers as $id => $customer)
        <option value="{{ $id }}">{{ $customer }}</option>
    @endforeach
</select>

<select id="voucher_statuses_id" name="statuses_id" class="form-control select2">
    <option value="">Todos los estados</option>
    @foreach ($statuses as $id => $status)
        <option value="{{ $id }}">{{ $status }}</option>
    @endforeach
</select>

<input type="text" id="voucher_date_range" name="date_range" class="form-control">
