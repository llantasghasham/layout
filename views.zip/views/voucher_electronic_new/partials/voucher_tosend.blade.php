<div class="row">
	<div class="col-md-12">
		<div class="table-responsive"style=" font-family: DejaVu Sans, sans-serif; ">
			<table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd; font-size: small;">
				<tr>
			        <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Cliente</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Sucursal</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Empresa</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Numero Consecutivo</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Total Factura</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Impuesto Total</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Fecha</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Tipo de Documento</th>
                    <th style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #007bff !important; color: #ffffff;">Estado</th>
				</tr>
                <tr>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{$voucher->contact->name ?? 'Cliente Desconocido'}}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{ $voucher->businessLocation->city ?? 'N/A' }}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{ $voucher->businessLocation->name ?? 'Empresa Desconocida' }}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{$voucher->NumeroConsecutivo }}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        ₡&nbsp;<span>{{number_format($voucher->TotalFactura, 2, ',', '.')}}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        ₡&nbsp;<span>{{number_format($voucher->MontoTotalImpuesto, 2, ',', '.')}}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{\Carbon\Carbon::parse($voucher->fechaEmision)->format('d/m/Y H:i:s')}}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{$voucher->getVoucherTypeText()}}</span>
                    </td>
                    <td style="padding: 4px; text-align: left; border: 1px solid #ddd; background-color: #d2d6de !important; color: #000;">
                        <span>{{$voucher->getStatusText()}}</span>
                    </td>
                </tr>
			</table>
		</div>
	</div>
</div>