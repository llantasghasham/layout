@extends('layouts.app')
@section('title', __('lang_v1.vouchers_electronicos_nuevo'))

@section('content')

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="container">
    <h1 class="mb-4 text-center">Detalle del Voucher Electr��nico</h1>

    <div class="card">
        <div class="card-header bg-primary text-white d-flex justify-content-between">
            <h4 class="mb-0">Detalles del Voucher</h4>
            <small>{{ \Carbon\Carbon::now()->format('d/m/Y H:i:s') }}</small>
        </div>
        <div class="card-body">
            <!-- Informaci��n de la Empresa -->
            <div class="row mb-3">
                <div class="col-md-12 text-center">
                    <h5 class="font-weight-bold">{{ $voucher->businessLocation->name ?? 'Empresa Desconocida' }}</h5>
                    <p>{{ $voucher->businessLocation->address ?? 'Direcci��n no disponible' }}</p>
                    <p><strong>Sucursal:</strong> {{ $voucher->businessLocation->city ?? 'N/A' }}</p>
                </div>
            </div>

            <hr>

            <!-- Informaci��n del Cliente -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <h6 class="font-weight-bold">Cliente</h6>
                    <p>{{ $voucher->contact->name ?? 'Cliente Desconocido' }}</p>
                    <p><strong>C��dula Jur��dica:</strong> {{ $voucher->contact->tax_number ?? 'N/A' }}</p>
                </div>
                <div class="col-md-6">
                    <h6 class="font-weight-bold">Informaci��n del Documento</h6>
                    <p><strong>N��mero Consecutivo:</strong> {{ $voucher->NumeroConsecutivo }}</p>
                    <p><strong>Fecha de Emisi��n:</strong> {{ \Carbon\Carbon::parse($voucher->fechaEmision)->format('d/m/Y H:i:s') }}</p>
                </div>
            </div>

            <hr>

            <!-- Detalles del Voucher -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <h6 class="font-weight-bold">Totales</h6>
                    <p><strong>Total Factura:</strong> {{ number_format($voucher->TotalFactura, 2, ',', '.') }} �6�1</p>
                    <p><strong>Impuesto Total:</strong> {{ number_format($voucher->MontoTotalImpuesto, 2, ',', '.') }} �6�1</p>
                </div>
                <div class="col-md-6">
                    <h6 class="font-weight-bold">Estado y Tipo de Documento</h6>
                    <p><strong>Estado:</strong> {{ $voucher->getStatusText() }}</p>
                    <p><strong>Tipo de Documento:</strong> {{ $voucher->getVoucherTypeText() }}</p>
                </div>
            </div>

            <hr>

            <!-- Mensaje -->
            <div class="row">
                <div class="col-12">
                    <h6 class="font-weight-bold">Mensaje Adicional</h6>
                    <p>{{ $voucher->Mensaje ?? 'N/A' }}</p>
                </div>
            </div>
        </div>
    </div>

    <a href="{{ route('vouchers.new.index') }}" class="btn btn-primary mt-4">
        <i class="fas fa-arrow-left"></i> Volver al listado
    </a>
</div>
@endsection
