<div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
		<div class="modal-header">
		    <button type="button" class="close no-print" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		    <h4 class="modal-title" id="modalTitle">ENVIAR VOUCHER POR CORREO Y WHATSAPP</h4>
	    </div>
        <div class="modal-body">
            <!-- FORMULARIOS -->
            <div class="card mb-4 shadow-sm">
                <!-- ENVIO POR CORREO-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="emailForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="email">{{ __('Correo(s) del Cliente') }}:</label>
                                <input type="text" id="email" name="email" class="form-control" placeholder="correo1@example.com, correo2@example.com">
                            </div>
                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-primary w-100" onclick="enviarPDFEmail()">{{ __('Enviar Correo') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- ENVIO POR WHATSAPP-->
                <div class="card-body" style="padding: 10px; width: 100%;">
                    <form id="whatsappForm">
                        @csrf
                        <div style="display: flex; justify-content: center; width: 100%;">
                            <div style="width: 50%">
                                <label for="cellphone">{{ __('Numero de Telefono') }}:</label>
                                <input type="text" id="cellphone" name="cellphone" class="form-control" placeholder="51 999999999">
                            </div>

                            <div style="margin-top: 22px; width: 20%; display: flex; justify-content: center; align-items: center;">
                                <button type="button" class="btn btn-success w-100" onclick="enviarPDFWhatsApp()">{{ __('Enviar WhatsApp') }}</button>
                            </div>
                        </div>
                    </form>
                </div>  
            </div>
        </div>
        <hr>
	    <div id="sendVoucher" style="padding: 15px; position: relative;">
            <div class="row d-flex align-items-center" style="text-align: center; font-size: larger; width: 100%; display: block; margin: auto;">
                <div class="col-sm-12"  style="padding: 2%;">
                    VOUCHER DEL QUE SE ENVIARA LOS ARCHIVOS NECESARIOS
                </div>
                <div class="col-sm-12">
                  @include('voucher_electronic_new.partials.voucher_tosend')
                </div>
            </div>
      	</div>
      	<div class="modal-footer">
	      	<button type="button" class="btn btn-default no-print" data-dismiss="modal">@lang( 'messages.close' )</button>
	    </div>
	</div>
</div>
<script>
    var voucher = @json($voucher);
    function enviarPDFEmail() {
        fetch("{{ route('vouchers.send-voucher-email') }}", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                emails: document.getElementById('email').value,
                voucher: voucher
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error); // Mostrar en consola
            alert(data.message || data.error); // Mostrar en alerta
        }) // Muestra la respuesta en la consola
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }

    function enviarPDFWhatsApp() {    
        fetch("{{ route('vouchers.send-voucher-wsp') }}", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                phone: document.getElementById('cellphone').value,
                voucher: voucher
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta del servidor:", data.message || data.error); // Mostrar en consola
            alert(data.message || data.error); // Mostrar en alerta
        }) // Muestra la respuesta en la consola
        .catch(error => {
            console.error("Error al enviar la solicitud:", error);
            alert("Ocurrió un error al enviar la solicitud.");
        });
    }
</script>
