@extends('layouts.home')
@section('title', config('app.name', 'ultimatePOS'))

@section('content')
    <style type="text/css">
        .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
                margin-top: 10%;
            }
        .title {
                font-size: 84px;
            }
        .tagline {
                font-size:25px;
                font-weight: 300;
                text-align: center;
            }

        @media only screen and (max-width: 600px) {
            .title{
                font-size: 38px;
            }
            .tagline {
                font-size:18px;
            }
        }
    </style>
    <div class="title flex-center" style="font-weight: 600 !important;">
        {{ config('app.name', 'ultimatePOS') }}
    </div>
    <p class="tagline">
        {{ env('APP_TITLE', '') }}
@endsection

<body>
    <!-- Contenido de tu página -->

    <!-- Agrega el código del chat -->
    <div id="chat-container">
        <!-- Aquí van los elementos del chat -->
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Evento de clic en el icono de chat
            var chatIcon = document.getElementById('chat-icon');
            chatIcon.addEventListener('click', function() {
                // Lógica para mostrar la interfaz de chat
                // Por ejemplo, puedes utilizar AJAX para cargar la interfaz de chat desde el servidor
                // y luego mostrarla en el contenedor '#chat-container'
                // También puedes configurar eventos de envío de mensajes y actualización en tiempo real aquí
            });
        });
    </script>

    <!-- Aquí van tus etiquetas de script y otros recursos -->
</body>

            